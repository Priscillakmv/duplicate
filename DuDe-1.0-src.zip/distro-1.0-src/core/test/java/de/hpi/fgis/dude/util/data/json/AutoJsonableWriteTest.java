/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.util.data.json;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import de.hpi.fgis.dude.util.ReflectUtil;
import de.hpi.fgis.dude.util.data.AutoJsonable;

/**
 * Tests the Serialization of the {@link AutoJsonable}.
 * 
 * @author Arvid.Heise
 */
@SuppressWarnings("unused")
public class AutoJsonableWriteTest {
	private static class ArrayClass implements AutoJsonable {
		private final PrimitiveClass[] primitiveClasses = { new PrimitiveClass(), null, new PrimitiveClass() };
		private final int[] ints = { 1, 2, 3 };
	}

	private static class CollectionClass implements AutoJsonable {
		private final List<PrimitiveClass> primitiveClasses = new ArrayList<PrimitiveClass>(Arrays.asList(new PrimitiveClass(), null,
				new PrimitiveClass()));
		private final List<Integer> ints = new ArrayList<Integer>(Arrays.asList(1, 2, 3));
	}

	private static class EmptyClass implements AutoJsonable {
		// empty class
	}

	private static class NestedClass implements AutoJsonable {
		private final PrimitiveClass primitiveClass = new PrimitiveClass();
		private final EmptyClass emptyClass = new EmptyClass();
	}

	private static class PolymorphsmArrayClass implements AutoJsonable {
		private final AutoJsonable[] jsonables = { new EmptyClass(), null, new PrimitiveClass() };
	}

	private static class PolymorphsmClass implements AutoJsonable {
		private final AutoJsonable jsonable = new EmptyClass();
	}

	private static class PolymorphsmCollectionClass implements AutoJsonable {
		private final List<AutoJsonable> jsonables = new ArrayList<AutoJsonable>(Arrays.asList(new EmptyClass(), null, new PrimitiveClass()));
	}

	private static class PrimitiveClass implements AutoJsonable {
		private final int a = 42;
		private final String foo = "bar";
		private final boolean flag = true;
	}

	private void testClass(String expected, Class<?> klazz) {
		String json = JsonUtil.toJson((AutoJsonable) ReflectUtil.newInstance(klazz), true);
		assertEquals(expected, json.replaceAll("\\s", ""));
	}

	/**
	 * 
	 */
	@Test
	public void testWriteArrayClass() {
		String json = "{\"primitiveClasses\":[{\"a\":42,\"foo\":\"bar\",\"flag\":true},null,{\"a\":42,\"foo\":\"bar\",\"flag\":true}],\"ints\":[1,2,3]}";
		this.testClass(json, ArrayClass.class);
	}

	/**
	 * 
	 */
	@Test
	public void testWriteCollectionClass() {
		String json = "{\"primitiveClasses\":[{\"a\":42,\"foo\":\"bar\",\"flag\":true},null,{\"a\":42,\"foo\":\"bar\",\"flag\":true}],\"ints\":[1,2,3]}";
		this.testClass(json, CollectionClass.class);
	}

	/**
	 * 
	 */
	@Test
	public void testWriteEmptyClass() {
		this.testClass("{}", EmptyClass.class);
	}

	/**
	 * 
	 */
	@Test
	public void testWriteNestedClass() {
		String json = "{\"primitiveClass\":{\"a\":42,\"foo\":\"bar\",\"flag\":true},\"emptyClass\":{}}";
		this.testClass(json, NestedClass.class);
	}

	/**
	 * 
	 */
	@Test
	public void testWritePolymorphsmArrayClass() {
		String json = "{\"jsonables\":[{\"class\":\"de.hpi.fgis.dude.util.data.json.AutoJsonableWriteTest$EmptyClass\"},null,{\"class\":\"de.hpi.fgis.dude.util.data.json.AutoJsonableWriteTest$PrimitiveClass\",\"a\":42,\"foo\":\"bar\",\"flag\":true}]}";
		this.testClass(json, PolymorphsmArrayClass.class);
	}

	/**
	 * 
	 */
	@Test
	public void testWritePolymorphsmClass() {
		String json = "{\"jsonable\":{\"class\":\"de.hpi.fgis.dude.util.data.json.AutoJsonableWriteTest$EmptyClass\"}}";
		this.testClass(json, PolymorphsmClass.class);
	}

	/**
	 * 
	 */
	@Test
	public void testWritePolymorphsmCollectionClass() {
		String json = "{\"jsonables\":[{\"class\":\"de.hpi.fgis.dude.util.data.json.AutoJsonableWriteTest$EmptyClass\"},null,{\"class\":\"de.hpi.fgis.dude.util.data.json.AutoJsonableWriteTest$PrimitiveClass\",\"a\":42,\"foo\":\"bar\",\"flag\":true}]}";
		this.testClass(json, PolymorphsmCollectionClass.class);
	}

	/**
	 * 
	 */
	@Test
	public void testWritePrimitiveClass() {
		String json = "{\"a\":42,\"foo\":\"bar\",\"flag\":true}";
		this.testClass(json, PrimitiveClass.class);
	}
}
