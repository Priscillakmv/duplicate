/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.postprocessor;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.util.data.DuDeObject;
import de.hpi.fgis.dude.util.data.DuDeObjectPair;
import de.hpi.fgis.dude.util.data.json.JsonRecord;
import de.hpi.fgis.dude.util.data.json.JsonString;

/**
 * Tests the {@link WarshallTransitiveClosureGenerator} class.
 * 
 * @author Uwe Draisbach
 */
public class WarshallTransitiveClosureGeneratorTest {
	
	private DuDeObject firstObj;
	private DuDeObject secondObj;
	private DuDeObject thirdObj;
	private DuDeObject fourthObj;
	private DuDeObject fifthObj;
	
	private WarshallTransitiveClosureGenerator transClosureMatrix;
	private WarshallTransitiveClosureGenerator transClosureList;
	private Collection<DuDeObjectPair> validResult;
	
	
	/**
	 * Initialization of required objects for all test methods.
	 * 
	 * @throws Exception
	 *             If an error occurs while initializing the test methods.
	 */
	@Before
	public void setUp() throws Exception {
		
		JsonRecord obj = new JsonRecord();
		obj.put("name", new JsonString("Peter"));
		this.firstObj = new DuDeObject(obj, "", "1");

		obj = new JsonRecord();
		obj.put("name", new JsonString("Pippi"));
		this.secondObj = new DuDeObject(obj, "", "2");

		obj = new JsonRecord();
		obj.put("name", new JsonString("Kalle"));
		this.thirdObj = new DuDeObject(obj, "", "3");

		obj = new JsonRecord();
		obj.put("name", new JsonString("Benjamin"));
		this.fourthObj = new DuDeObject(obj, "", "4");

		obj = new JsonRecord();
		obj.put("name", new JsonString("Feivel"));
		this.fifthObj = new DuDeObject(obj, "", "5");
			
		this.transClosureMatrix = new WarshallTransitiveClosureGenerator();
		this.transClosureMatrix.enableAdjacencyMatrixRepresentation();
		this.transClosureMatrix.add(new DuDeObjectPair(this.firstObj, this.secondObj));
		this.transClosureMatrix.add(new DuDeObjectPair(this.secondObj, this.fourthObj));
		this.transClosureMatrix.add(new DuDeObjectPair(this.thirdObj, this.fifthObj));
		
		this.transClosureList = new WarshallTransitiveClosureGenerator();
		this.transClosureList.enableAdjacencyListRepresentation();
		this.transClosureList.add(new DuDeObjectPair(this.firstObj, this.secondObj));
		this.transClosureList.add(new DuDeObjectPair(this.secondObj, this.fourthObj));
		this.transClosureList.add(new DuDeObjectPair(this.thirdObj, this.fifthObj));
		
		this.validResult = new ArrayList<DuDeObjectPair>();
		this.validResult.add(new DuDeObjectPair(this.firstObj,  this.secondObj));
		this.validResult.add(new DuDeObjectPair(this.firstObj,  this.fourthObj));
		this.validResult.add(new DuDeObjectPair(this.secondObj, this.fourthObj));
		this.validResult.add(new DuDeObjectPair(this.thirdObj,  this.fifthObj));
	}
	
	
	/**
	 * Tests the matrix representation of <code>WarshallTransitiveClosureGenerator</code>.
	 */
	@Test
	public void testMatrix() {
		Iterator<DuDeObjectPair> matrixIterator = this.transClosureMatrix.iterator();
		Iterator<DuDeObjectPair> validResultIterator = this.validResult.iterator();

		for (int i = 1; i <= this.validResult.size(); i++) {
			assertTrue("Error at iteration step: " + i, matrixIterator.hasNext());

			DuDeObjectPair currentPair = null;
			try {
				currentPair = matrixIterator.next();
			} catch (NoSuchElementException e) {
				fail("NoSuchElementException occurred at iteration step " + i);
			}
			assertEquals("Error at iteration step: " + i, validResultIterator.next(), currentPair);
		}

		assertFalse("Data iterator has more elements than expected", matrixIterator.hasNext());
	}
	
	/**
	 * Tests the list representation of <code>WarshallTransitiveClosureGenerator</code>.
	 */
	@Test
	public void testList() {
		Iterator<DuDeObjectPair> listIterator = this.transClosureList.iterator();
		Iterator<DuDeObjectPair> validResultIterator = this.validResult.iterator();

		for (int i = 1; i <= this.validResult.size(); i++) {
			assertTrue("Error at iteration step: " + i, listIterator.hasNext());

			DuDeObjectPair currentPair = null;
			try {
				currentPair = listIterator.next();
			} catch (NoSuchElementException e) {
				fail("NoSuchElementException occurred at iterator step " + i);
			}
			assertEquals("Error at iteration step: " + i, validResultIterator.next(), currentPair);
		}

		assertFalse("Data iterator has more elements than expected", listIterator.hasNext());
	}

}
