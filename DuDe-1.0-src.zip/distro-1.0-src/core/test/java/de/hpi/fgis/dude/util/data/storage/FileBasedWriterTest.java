/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.util.data.storage;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;

import org.codehaus.jackson.JsonGenerationException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.util.data.Jsonable;
import de.hpi.fgis.dude.util.data.json.JsonNumber;
import de.hpi.fgis.dude.util.data.json.JsonString;
import de.hpi.fgis.dude.util.data.json.JsonValue;

/**
 * Tests the {@link JsonableWriter} implementation of {@link FileBasedStorage}.
 * 
 * @author Matthias Pohl
 */
public class FileBasedWriterTest extends FileBasedStorageTest {
	
	private JsonString strValue = new JsonString("strVal1");
	private JsonNumber numValue = new JsonNumber(10);

	/**
	 * The preset of each test method.
	 * 
	 * @throws Exception
	 *             If an error occurs while initializing the test methods.
	 */
	@Override
	@Before
	public void setUp() throws Exception {
		super.setUp();
	}

	/**
	 * The tear-down method for each test method.
	 * 
	 * @throws Exception
	 *             If an error occurs during the method call.
	 */
	@Override
	@After
	public void tearDown() throws Exception {
		super.tearDown();
	}

	/**
	 * Tests {@link FileBasedStorage}'s {@link JsonableWriter#add(Jsonable)}
	 */
	@Test
	public void testAdd() {
		JsonableWriter<JsonValue> writer = null;
		try {
			writer = new FileBasedStorage<JsonValue>(this.filename).getWriter();
		} catch (IOException e) {
			fail("IOException occurred...");
		}
		
		try {
			writer.add(this.strValue);
			writer.add(this.numValue);
		} catch (JsonGenerationException e) {
			fail("JsonGenerationException occurred...");
		} catch (IOException e) {
			fail("IOException occurred...");
		}
		
		try {
			writer.close();
			
			JsonableReader<JsonValue> reader = new FileBasedStorage<JsonValue>(this.filename).getReader();
			
			Iterator<JsonValue> iterator = reader.iterator();
			
			assertTrue(iterator.hasNext());
			assertEquals(this.strValue, iterator.next());

			assertTrue(iterator.hasNext());
			assertEquals(this.numValue, iterator.next());
			
			assertFalse(iterator.hasNext());
			
			reader.close();
		} catch (IOException e) {
			fail("IOException occurred...");
		}
	}

	/**
	 * Tests {@link FileBasedStorage}'s {@link JsonableWriter#close()}.
	 */
	@Test
	public void testClose() {
		JsonableWriter<JsonValue> writer = null;
		try {
			writer = new FileBasedStorage<JsonValue>(this.filename).getWriter();
		} catch (IOException e) {
			fail("IOException occurred...");
		}
		
		try {
			writer.close();
		} catch (IOException e) {
			fail("IOException occurred...");
		}

		try {
			writer.close();
		} catch (IOException e) {
			fail("IOException occurred...");
		}
	}

	/**
	 * Tests {@link FileBasedStorage}'s {@link JsonableWriter#addAll(Collection)}.
	 */
	@Test
	public void testAddAll() {
		JsonableWriter<JsonValue> writer = null;
		try {
			writer = new FileBasedStorage<JsonValue>(this.filename).getWriter();
		} catch (IOException e) {
			fail("IOException occurred...");
		}
		
		try {
			writer.addAll(Arrays.asList(new JsonValue[] {this.numValue, this.strValue}));
		} catch (JsonGenerationException e) {
			fail("JsonGenerationException occurred...");
		} catch (IOException e) {
			fail("IOException occurred...");
		}
		
		try {
			writer.close();
			
			JsonableReader<JsonValue> reader = new FileBasedStorage<JsonValue>(this.filename).getReader();
			
			Iterator<JsonValue> iterator = reader.iterator();
			
			assertTrue(iterator.hasNext());
			assertEquals(this.numValue, iterator.next());

			assertTrue(iterator.hasNext());
			assertEquals(this.strValue, iterator.next());
			
			assertFalse(iterator.hasNext());
			
			reader.close();
		} catch (IOException e) {
			fail("IOException occurred...");
		}
	}

}
