/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.algorithm.recordlinkage;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.algorithm.AbstractRecordLinkageTest;
import de.hpi.fgis.dude.datasource.DataSource;
import de.hpi.fgis.dude.util.data.DuDeObjectPair;

/**
 * Tests {@link NaiveRecordLinkage}.
 * 
 * @author Matthias Pohl
 */
public class NaiveRecordLinkageTest extends AbstractRecordLinkageTest<NaiveRecordLinkage> {

	@Override
	@Before
	public void setUp() throws Exception {
		super.setUp();

		this.algorithm = new NaiveRecordLinkage();
		this.algorithm.enableInMemoryProcessing();
	}

	@Override
	@After
	public void tearDown() throws Exception {
		super.tearDown();
	}

	/**
	 * Tests the algorithm's result if several non-empty {@link DataSource}s are attached.
	 */
	@Test
	public void testMultipleDataSources() {
		this.algorithm.addDataSource(this.dataSource0);
		this.algorithm.addDataSource(this.dataSource1);
		this.algorithm.addDataSource(this.dataSource2);

		DuDeObjectPair[] expectedContent = new DuDeObjectPair[] { this.getPair(this.obj_a0, this.obj_b1), this.getPair(this.obj_a0, this.obj_a1),
				this.getPair(this.obj_a0, this.obj_c2), this.getPair(this.obj_a0, this.obj_b2), this.getPair(this.obj_a0, this.obj_a2),
				this.getPair(this.obj_b1, this.obj_c2), this.getPair(this.obj_b1, this.obj_b2), this.getPair(this.obj_b1, this.obj_a2),
				this.getPair(this.obj_a1, this.obj_c2), this.getPair(this.obj_a1, this.obj_b2), this.getPair(this.obj_a1, this.obj_a2) };

		this.testIterator(this.algorithm.iterator(), expectedContent);
	}

	/**
	 * Tests the algorithm's result if an empty and several non-empty {@link DataSource}s are attached.
	 */
	@Test
	public void testMultipleDataSourcesWithEmptyDataSource() {
		this.algorithm.addDataSource(this.emptyDataSource0);
		this.algorithm.addDataSource(this.dataSource1);
		this.algorithm.addDataSource(this.dataSource2);

		DuDeObjectPair[] expectedContent = new DuDeObjectPair[] { this.getPair(this.obj_b1, this.obj_c2), this.getPair(this.obj_b1, this.obj_b2),
				this.getPair(this.obj_b1, this.obj_a2), this.getPair(this.obj_a1, this.obj_c2), this.getPair(this.obj_a1, this.obj_b2),
				this.getPair(this.obj_a1, this.obj_a2) };

		this.testIterator(this.algorithm.iterator(), expectedContent);
	}

	/**
	 * Tests the data size, if an empty {@link DataSource} is attached.
	 * 
	 * @see NaiveRecordLinkage#getDataSize()
	 * @see NaiveRecordLinkage#getDataSize(DataSource)
	 */
	@Test
	public void testGetDataSizeOfEmptyDataSource() {
		this.algorithm.addDataSource(this.emptyDataSource0);

		assertEquals(0, this.algorithm.getDataSize());

		this.algorithm.iterator();

		assertEquals(0, this.algorithm.getDataSize());
		assertEquals(0, this.algorithm.getDataSize(this.emptyDataSource0));

		try {
			this.algorithm.getDataSize(this.emptyDataSource1);
			fail("IllegalArgumentException should have been thrown...");
		} catch (IllegalArgumentException e) {
			// expected behavior
		}

		try {
			this.algorithm.getDataSize(null);
			fail("NullPointerException should have been thrown...");
		} catch (NullPointerException e) {
			// expected behavior
		}
	}

	/**
	 * Tests the data size, if several empty {@link DataSource}s are attached.
	 * 
	 * @see NaiveRecordLinkage#getDataSize()
	 * @see NaiveRecordLinkage#getDataSize(DataSource)
	 */
	@Test
	public void testGetDataSizeOfMultipleEmptyDataSources() {
		this.algorithm.addDataSource(this.emptyDataSource0);
		this.algorithm.addDataSource(this.emptyDataSource1);

		assertEquals(0, this.algorithm.getDataSize());

		this.algorithm.iterator();

		assertEquals(0, this.algorithm.getDataSize());
		assertEquals(0, this.algorithm.getDataSize(this.emptyDataSource0));
		assertEquals(0, this.algorithm.getDataSize(this.emptyDataSource1));

		try {
			this.algorithm.getDataSize(this.dataSource0);
			fail("IllegalArgumentException should have been thrown...");
		} catch (IllegalArgumentException e) {
			// expected behavior
		}

		try {
			this.algorithm.getDataSize(null);
			fail("NullPointerException should have been thrown...");
		} catch (NullPointerException e) {
			// expected behavior
		}
	}

	/**
	 * Tests the data size, if a non-empty {@link DataSource} is attached.
	 * 
	 * @see NaiveRecordLinkage#getDataSize()
	 * @see NaiveRecordLinkage#getDataSize(DataSource)
	 */
	@Test
	public void testGetDataSizeOfOneDataSource() {
		this.algorithm.addDataSource(this.dataSource0);

		assertEquals(0, this.algorithm.getDataSize());

		this.algorithm.iterator();

		// no data was extracted since only one data source was added
		assertEquals(0, this.algorithm.getDataSize());
		assertEquals(0, this.algorithm.getDataSize(this.dataSource0));

		try {
			this.algorithm.getDataSize(this.dataSource1);
			fail("IllegalArgumentException should have been thrown...");
		} catch (IllegalArgumentException e) {
			// expected behavior
		}

		try {
			this.algorithm.getDataSize(null);
			fail("NullPointerException should have been thrown...");
		} catch (NullPointerException e) {
			// expected behavior
		}
	}

	/**
	 * Tests the data size, if several {@link DataSource}s (empty and non-empty) are attached.
	 * 
	 * @see NaiveRecordLinkage#getDataSize()
	 * @see NaiveRecordLinkage#getDataSize(DataSource)
	 */
	@Test
	public void testGetDataSizeOfMultipleDataSources() {
		this.algorithm.addDataSource(this.emptyDataSource0);
		this.algorithm.addDataSource(this.dataSource0);
		this.algorithm.addDataSource(this.dataSource1);

		assertEquals(0, this.algorithm.getDataSize());

		assertEquals(0, this.algorithm.getDataSize(this.emptyDataSource0));
		assertEquals(0, this.algorithm.getDataSize(this.dataSource0));
		assertEquals(0, this.algorithm.getDataSize(this.dataSource1));

		this.algorithm.iterator();

		// no data was extracted since only one data source was added
		assertEquals(3, this.algorithm.getDataSize());

		assertEquals(0, this.algorithm.getDataSize(this.emptyDataSource0));
		assertEquals(1, this.algorithm.getDataSize(this.dataSource0));
		assertEquals(2, this.algorithm.getDataSize(this.dataSource1));

		try {
			this.algorithm.getDataSize(this.dataSource2);
			fail("IllegalArgumentException should have been thrown...");
		} catch (IllegalArgumentException e) {
			// expected behavior
		}

		try {
			this.algorithm.getDataSize(null);
			fail("NullPointerException should have been thrown...");
		} catch (NullPointerException e) {
			// expected behavior
		}
	}
}
