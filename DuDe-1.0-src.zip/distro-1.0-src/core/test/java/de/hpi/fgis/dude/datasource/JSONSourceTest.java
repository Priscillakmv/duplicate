/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.datasource;

import java.io.File;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;

import de.hpi.fgis.dude.util.data.json.JsonArray;
import de.hpi.fgis.dude.util.data.json.JsonBoolean;
import de.hpi.fgis.dude.util.data.json.JsonNull;
import de.hpi.fgis.dude.util.data.json.JsonNumber;
import de.hpi.fgis.dude.util.data.json.JsonRecord;
import de.hpi.fgis.dude.util.data.json.JsonString;

/**
 * Tests {@link JSONSource}.
 * 
 * @author Matthias Pohl
 */
public class JSONSourceTest extends AbstractDataSourceTest<JSONSource> {

	private File dataFile;
	
	@Override
	@Before
	public void setUp() throws Exception {
		super.setUp();
		
		this.dataSource = new JSONSource("json", this.dataFile);
	}

	@Override
	@After
	public void tearDown() throws Exception {
		// close all file connections before the file is deleted
		super.tearDown();
		
		this.dataFile.delete();
	}

	@Override
	protected void initializeData() throws Exception {
		this.dataFile = File.createTempFile("JSONSourceTest", ".json");
		
		PrintStream writer = new PrintStream(this.dataFile);
		
		writer.println("[");
		
		// record 0
		writer.println("{");
		writer.println("\"attr1\" : 0,");
		writer.println("\"" + AbstractDataSourceTest.DEFAULT_ID_ATTRIBUTE + "\" : \"asd0\",");
		writer.println("\"attr2\" : true,");
		writer.println("\"attr3\" : null,");
		writer.println("\"attr4\" : [ 0, \"asd0\" ],");
		writer.println("\"attr5\" : {");
		writer.println("    \"attr51\" : 10,");
		writer.println("    \"attr52\" : true,");
		writer.println("    \"attr53\" : null");
		writer.println("  }");
		writer.println("},");
		
		// record 1
		writer.println("{");
		writer.println("\"attr1\" : 1,");
		writer.println("\"" + AbstractDataSourceTest.DEFAULT_ID_ATTRIBUTE + "\" : \"asd1\",");
		writer.println("\"attr2\" : false,");
		writer.println("\"attr3\" : null,");
		writer.println("\"attr4\" : [ 1, \"asd1\" ],");
		writer.println("\"attr5\" : {");
		writer.println("    \"attr51\" : 11,");
		writer.println("    \"attr52\" : false,");
		writer.println("    \"attr53\" : null");
		writer.println("  }");
		writer.println("},");
		
		// record 2
		writer.println("{");
		writer.println("\"attr1\" : 2,");
		writer.println("\"" + AbstractDataSourceTest.DEFAULT_ID_ATTRIBUTE + "\" : \"asd2\",");
		writer.println("\"attr2\" : true,");
		writer.println("\"attr3\" : null,");
		writer.println("\"attr4\" : [ 2, \"asd2\" ],");
		writer.println("\"attr5\" : {");
		writer.println("    \"attr51\" : 12,");
		writer.println("    \"attr52\" : true,");
		writer.println("    \"attr53\" : null");
		writer.println("  }");
		writer.println("}");
		
		writer.println("]");
		
		writer.close();
	}

	@Override
	protected void initializeRecords() {
		JsonArray attr4;
		JsonRecord attr5;
		
		this.record0 = new JsonRecord();
		this.record0.put(AbstractDataSourceTest.DEFAULT_ID_ATTRIBUTE, new JsonString("asd0"));
		this.record0.put("attr1", new JsonNumber(0));
		this.record0.put("attr2", JsonBoolean.TRUE);
		this.record0.put("attr3", JsonNull.NULL);
		
		attr4 = new JsonArray();
		attr4.add(0);
		attr4.add("asd0");
		this.record0.put("attr4", attr4);
		
		attr5 = new JsonRecord();
		attr5.put("attr51", new JsonNumber(10));
		attr5.put("attr52", JsonBoolean.TRUE);
		attr5.put("attr53", JsonNull.NULL);
		this.record0.put("attr5", attr5);
		
		this.record1 = new JsonRecord();
		this.record1.put(AbstractDataSourceTest.DEFAULT_ID_ATTRIBUTE, new JsonString("asd1"));
		this.record1.put("attr1", new JsonNumber(1));
		this.record1.put("attr2", JsonBoolean.FALSE);
		this.record1.put("attr3", JsonNull.NULL);
		
		attr4 = new JsonArray();
		attr4.add(1);
		attr4.add("asd1");
		this.record1.put("attr4", attr4);
		
		attr5 = new JsonRecord();
		attr5.put("attr51", new JsonNumber(11));
		attr5.put("attr52", JsonBoolean.FALSE);
		attr5.put("attr53", JsonNull.NULL);
		this.record1.put("attr5", attr5);
		
		this.record2 = new JsonRecord();
		this.record2.put(AbstractDataSourceTest.DEFAULT_ID_ATTRIBUTE, new JsonString("asd2"));
		this.record2.put("attr1", new JsonNumber(2));
		this.record2.put("attr2", JsonBoolean.TRUE);
		this.record2.put("attr3", JsonNull.NULL);
		
		attr4 = new JsonArray();
		attr4.add(2);
		attr4.add("asd2");
		this.record2.put("attr4", attr4);
		
		attr5 = new JsonRecord();
		attr5.put("attr51", new JsonNumber(12));
		attr5.put("attr52", JsonBoolean.TRUE);
		attr5.put("attr53", JsonNull.NULL);
		this.record2.put("attr5", attr5);
	}

}
