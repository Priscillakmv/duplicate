/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.algorithm.duplicatedetection;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.algorithm.AbstractDuplicateDetectionTest;
import de.hpi.fgis.dude.algorithm.AlgorithmTest;
import de.hpi.fgis.dude.algorithm.duplicatedetection.DuplicateCountSNM.AdaptionMode;
import de.hpi.fgis.dude.algorithm.duplicatedetection.DuplicateCountSNM.ComparisonResult;
import de.hpi.fgis.dude.util.data.DuDeObjectPair;
import de.hpi.fgis.dude.util.sorting.sortingkey.SortingKey;
import de.hpi.fgis.dude.util.sorting.sortingkey.TextBasedSubkey;

/**
 * Tests the {@link DuplicateCountSNM} class.
 * 
 * @author Uwe Draisbach
 */
public class DuplicateCountSNMTest extends AbstractDuplicateDetectionTest<DuplicateCountSNM> {

	private SortingKey sortingKey;

	@Override
	@Before
	public void setUp() throws Exception {
		super.setUp();

		this.sortingKey = new SortingKey();
		this.sortingKey.addSubkey(new TextBasedSubkey(AlgorithmTest.ATTR_ATTRIBUTE_NAME));

		this.algorithm = new DuplicateCountSNM.AdaptiveWindowSizeSNMBuilder(this.sortingKey, AdaptionMode.MULTI_REC_INCREASE).windowSize(5)
				.increaseThreshold(0.25f).build();
		this.algorithm.enableInMemoryProcessing();
	}

	@Override
	@After
	public void tearDown() throws Exception {
		super.tearDown();
	}

	/**
	 * Tests the content returned by the passed iterator.
	 * 
	 * @param iterator
	 *            The iterator of which the content shall be checked.
	 * @param goldStandard
	 *            The pairs that shall be categorized as {@link ComparisonResult#DUPLICATE}.
	 * @param expectedContent
	 *            The expected content.
	 */
	protected void testIterator(Iterator<DuDeObjectPair> iterator, Collection<DuDeObjectPair> goldStandard, DuDeObjectPair... expectedContent) {
		assertNotNull(iterator);

		for (int i = 0; i < expectedContent.length; i++) {
			assertTrue("hasNext() failed: All elements starting with index #" + i + " are missing.", iterator.hasNext());
			try {
				DuDeObjectPair pair = iterator.next();
				assertEquals("next() failed: Element #" + i + " is wrong.", expectedContent[i], pair);

				if (goldStandard.contains(pair)) {
					this.algorithm.notifyOfLatestComparisonResult(ComparisonResult.DUPLICATE);
				} else {
					this.algorithm.notifyOfLatestComparisonResult(ComparisonResult.NON_DUPLICATE);
				}
			} catch (NoSuchElementException e) {
				fail("NoSuchElementException occurred...");
			}
		}

		assertFalse(iterator.hasNext());
		try {
			iterator.next();
			fail("NoSuchElementException should have been thrown...");
		} catch (NoSuchElementException e) {
			// expected behavior
		}
	}

	/**
	 * Tests the content returned by the passed iterator.
	 * 
	 * @param iterator
	 *            The iterator of which the content shall be checked.
	 * @param notificationType
	 *            The {@link ComparisonResult} that is sent to the {@link DuplicateCountSNM} instance for each pair.
	 * @param expectedContent
	 *            The expected content.
	 */
	protected void testIterator(Iterator<DuDeObjectPair> iterator, ComparisonResult notificationType, DuDeObjectPair... expectedContent) {
		assertNotNull(iterator);

		for (int i = 0; i < expectedContent.length; i++) {
			assertTrue("hasNext() failed: All elements starting with index #" + i + " are missing.", iterator.hasNext());
			try {
				DuDeObjectPair pair = iterator.next();
				assertEquals("next() failed: Element #" + i + " is wrong.", expectedContent[i], pair);

				this.algorithm.notifyOfLatestComparisonResult(notificationType);
			} catch (NoSuchElementException e) {
				fail("NoSuchElementException occurred...");
			}
		}

		assertFalse(iterator.hasNext());
		try {
			iterator.next();
			fail("NoSuchElementException should have been thrown...");
		} catch (NoSuchElementException e) {
			// expected behavior
		}
	}

	@Override
	protected void testIterator(Iterator<DuDeObjectPair> iterator, DuDeObjectPair... expectedContent) {
		this.testIterator(iterator, ComparisonResult.NON_DUPLICATE, expectedContent);
	}

	/**
	 * Tests the created DuDeObject-Pairs
	 * 
	 * Window size: 2 Adaption mode: Average Duplicates: none
	 */
	@Test
	public void test_WindowSize2_AdaptionModeAverage_NotificationNoDuplicate() {
		// initialize algorithm
		this.algorithm = new DuplicateCountSNM.AdaptiveWindowSizeSNMBuilder(this.sortingKey, AdaptionMode.BASIC).windowSize(2).build();

		// add data to algorithm
		this.algorithm.addDataSource(this.dataSource0);
		this.algorithm.addDataSource(this.dataSource1);
		this.algorithm.addDataSource(this.dataSource2);

		this.algorithm.enableInMemoryProcessing();

		DuDeObjectPair[] expectedContent = new DuDeObjectPair[] { this.getPair(this.obj_a0, this.obj_a1), this.getPair(this.obj_a1, this.obj_a2),
				this.getPair(this.obj_a2, this.obj_b1), this.getPair(this.obj_b1, this.obj_b2), this.getPair(this.obj_b2, this.obj_c2) };

		this.testIterator(this.algorithm.iterator(), expectedContent);
	}

	/**
	 * Tests the created DuDeObject-Pairs
	 * 
	 * Window size: 3 Adaption mode: Average Duplicates: none
	 */
	@Test
	public void test_WindowSize3_AdaptionModeAverage_NotificationNoDuplicate() {
		// initialize algorithm
		this.algorithm = new DuplicateCountSNM.AdaptiveWindowSizeSNMBuilder(this.sortingKey, AdaptionMode.BASIC).windowSize(3).build();

		// add data to algorithm
		this.algorithm.addDataSource(this.dataSource0);
		this.algorithm.addDataSource(this.dataSource1);
		this.algorithm.addDataSource(this.dataSource2);

		this.algorithm.enableInMemoryProcessing();

		DuDeObjectPair[] expectedContent = new DuDeObjectPair[] { this.getPair(this.obj_a0, this.obj_a1), this.getPair(this.obj_a0, this.obj_a2),
				this.getPair(this.obj_a1, this.obj_a2), this.getPair(this.obj_a1, this.obj_b1), this.getPair(this.obj_a2, this.obj_b1),
				this.getPair(this.obj_a2, this.obj_b2), this.getPair(this.obj_b1, this.obj_b2), this.getPair(this.obj_b1, this.obj_c2),
				this.getPair(this.obj_b2, this.obj_c2) };

		this.testIterator(this.algorithm.iterator(), expectedContent);
	}

	/**
	 * Tests the created DuDeObject-Pairs
	 * 
	 * Window size: 2 Adaption mode: Average Duplicates: [a0, a1] and [a2, b1, b2, c2] are duplicate groups
	 */
	@Test
	public void test_WindowSize2_AdaptionModeAverage_NotificationDuplicate() {
		// initialize algorithm
		this.algorithm = new DuplicateCountSNM.AdaptiveWindowSizeSNMBuilder(this.sortingKey, AdaptionMode.BASIC).windowSize(2)
				.increaseThreshold(0.51f).build();

		this.algorithm.addDataSource(this.dataSource0);
		this.algorithm.addDataSource(this.dataSource1);
		this.algorithm.addDataSource(this.dataSource2);

		this.algorithm.enableInMemoryProcessing();

		Collection<DuDeObjectPair> goldStandard = new ArrayList<DuDeObjectPair>();
		goldStandard.add(this.getPair(this.obj_a0, this.obj_a1));
		goldStandard.add(this.getPair(this.obj_a2, this.obj_b1));
		goldStandard.add(this.getPair(this.obj_a2, this.obj_b2));
		goldStandard.add(this.getPair(this.obj_a2, this.obj_c2));

		DuDeObjectPair[] expectedContent = new DuDeObjectPair[] { this.getPair(this.obj_a0, this.obj_a1), this.getPair(this.obj_a0, this.obj_a2),
				this.getPair(this.obj_a1, this.obj_a2), this.getPair(this.obj_a2, this.obj_b1), this.getPair(this.obj_a2, this.obj_b2),
				this.getPair(this.obj_a2, this.obj_c2), this.getPair(this.obj_b1, this.obj_b2), this.getPair(this.obj_b2, this.obj_c2) };

		this.testIterator(this.algorithm.iterator(), goldStandard, expectedContent);
	}
	
	/**
	 * Tests the created DuDeObject-Pairs
	 * 
	 * Window size: 3 
	 * Adaption mode: Average
	 * Duplicates: [a1, a2] is a duplicate group
	 */
	@Test
	public void test_WindowSize3_AdaptionModeAverage_NotificationDuplicate() {
		// initialize algorithm
		this.algorithm = new DuplicateCountSNM.AdaptiveWindowSizeSNMBuilder(this.sortingKey, AdaptionMode.BASIC).windowSize(3).increaseThreshold(0.3f).build();

		// add data to algorithm
		this.algorithm.addDataSource(this.dataSource0);
		this.algorithm.addDataSource(this.dataSource1);
		this.algorithm.addDataSource(this.dataSource2);

		this.algorithm.enableInMemoryProcessing();

		Collection<DuDeObjectPair> goldStandard = new ArrayList<DuDeObjectPair>();
		goldStandard.add(this.getPair(this.obj_a1, this.obj_a2));
		
		DuDeObjectPair[] expectedContent = new DuDeObjectPair[] { 
				this.getPair(this.obj_a0, this.obj_a1), 
				this.getPair(this.obj_a0, this.obj_a2),
				this.getPair(this.obj_a1, this.obj_a2), 
				this.getPair(this.obj_a1, this.obj_b1), 
				this.getPair(this.obj_a1, this.obj_b2), 
				this.getPair(this.obj_a1, this.obj_c2), 
				this.getPair(this.obj_a2, this.obj_b1),
				this.getPair(this.obj_a2, this.obj_b2), 
				this.getPair(this.obj_b1, this.obj_b2), 
				this.getPair(this.obj_b1, this.obj_c2),
				this.getPair(this.obj_b2, this.obj_c2) 
		};

		this.testIterator(this.algorithm.iterator(), goldStandard, expectedContent);
	}
	
	/**
	 * Tests the created DuDeObject-Pairs
	 * 
	 * Window size: 3 
	 * Adaption mode: Large Increase 
	 * Duplicates: none
	 */
	@Test
	public void test_WindowSize3_AdaptionModeLargeIncrease_NotificationNoDuplicate() {
		// initialize algorithm
		this.algorithm = new DuplicateCountSNM.AdaptiveWindowSizeSNMBuilder(this.sortingKey, AdaptionMode.MULTI_REC_INCREASE).windowSize(3).build();

		// add data to algorithm
		this.algorithm.addDataSource(this.dataSource0);
		this.algorithm.addDataSource(this.dataSource1);
		this.algorithm.addDataSource(this.dataSource2);

		this.algorithm.enableInMemoryProcessing();
		
		DuDeObjectPair[] expectedContent = new DuDeObjectPair[] { 
				this.getPair(this.obj_a0, this.obj_a1), 
				this.getPair(this.obj_a0, this.obj_a2),
				this.getPair(this.obj_a1, this.obj_a2), 
				this.getPair(this.obj_a1, this.obj_b1),
				this.getPair(this.obj_a2, this.obj_b1),
				this.getPair(this.obj_a2, this.obj_b2), 
				this.getPair(this.obj_b1, this.obj_b2), 
				this.getPair(this.obj_b1, this.obj_c2),
				this.getPair(this.obj_b2, this.obj_c2) 
		};

		this.testIterator(this.algorithm.iterator(), expectedContent);
	}
	
//	/**
//	 * Tests the created DuDeObject-Pairs
//	 * 
//	 * Window size: 3 
//	 * Adaption mode: Large Increase 
//	 * Duplicates: [a1, a2] is a duplicate group
//	 */
//	@Test
//	public void test_WindowSize3_AdaptionModeLargeIncrease_NotificationDuplicate() {
//		// initialize algorithm
//		this.algorithm = new AdaptiveWindowSizeSNM.AdaptiveWindowSizeSNMBuilder(this.sortingKey, AdaptionMode.LARGE_INCREASE).windowSize(3).build();
//
//		// add data to algorithm
//		this.algorithm.addDataSource(this.dataSource0);
//		this.algorithm.addDataSource(this.dataSource1);
//		this.algorithm.addDataSource(this.dataSource2);
//
//		this.algorithm.enableInMemoryProcessing();
//		
//		Collection<DuDeObjectPair> goldStandard = new ArrayList<DuDeObjectPair>();
//		goldStandard.add(this.getPair(this.obj_a1, this.obj_b2));
//		
//		DuDeObjectPair[] expectedContent = new DuDeObjectPair[] { 
//				this.getPair(this.obj_a0, this.obj_a1), 
//				this.getPair(this.obj_a0, this.obj_a2),
//				this.getPair(this.obj_a1, this.obj_a2), 
//				this.getPair(this.obj_a1, this.obj_b1),
//				this.getPair(this.obj_a2, this.obj_b1),
//				this.getPair(this.obj_a2, this.obj_b2), 
//				this.getPair(this.obj_b1, this.obj_b2), 
//				this.getPair(this.obj_b1, this.obj_c2),
//				this.getPair(this.obj_b2, this.obj_c2) 
//		};
//
//		this.testIterator(this.algorithm.iterator(), goldStandard, expectedContent);
//	}
	
	/**
	 * Tests the created DuDeObject-Pairs
	 * 
	 * Window size: 3 
	 * Adaption mode: Max distance
	 * Duplicates: none
	 */
	@Test
	public void test_WindowSize3_AdaptionModeMaxDistance_NotificationNoDuplicate() {
		// initialize algorithm
		this.algorithm = new DuplicateCountSNM.AdaptiveWindowSizeSNMBuilder(this.sortingKey, AdaptionMode.DISTANCE_BASED_INCREASE).windowSize(3).build();

		// add data to algorithm
		this.algorithm.addDataSource(this.dataSource0);
		this.algorithm.addDataSource(this.dataSource1);
		this.algorithm.addDataSource(this.dataSource2);

		this.algorithm.enableInMemoryProcessing();
		
		DuDeObjectPair[] expectedContent = new DuDeObjectPair[] { 
				this.getPair(this.obj_a0, this.obj_a1), 
				this.getPair(this.obj_a0, this.obj_a2),
				this.getPair(this.obj_a1, this.obj_a2), 
				this.getPair(this.obj_a1, this.obj_b1),
				this.getPair(this.obj_a2, this.obj_b1),
				this.getPair(this.obj_a2, this.obj_b2), 
				this.getPair(this.obj_b1, this.obj_b2), 
				this.getPair(this.obj_b1, this.obj_c2),
				this.getPair(this.obj_b2, this.obj_c2) 
		};

		this.testIterator(this.algorithm.iterator(), expectedContent);
	}
	
//	/**
//	 * Tests the created DuDeObject-Pairs
//	 * 
//	 * Window size: 2 
//	 * Adaption mode: Max distance
//	 * Duplicates: [a1, a2] is a duplicate group
//	 */
//	@Test
//	public void test_WindowSize2_AdaptionModeMaxDistance_NotificationDuplicate() {
//		// initialize algorithm
//		this.algorithm = new AdaptiveWindowSizeSNM.AdaptiveWindowSizeSNMBuilder(this.sortingKey, AdaptionMode.MAX_DISTANCE).windowSize(2).increaseThreshold(0.251f).build();
//
//		// add data to algorithm
//		this.algorithm.addDataSource(this.dataSource0);
//		this.algorithm.addDataSource(this.dataSource1);
//		this.algorithm.addDataSource(this.dataSource2);
//
//		this.algorithm.enableInMemoryProcessing();
//
//		Collection<DuDeObjectPair> goldStandard = new ArrayList<DuDeObjectPair>();
//		goldStandard.add(this.getPair(this.obj_a1, this.obj_b2));
//		
//		DuDeObjectPair[] expectedContent = new DuDeObjectPair[] { 
//				this.getPair(this.obj_a0, this.obj_a1), 
//				this.getPair(this.obj_a0, this.obj_a2),
//				this.getPair(this.obj_a1, this.obj_a2), 
//				this.getPair(this.obj_a1, this.obj_b1),
//				this.getPair(this.obj_a2, this.obj_b1),
//				this.getPair(this.obj_a2, this.obj_b2), 
//				this.getPair(this.obj_b1, this.obj_b2), 
//				this.getPair(this.obj_b1, this.obj_c2),
//				this.getPair(this.obj_b2, this.obj_c2) 
//		};
//
//		this.testIterator(this.algorithm.iterator(), goldStandard, expectedContent);
//	}
	
	/**
	 * Tests the created DuDeObject-Pairs
	 * 
	 * Window size: 3 
	 * Adaption mode: Percentage
	 * Duplicates: none
	 */
	@Test
	public void test_WindowSize3_AdaptionModePercentage_NotificationNoDuplicate() {
		// initialize algorithm
		this.algorithm = new DuplicateCountSNM.AdaptiveWindowSizeSNMBuilder(this.sortingKey, AdaptionMode.PERCENTAGE_INCREASE).windowSize(3).build();

		// add data to algorithm
		this.algorithm.addDataSource(this.dataSource0);
		this.algorithm.addDataSource(this.dataSource1);
		this.algorithm.addDataSource(this.dataSource2);

		this.algorithm.enableInMemoryProcessing();
		
		DuDeObjectPair[] expectedContent = new DuDeObjectPair[] { 
				this.getPair(this.obj_a0, this.obj_a1), 
				this.getPair(this.obj_a0, this.obj_a2),
				this.getPair(this.obj_a1, this.obj_a2), 
				this.getPair(this.obj_a1, this.obj_b1),
				this.getPair(this.obj_a2, this.obj_b1),
				this.getPair(this.obj_a2, this.obj_b2), 
				this.getPair(this.obj_b1, this.obj_b2), 
				this.getPair(this.obj_b1, this.obj_c2),
				this.getPair(this.obj_b2, this.obj_c2) 
		};

		this.testIterator(this.algorithm.iterator(), expectedContent);
	}
	
//	/**
//	 * Tests the created DuDeObject-Pairs
//	 * 
//	 * Window size: 2 
//	 * Adaption mode: Percentage
//	 * Duplicates: [a1, a2] is a duplicate group
//	 */
//	@Test
//	public void test_WindowSize2_AdaptionModePercentage_NotificationDuplicate() {
//		// initialize algorithm
//		this.algorithm = new AdaptiveWindowSizeSNM.AdaptiveWindowSizeSNMBuilder(this.sortingKey, AdaptionMode.PERCENTAGE).windowSize(2).increaseThreshold(0.3f).increaseFactor(2.0f).build();
//
//		// add data to algorithm
//		this.algorithm.addDataSource(this.dataSource0);
//		this.algorithm.addDataSource(this.dataSource1);
//		this.algorithm.addDataSource(this.dataSource2);
//
//		this.algorithm.enableInMemoryProcessing();
//
//		Collection<DuDeObjectPair> goldStandard = new ArrayList<DuDeObjectPair>();
//		goldStandard.add(this.getPair(this.obj_a1, this.obj_b2));
//		
//		DuDeObjectPair[] expectedContent = new DuDeObjectPair[] { 
//				this.getPair(this.obj_a0, this.obj_a1), 
//				this.getPair(this.obj_a0, this.obj_a2),
//				this.getPair(this.obj_a1, this.obj_a2), 
//				this.getPair(this.obj_a1, this.obj_b1),
//				this.getPair(this.obj_a2, this.obj_b1),
//				this.getPair(this.obj_a2, this.obj_b2), 
//				this.getPair(this.obj_b1, this.obj_b2), 
//				this.getPair(this.obj_b1, this.obj_c2),
//				this.getPair(this.obj_b2, this.obj_c2) 
//		};
//
//		this.testIterator(this.algorithm.iterator(), goldStandard, expectedContent);
//	}

}
