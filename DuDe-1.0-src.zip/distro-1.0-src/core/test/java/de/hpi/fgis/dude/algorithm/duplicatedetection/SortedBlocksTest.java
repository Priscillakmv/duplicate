/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.algorithm.duplicatedetection;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.algorithm.duplicatedetection.SortedBlocks.AlgorithmVariant;
import de.hpi.fgis.dude.datasource.DataSource;
import de.hpi.fgis.dude.datasource.DuDeObjectSource;
import de.hpi.fgis.dude.util.data.DuDeObject;
import de.hpi.fgis.dude.util.data.DuDeObjectPair;
import de.hpi.fgis.dude.util.data.json.JsonArray;
import de.hpi.fgis.dude.util.data.json.JsonRecord;
import de.hpi.fgis.dude.util.data.json.JsonString;
import de.hpi.fgis.dude.util.sorting.sortingkey.SortingKey;
import de.hpi.fgis.dude.util.sorting.sortingkey.TextBasedSubkey;

public class SortedBlocksTest {
	
	private DataSource dataSource;
	private Collection<DuDeObject> coll = new ArrayList<DuDeObject>();
    private String sourceID = "src";
	
	private DuDeObject a1_Object;
	private DuDeObject a2_Object;
	private DuDeObject a3_Object;
	private DuDeObject b1_Object;
	private DuDeObject b2_Object;
	private DuDeObject b3_Object;
	private DuDeObject b4_Object;
	private DuDeObject c1_Object;
	private DuDeObject c2_Object;
	private DuDeObject c3_Object;
	private DuDeObject d1_Object;
	private DuDeObject d2_Object;
	
	private SortingKey sortingKey;

	private Collection<DuDeObjectPair> validResultBasic               = new ArrayList<DuDeObjectPair>();
	private Collection<DuDeObjectPair> validResultFixPartitionSize    = new ArrayList<DuDeObjectPair>();
	private Collection<DuDeObjectPair> validResultMaxSizeNewPartition = new ArrayList<DuDeObjectPair>();
	private Collection<DuDeObjectPair> validResultMaxSizeSlideWindow  = new ArrayList<DuDeObjectPair>();
	
	

	/**
	 * The preset of each test method.
	 * 
	 * @throws Exception
	 *             If an error occurs while initializing the test methods.
	 */
	@Before
	public void setUp() throws Exception {
		
		// Sorting key configuration
		TextBasedSubkey subkey = new TextBasedSubkey("Name");
		//subkey.setRange(0, 1);
		this.sortingKey = new SortingKey(subkey);
		
		// Test data preparation
		JsonRecord data = new JsonRecord();
		data.put("Name", new JsonArray(new JsonString("AAA1")));
		this.a1_Object = new DuDeObject(data, this.sourceID, "0");
		
		data = new JsonRecord();
		data.put("Name", new JsonArray(new JsonString("AAA2")));
		this.a2_Object = new DuDeObject(data, this.sourceID, "1");
		
		data = new JsonRecord();
		data.put("Name", new JsonArray(new JsonString("AAA3")));
		this.a3_Object = new DuDeObject(data, this.sourceID, "2");
		
		data = new JsonRecord();
		data.put("Name", new JsonArray(new JsonString("BBB1")));
		this.b1_Object = new DuDeObject(data, this.sourceID, "3");
		
		data = new JsonRecord();
		data.put("Name", new JsonArray(new JsonString("BBB2")));
		this.b2_Object = new DuDeObject(data, this.sourceID, "4");
		
		data = new JsonRecord();
		data.put("Name", new JsonArray(new JsonString("BBB3")));
		this.b3_Object = new DuDeObject(data, this.sourceID, "5");
		
		data = new JsonRecord();
		data.put("Name", new JsonArray(new JsonString("BBB4")));
		this.b4_Object = new DuDeObject(data, this.sourceID, "6");
		
		data = new JsonRecord();
		data.put("Name", new JsonArray(new JsonString("CCC1")));
		this.c1_Object = new DuDeObject(data, this.sourceID, "7");
		
		data = new JsonRecord();
		data.put("Name", new JsonArray(new JsonString("CCC2")));
		this.c2_Object = new DuDeObject(data, this.sourceID, "8");
		
		data = new JsonRecord();
		data.put("Name", new JsonArray(new JsonString("CCC3")));
		this.c3_Object = new DuDeObject(data, this.sourceID, "9");
		
		data = new JsonRecord();
		data.put("Name", new JsonArray(new JsonString("DDD1")));
		this.d1_Object = new DuDeObject(data, this.sourceID, "10");
		
		data = new JsonRecord();
		data.put("Name", new JsonArray(new JsonString("DDD2")));
		this.d2_Object = new DuDeObject(data, this.sourceID, "11");
		
		
		this.coll = new ArrayList<DuDeObject>();
		this.coll.add(this.a1_Object);
		this.coll.add(this.b1_Object);
		this.coll.add(this.c1_Object);
		this.coll.add(this.d1_Object);
		this.coll.add(this.a2_Object);
		this.coll.add(this.b2_Object);
		this.coll.add(this.c2_Object);
		this.coll.add(this.d2_Object);
		this.coll.add(this.a3_Object);
		this.coll.add(this.b3_Object);
		this.coll.add(this.c3_Object);
		this.coll.add(this.b4_Object);
		
		this.dataSource = new DuDeObjectSource(this.sourceID, this.coll);

		// Expected result for Basic variant
		this.validResultBasic.add(new DuDeObjectPair(this.a1_Object, this.a2_Object));
		this.validResultBasic.add(new DuDeObjectPair(this.a1_Object, this.a3_Object));
		this.validResultBasic.add(new DuDeObjectPair(this.a2_Object, this.a3_Object));
		this.validResultBasic.add(new DuDeObjectPair(this.a2_Object, this.b1_Object));
		this.validResultBasic.add(new DuDeObjectPair(this.a3_Object, this.b1_Object));
		this.validResultBasic.add(new DuDeObjectPair(this.a3_Object, this.b2_Object));
		this.validResultBasic.add(new DuDeObjectPair(this.b1_Object, this.b2_Object));
		this.validResultBasic.add(new DuDeObjectPair(this.b1_Object, this.b3_Object));
		this.validResultBasic.add(new DuDeObjectPair(this.b2_Object, this.b3_Object));
		this.validResultBasic.add(new DuDeObjectPair(this.b1_Object, this.b4_Object));
		this.validResultBasic.add(new DuDeObjectPair(this.b2_Object, this.b4_Object));
		this.validResultBasic.add(new DuDeObjectPair(this.b3_Object, this.b4_Object));
		this.validResultBasic.add(new DuDeObjectPair(this.b3_Object, this.c1_Object));
		this.validResultBasic.add(new DuDeObjectPair(this.b4_Object, this.c1_Object));
		this.validResultBasic.add(new DuDeObjectPair(this.b4_Object, this.c2_Object));
		this.validResultBasic.add(new DuDeObjectPair(this.c1_Object, this.c2_Object));
		this.validResultBasic.add(new DuDeObjectPair(this.c1_Object, this.c3_Object));
		this.validResultBasic.add(new DuDeObjectPair(this.c2_Object, this.c3_Object));
		this.validResultBasic.add(new DuDeObjectPair(this.c2_Object, this.d1_Object));
		this.validResultBasic.add(new DuDeObjectPair(this.c3_Object, this.d1_Object));
		this.validResultBasic.add(new DuDeObjectPair(this.c3_Object, this.d2_Object));
		this.validResultBasic.add(new DuDeObjectPair(this.d1_Object, this.d2_Object));
		
		// Expected result for FixPartitionSize variant
		this.validResultFixPartitionSize.add(new DuDeObjectPair(this.a1_Object, this.a2_Object));
		this.validResultFixPartitionSize.add(new DuDeObjectPair(this.a1_Object, this.a3_Object));
		this.validResultFixPartitionSize.add(new DuDeObjectPair(this.a2_Object, this.a3_Object));
		this.validResultFixPartitionSize.add(new DuDeObjectPair(this.a3_Object, this.b1_Object));
		this.validResultFixPartitionSize.add(new DuDeObjectPair(this.b1_Object, this.b2_Object));
		this.validResultFixPartitionSize.add(new DuDeObjectPair(this.b1_Object, this.b3_Object));
		this.validResultFixPartitionSize.add(new DuDeObjectPair(this.b2_Object, this.b3_Object));
		this.validResultFixPartitionSize.add(new DuDeObjectPair(this.b3_Object, this.b4_Object));
		this.validResultFixPartitionSize.add(new DuDeObjectPair(this.b4_Object, this.c1_Object));
		this.validResultFixPartitionSize.add(new DuDeObjectPair(this.b4_Object, this.c2_Object));
		this.validResultFixPartitionSize.add(new DuDeObjectPair(this.c1_Object, this.c2_Object));
		this.validResultFixPartitionSize.add(new DuDeObjectPair(this.c2_Object, this.c3_Object));
		this.validResultFixPartitionSize.add(new DuDeObjectPair(this.c3_Object, this.d1_Object));
		this.validResultFixPartitionSize.add(new DuDeObjectPair(this.c3_Object, this.d2_Object));
		this.validResultFixPartitionSize.add(new DuDeObjectPair(this.d1_Object, this.d2_Object));	
		
		// Expected result for MaxSizeNewPartition variant
		this.validResultMaxSizeNewPartition.add(new DuDeObjectPair(this.a1_Object, this.a2_Object));
		this.validResultMaxSizeNewPartition.add(new DuDeObjectPair(this.a1_Object, this.a3_Object));
		this.validResultMaxSizeNewPartition.add(new DuDeObjectPair(this.a2_Object, this.a3_Object));
		this.validResultMaxSizeNewPartition.add(new DuDeObjectPair(this.a3_Object, this.b1_Object));
		this.validResultMaxSizeNewPartition.add(new DuDeObjectPair(this.b1_Object, this.b2_Object));
		this.validResultMaxSizeNewPartition.add(new DuDeObjectPair(this.b1_Object, this.b3_Object));
		this.validResultMaxSizeNewPartition.add(new DuDeObjectPair(this.b2_Object, this.b3_Object));
		this.validResultMaxSizeNewPartition.add(new DuDeObjectPair(this.b3_Object, this.b4_Object));
		this.validResultMaxSizeNewPartition.add(new DuDeObjectPair(this.b4_Object, this.c1_Object));
		this.validResultMaxSizeNewPartition.add(new DuDeObjectPair(this.c1_Object, this.c2_Object));
		this.validResultMaxSizeNewPartition.add(new DuDeObjectPair(this.c1_Object, this.c3_Object));
		this.validResultMaxSizeNewPartition.add(new DuDeObjectPair(this.c2_Object, this.c3_Object));
		this.validResultMaxSizeNewPartition.add(new DuDeObjectPair(this.c3_Object, this.d1_Object));
		this.validResultMaxSizeNewPartition.add(new DuDeObjectPair(this.d1_Object, this.d2_Object));
		
		// Expected result for MaxSizeSlideWindow variant
		this.validResultMaxSizeSlideWindow.add(new DuDeObjectPair(this.a1_Object, this.a2_Object));
		this.validResultMaxSizeSlideWindow.add(new DuDeObjectPair(this.a1_Object, this.a3_Object));
		this.validResultMaxSizeSlideWindow.add(new DuDeObjectPair(this.a2_Object, this.a3_Object));
		this.validResultMaxSizeSlideWindow.add(new DuDeObjectPair(this.a3_Object, this.b1_Object));
		this.validResultMaxSizeSlideWindow.add(new DuDeObjectPair(this.b1_Object, this.b2_Object));
		this.validResultMaxSizeSlideWindow.add(new DuDeObjectPair(this.b1_Object, this.b3_Object));
		this.validResultMaxSizeSlideWindow.add(new DuDeObjectPair(this.b2_Object, this.b3_Object));
		this.validResultMaxSizeSlideWindow.add(new DuDeObjectPair(this.b2_Object, this.b4_Object));
		this.validResultMaxSizeSlideWindow.add(new DuDeObjectPair(this.b3_Object, this.b4_Object));
		this.validResultMaxSizeSlideWindow.add(new DuDeObjectPair(this.b4_Object, this.c1_Object));
		this.validResultMaxSizeSlideWindow.add(new DuDeObjectPair(this.c1_Object, this.c2_Object));
		this.validResultMaxSizeSlideWindow.add(new DuDeObjectPair(this.c1_Object, this.c3_Object));
		this.validResultMaxSizeSlideWindow.add(new DuDeObjectPair(this.c2_Object, this.c3_Object));
		this.validResultMaxSizeSlideWindow.add(new DuDeObjectPair(this.c3_Object, this.d1_Object));
		this.validResultMaxSizeSlideWindow.add(new DuDeObjectPair(this.d1_Object, this.d2_Object));
	}
	
	/**
	 * Tests the Basic variant of SortedBlocks
	 */
	@Test
	public void testBasic() {
		AlgorithmVariant variant = AlgorithmVariant.Basic;
		int overlap = 2;
		SortedBlocks algorithm = new SortedBlocks(variant, this.sortingKey, overlap);
		algorithm.enableInMemoryProcessing();
		algorithm.setCharBlockKey(3);
		
		Iterator<DuDeObjectPair> iterator = algorithm.iterator();
		assertFalse(iterator.hasNext());
		
		algorithm.addDataSource(this.dataSource);
		
		iterator = algorithm.iterator();
		Iterator<DuDeObjectPair> validResultIterator = this.validResultBasic.iterator();

		for (int i = 0; i < this.validResultBasic.size(); ++i) {
			assertTrue("Error at iteration step: " + i, iterator.hasNext());

			DuDeObjectPair currentPair = null;
			try {
				currentPair = iterator.next();
			} catch (NoSuchElementException e) {
				fail("NoSuchElementException occurred...");
			}

			assertEquals("Error at iteration step: " + i, validResultIterator.next(), currentPair);
		}

		assertFalse(iterator.hasNext());		
	}
	
	
	/**
	 * Tests the fix partition size variant of SortedBlocks
	 */
	@Test
	public void testFixPartitionSize() {
		AlgorithmVariant variant = AlgorithmVariant.FixPartitionSize;
		int overlap = 1;
		SortedBlocks algorithm = new SortedBlocks(variant, this.sortingKey, overlap);
		algorithm.enableInMemoryProcessing();
		algorithm.setFixBlockSize(3);
		
		Iterator<DuDeObjectPair> iterator = algorithm.iterator();
		assertFalse(iterator.hasNext());
		
		algorithm.addDataSource(this.dataSource);
		
		iterator = algorithm.iterator();
		Iterator<DuDeObjectPair> validResultIterator = this.validResultFixPartitionSize.iterator();

		for (int i = 0; i < this.validResultFixPartitionSize.size(); ++i) {
			assertTrue("Error at iteration step: " + i, iterator.hasNext());

			DuDeObjectPair currentPair = null;
			try {
				currentPair = iterator.next();
			} catch (NoSuchElementException e) {
				fail("NoSuchElementException occurred...");
			}

			assertEquals("Error at iteration step: " + i, validResultIterator.next(), currentPair);
		}

		assertFalse(iterator.hasNext());		
	}
	
	/**
	 * Tests the MaxSizeNewPartition variant of SortedBlocks
	 */
	@Test
	public void testMaxSizeNewPartition() {
		AlgorithmVariant variant = AlgorithmVariant.MaxSizeNewPartition;
		int overlap = 1;
		SortedBlocks algorithm = new SortedBlocks(variant, this.sortingKey, overlap);
		algorithm.enableInMemoryProcessing();
		algorithm.setCharBlockKey(3);
    	algorithm.setMaxBlockSize(3);		
		
		Iterator<DuDeObjectPair> iterator = algorithm.iterator();
		assertFalse(iterator.hasNext());
		
		algorithm.addDataSource(this.dataSource);
		
		iterator = algorithm.iterator();
		Iterator<DuDeObjectPair> validResultIterator = this.validResultMaxSizeNewPartition.iterator();

		for (int i = 0; i < this.validResultMaxSizeNewPartition.size(); ++i) {
			assertTrue("Error at iteration step: " + i, iterator.hasNext());

			DuDeObjectPair currentPair = null;
			try {
				currentPair = iterator.next();
			} catch (NoSuchElementException e) {
				fail("NoSuchElementException occurred...");
			}

			assertEquals("Error at iteration step: " + i, validResultIterator.next(), currentPair);
		}

		assertFalse(iterator.hasNext());		
	}
	
	/**
	 * Tests the MaxSizeNewPartition variant of SortedBlocks
	 */
	@Test
	public void testMaxSizeSlideWindow() {
		AlgorithmVariant variant = AlgorithmVariant.MaxSizeSlideWindow;
		int overlap = 1;
		SortedBlocks algorithm = new SortedBlocks(variant, this.sortingKey, overlap);
		algorithm.enableInMemoryProcessing();
		algorithm.setCharBlockKey(3);
    	algorithm.setMaxBlockSize(3);		
		
		Iterator<DuDeObjectPair> iterator = algorithm.iterator();
		assertFalse(iterator.hasNext());
		
		algorithm.addDataSource(this.dataSource);
		
		iterator = algorithm.iterator();
		Iterator<DuDeObjectPair> validResultIterator = this.validResultMaxSizeSlideWindow.iterator();

		for (int i = 0; i < this.validResultMaxSizeSlideWindow.size(); ++i) {
			assertTrue("Error at iteration step: " + i, iterator.hasNext());

			DuDeObjectPair currentPair = null;
			try {
				currentPair = iterator.next();
			} catch (NoSuchElementException e) {
				fail("NoSuchElementException occurred...");
			}

			assertEquals("Error at iteration step: " + i, validResultIterator.next(), currentPair);
		}

		assertFalse(iterator.hasNext());		
	}

}
