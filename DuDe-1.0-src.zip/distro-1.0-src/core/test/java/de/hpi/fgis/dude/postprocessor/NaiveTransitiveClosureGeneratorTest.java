/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.postprocessor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.util.data.DuDeObject;
import de.hpi.fgis.dude.util.data.DuDeObjectPair;
import de.hpi.fgis.dude.util.data.DuDeObjectPair.GeneratedBy;
import de.hpi.fgis.dude.util.data.json.JsonNumber;
import de.hpi.fgis.dude.util.data.json.JsonRecord;
import de.hpi.fgis.dude.util.data.json.JsonString;

/**
 * Tests the {@link NaiveTransitiveClosureGenerator} class.
 * 
 * @author Matthias Pohl
 */
public class NaiveTransitiveClosureGeneratorTest {

	private DuDeObject firstObj;
	private DuDeObject secondObj;
	private DuDeObject thirdObj;
	private DuDeObject fourthObj;
	private DuDeObject fifthObj;

	private DuDeObjectPair firstPairClosure1;
	private DuDeObjectPair secondPairClosure1;
	
	private DuDeObjectPair thirdPairClosure1;

	private DuDeObjectPair firstPairClosure2;

	private DuDeObjectPair singlePair;

	private final Collection<DuDeObjectPair> pairCollection = new ArrayList<DuDeObjectPair>();

	private final Collection<DuDeObjectPair> actualResult = new HashSet<DuDeObjectPair>();

	/**
	 * The preset of each test method.
	 * 
	 * @throws Exception
	 *             If an error occurs while initializing the test methods.
	 */
	@Before
	public void setUp() throws Exception {
		JsonRecord obj = new JsonRecord();
		obj.put("ID", new JsonNumber(0));
		obj.put("first", new JsonString("Peter"));
		obj.put("last", new JsonString("Pan"));

		this.firstObj = new DuDeObject(obj, "", "0");

		obj = new JsonRecord();
		obj.put("ID", new JsonNumber(1));
		obj.put("first", new JsonString("Pippi"));
		obj.put("last", new JsonString("Langstrumpf"));

		this.secondObj = new DuDeObject(obj, "", "1");

		obj = new JsonRecord();
		obj.put("ID", new JsonNumber(2));
		obj.put("first", new JsonString("Kalle"));
		obj.put("last", new JsonString("Blomquist"));

		this.thirdObj = new DuDeObject(obj, "", "2");

		obj = new JsonRecord();
		obj.put("ID", new JsonNumber(3));
		obj.put("first", new JsonString("Benjamin"));
		obj.put("last", new JsonString("Bluemchen"));

		this.fourthObj = new DuDeObject(obj, "", "3");

		obj = new JsonRecord();
		obj.put("ID", new JsonNumber(4));
		obj.put("first", new JsonString("Feivel"));
		obj.put("last", new JsonString("der Mauswanderer"));

		this.fifthObj = new DuDeObject(obj, "", "4");

		this.firstPairClosure1 = new DuDeObjectPair(this.firstObj, this.secondObj);
		this.firstPairClosure1.setLineage(GeneratedBy.Algorithm);
		this.secondPairClosure1 = new DuDeObjectPair(this.firstObj, this.thirdObj);
		this.secondPairClosure1.setLineage(GeneratedBy.Algorithm);
		
		this.thirdPairClosure1 = new DuDeObjectPair(this.secondObj, this.thirdObj);
		this.thirdPairClosure1.setLineage(GeneratedBy.TransitiveClosure);

		this.firstPairClosure2 = new DuDeObjectPair(this.fourthObj, this.fifthObj);
		this.firstPairClosure2.setLineage(GeneratedBy.Algorithm);
		
		this.singlePair = this.firstPairClosure1;

		this.pairCollection.add(this.secondPairClosure1);
		this.pairCollection.add(this.firstPairClosure2);

		this.actualResult.add(this.firstPairClosure1);
		this.actualResult.add(this.secondPairClosure1);
		
		this.actualResult.add(this.thirdPairClosure1);
		
		this.actualResult.add(this.firstPairClosure2);
	}

	/**
	 * Tests {@link NaiveTransitiveClosureGenerator#getTransitiveClosures()}.
	 */
	@Test
	public void testGetTransitiveClosures() {
		NaiveTransitiveClosureGenerator transitiveClosureGenerator = new NaiveTransitiveClosureGenerator();

		transitiveClosureGenerator.add(this.singlePair);
		transitiveClosureGenerator.add(this.pairCollection);

		@SuppressWarnings("unchecked")
		// the cast is valid
		Collection<Collection<DuDeObject>> transitiveClosures = (Collection<Collection<DuDeObject>>) transitiveClosureGenerator
				.getTransitiveClosures();

		Iterator<Collection<DuDeObject>> transitiveClosuresIterator = transitiveClosures.iterator();

		assertTrue(transitiveClosuresIterator.hasNext());

		Collection<DuDeObject> transitiveClosure = transitiveClosuresIterator.next();

		if (transitiveClosure.size() == 2) {
			// 2-element transitive closure returned first
			assertTrue(transitiveClosure.contains(this.fourthObj));
			assertTrue(transitiveClosure.contains(this.fifthObj));

			assertFalse(transitiveClosure.contains(this.firstObj));
			assertFalse(transitiveClosure.contains(this.secondObj));
			assertFalse(transitiveClosure.contains(this.thirdObj));

			assertTrue(transitiveClosuresIterator.hasNext());
			transitiveClosure = transitiveClosuresIterator.next();

			assertEquals(3, transitiveClosure.size());

			assertTrue(transitiveClosure.contains(this.firstObj));
			assertTrue(transitiveClosure.contains(this.secondObj));
			assertTrue(transitiveClosure.contains(this.thirdObj));

			assertFalse(transitiveClosure.contains(this.fourthObj));
			assertFalse(transitiveClosure.contains(this.fifthObj));

			assertFalse(transitiveClosuresIterator.hasNext());
		} else if (transitiveClosure.size() == 3) {
			// 3-element transitive closure returned first
			assertTrue(transitiveClosure.contains(this.firstObj));
			assertTrue(transitiveClosure.contains(this.secondObj));
			assertTrue(transitiveClosure.contains(this.thirdObj));

			assertFalse(transitiveClosure.contains(this.fourthObj));
			assertFalse(transitiveClosure.contains(this.fifthObj));

			assertTrue(transitiveClosuresIterator.hasNext());
			transitiveClosure = transitiveClosuresIterator.next();

			assertEquals(2, transitiveClosure.size());

			assertTrue(transitiveClosure.contains(this.fourthObj));
			assertTrue(transitiveClosure.contains(this.fifthObj));

			assertFalse(transitiveClosure.contains(this.firstObj));
			assertFalse(transitiveClosure.contains(this.secondObj));
			assertFalse(transitiveClosure.contains(this.thirdObj));

			assertFalse(transitiveClosuresIterator.hasNext());
		} else {
			fail("A transitive closure with an invalid size was created: " + transitiveClosure.size());
		}
	}

	/**
	 * Tests iterator implementation of {@link NaiveTransitiveClosureGenerator}.
	 */
	@Test
	public void testIterator() {
		NaiveTransitiveClosureGenerator transitiveClosureGenerator = new NaiveTransitiveClosureGenerator();

		assertFalse(transitiveClosureGenerator.iterator().hasNext());

		transitiveClosureGenerator.add(this.singlePair);
		transitiveClosureGenerator.add(this.pairCollection);

		Iterator<DuDeObjectPair> iterator = transitiveClosureGenerator.iterator();
		Iterator<DuDeObjectPair> iterator_inParallel = transitiveClosureGenerator.iterator();

		for (int i = 0; i < this.actualResult.size(); ++i) {
			assertTrue(iterator.hasNext());
			DuDeObjectPair pair = iterator.next();
			assertTrue(this.actualResult.contains(pair));
			if (pair.equals(this.thirdPairClosure1)) {
				assertEquals(GeneratedBy.TransitiveClosure, pair.getLineage());
			} else {
				assertEquals(GeneratedBy.Algorithm, pair.getLineage());
			}
			
			assertTrue(iterator_inParallel.hasNext());
			DuDeObjectPair pair_inParallel = iterator_inParallel.next();
			assertTrue(this.actualResult.contains(pair_inParallel));
			if (pair_inParallel.equals(this.thirdPairClosure1)) {
				assertEquals(GeneratedBy.TransitiveClosure, pair_inParallel.getLineage());
			} else {
				assertEquals(GeneratedBy.Algorithm, pair_inParallel.getLineage());
			}
		}

		assertFalse(iterator.hasNext());
		try {
			iterator.next();
			fail("NoSuchElementException should have been thrown...");
		} catch (NoSuchElementException e) {
			// nothing to do
		}
		
		assertFalse(iterator_inParallel.hasNext());
		try {
			iterator_inParallel.next();
			fail("NoSuchElementException should have been thrown...");
		} catch (NoSuchElementException e) {
			// nothing to do
		}
	}

}
