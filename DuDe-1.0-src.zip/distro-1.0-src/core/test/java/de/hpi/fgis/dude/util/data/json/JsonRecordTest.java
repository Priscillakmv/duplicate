/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.util.data.json;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.LinkedList;
import java.util.TreeMap;

import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.util.data.json.JsonValue.JsonType;

/**
 * Tests {@link JsonRecord}.
 * 
 * @author Matthias Pohl
 */
public class JsonRecordTest {
	
	private JsonRecord record;
	
	private JsonRecord subrecord1;
	private JsonRecord subrecord2;
	private JsonRecord subrecord3;
	private JsonRecord subrecord4;
	
	private JsonString finalAttribute = new JsonString("checked");
	private JsonString stringAttribute = new JsonString("String");
	private JsonNumber integerAttribute = new JsonNumber(1);

	/**
	 * The preset of each test method.
	 * 
	 * @throws Exception
	 *             If an error occurs while initializing the test methods.
	 */
	@Before
	public void setUp() throws Exception {
		this.record = new JsonRecord();
		
		this.subrecord4 = new JsonRecord();
		this.subrecord4.put("path", this.finalAttribute);
		
		this.subrecord3 = new JsonRecord();
		this.subrecord3.put("attribute", this.subrecord4);
		
		this.subrecord2 = new JsonRecord();
		this.subrecord2.put("an", this.subrecord3);
		
		this.subrecord1 = new JsonRecord();
		this.subrecord1.put("anotherAttr", this.stringAttribute);
		this.subrecord1.put("is", this.subrecord2);
		
		this.record.put("this", this.subrecord1);
		this.record.put("attr", this.integerAttribute);
	}

	/**
	 * Tests {@link JsonRecord#getType()}.
	 */
	@Test
	public void testGetType() {
		assertEquals(JsonType.Record, this.record.getType());
	}

	/**
	 * Tests {@link JsonRecord#compareTo(JsonValue)}.
	 */
	@Test
	public void testCompareTo() {
		assertEquals(this.record.compareTo(this.record), 0);
		assertTrue(this.record.compareTo(null) > 0);
		assertTrue(this.record.compareTo(JsonNull.NULL) > 0);
		assertTrue(this.record.compareTo(new JsonArray()) > 0);
		assertTrue(this.record.compareTo(JsonBoolean.TRUE) > 0);
		assertTrue(this.record.compareTo(JsonBoolean.FALSE) > 0);
		assertTrue(this.record.compareTo(this.integerAttribute) > 0);
		assertTrue(this.record.compareTo(this.finalAttribute) < 0);
		
		assertTrue(this.record.compareTo(new JsonRecord()) > 0);
		assertTrue(this.record.compareTo(this.subrecord1) > 0);
		assertTrue(this.record.compareTo(this.subrecord2) > 0);
		assertTrue(this.record.compareTo(this.subrecord3) < 0);
		assertTrue(this.record.compareTo(this.subrecord4) < 0);
	}

	/**
	 * Tests {@link JsonRecord#searchFor(String)}.
	 */
	@Test
	public void testSearchFor() {
		assertNull(this.record.searchFor("notfound"));
		assertEquals(this.subrecord1, this.record.searchFor("this"));
		assertEquals(this.subrecord2, this.record.searchFor("is"));
		assertEquals(this.finalAttribute, this.record.searchFor("path"));
		assertEquals(this.integerAttribute, this.record.searchFor("attr"));
		assertEquals(this.stringAttribute, this.record.searchFor("anotherAttr"));
	}

	/**
	 * Tests {@link JsonRecord#getJsonValue(String[])}.
	 */
	@Test
	public void testGetJsonValueStringArray() {
		assertEquals(this.finalAttribute, this.record.getJsonValue("this", "is", "an", "attribute", "path"));
		assertEquals(this.subrecord1, this.record.getJsonValue("this"));
		assertEquals(this.integerAttribute, this.record.getJsonValue("attr"));
		assertNull(this.record.getJsonValue("this", "is", "not", "valid"));
		assertNull(this.record.getJsonValue("this", "attr"));
		assertNull(this.record.getJsonValue("this", "path"));
	}

	/**
	 * Tests {@link JsonRecord#generateString()}.
	 */
	@Test
	public void testGenerateString() {
		assertTrue(this.record.generateString().indexOf("checked") > -1);
		assertTrue(this.record.generateString().indexOf("String") > -1);
		assertTrue(this.record.generateString().indexOf("1") > -1);
	}

	/**
	 * Tests {@link JsonRecord#put(String, JsonValue)}.
	 */
	@Test
	public void testPutStringJsonValue() {
		final String key = "key";
		
		assertNull(this.record.putNull(key));
		assertEquals(JsonNull.NULL, this.record.put(key, true));
		assertEquals(JsonBoolean.TRUE, this.record.put(key, false));
		assertEquals(JsonBoolean.FALSE, this.record.put(key, new JsonNumber(1)));
		assertEquals(new JsonNumber(1), this.record.put(key, new JsonNumber(2L)));
		assertEquals(new JsonNumber(2L), this.record.put(key, new JsonNumber(3.3)));
		assertEquals(new JsonNumber(3.3), this.record.put(key, new JsonString("text")));
		assertEquals(new JsonString("text"), this.record.putCollection(key, new LinkedList<JsonValue>()));
		assertEquals(new JsonArray(), this.record.putMap(key, new TreeMap<String, JsonValue>()));
		assertEquals(new JsonRecord(), this.record.put(key, (JsonValue) null));
		assertEquals(JsonNull.NULL, this.record.get(key));
	}

}
