/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.util.sorting;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.util.data.DuDeObject;
import de.hpi.fgis.dude.util.data.json.JsonArray;
import de.hpi.fgis.dude.util.data.json.JsonNull;
import de.hpi.fgis.dude.util.data.json.JsonNumber;
import de.hpi.fgis.dude.util.data.json.JsonRecord;
import de.hpi.fgis.dude.util.data.json.JsonString;
import de.hpi.fgis.dude.util.data.json.JsonValue;
import de.hpi.fgis.dude.util.sorting.sortingkey.Subkey;
import de.hpi.fgis.dude.util.sorting.sortingkey.TextBasedSubkey;

/**
 * Tests the {@link TextBasedSubkey} class.
 * 
 * @author Matthias Pohl
 */
public class TextBasedSubkeyTest {

	private static final String ATTRIBUTE_NAME = "attr";

	private TextBasedSubkey subkey;

	private Map<JsonValue, JsonValue[]> subkeys;
	private JsonValue[] orderedValues;
	private Collection<JsonValue[]> equalValues;

	private static DuDeObject createDuDeObject(JsonValue value) {
		JsonRecord data = new JsonRecord();
		if (value != null) {
			data.put(TextBasedSubkeyTest.ATTRIBUTE_NAME, value);
		}

		return new DuDeObject(data, "", new JsonArray(value));
	}

	private static DuDeObject createDuDeObject(String str) {
		return TextBasedSubkeyTest.createDuDeObject(new JsonString(str));
	}

	private static JsonValue[] convertIntoJsonValues(String... values) {
		JsonValue[] jsonValues = new JsonValue[values.length];
		for (int i = 0; i < values.length; i++) {
			jsonValues[i] = new JsonString(values[i]);
		}

		return jsonValues;
	}

	private static void testOrder(Subkey subkey, JsonValue... values) {
		for (int i = 0; i < values.length - 1; i++) {
			assertTrue("Invalid comparison: " + values[i] + " < " + values[i + 1],
					subkey.compare(TextBasedSubkeyTest.createDuDeObject(values[i]), TextBasedSubkeyTest.createDuDeObject(values[i + 1])) < 0);
		}
	}

	private static void testOrder(Subkey subkey, String... values) {
		TextBasedSubkeyTest.testOrder(subkey, TextBasedSubkeyTest.convertIntoJsonValues(values));
	}

	private static void testEquality(Subkey subkey, JsonValue... values) {
		for (int i = 0; i < values.length - 1; i++) {
			assertEquals("Invalid comparison: " + values[i] + " == " + values[i + 1], 0,
					subkey.compare(TextBasedSubkeyTest.createDuDeObject(values[i]), TextBasedSubkeyTest.createDuDeObject(values[i + 1])));
		}
	}

	private static void testEquality(Subkey subkey, String... values) {
		TextBasedSubkeyTest.testEquality(subkey, TextBasedSubkeyTest.convertIntoJsonValues(values));
	}

	private void addSubkeyValues(JsonValue actualAttributeValue, JsonValue... subkeyValues) {
		this.subkeys.put(actualAttributeValue, subkeyValues);
	}

	private void setOrderedValues(JsonValue... values) {
		this.orderedValues = values;
	}

	private void addEqualValues(JsonValue... values) {
		this.equalValues.add(values);
	}

	/**
	 * Initializes the test environment.
	 */
	@Before
	public void setUp() {
		this.subkeys = new HashMap<JsonValue, JsonValue[]>();
		this.equalValues = new ArrayList<JsonValue[]>();
	}

	/**
	 * Runs the actual tests.
	 */
	@After
	public void runTests() {
		for (Map.Entry<JsonValue, JsonValue[]> subkeyData : this.subkeys.entrySet()) {
			JsonArray expectedSubkey = new JsonArray(Arrays.asList(subkeyData.getValue()));
			JsonArray actualSubkey = this.subkey.getSubkeyValue(TextBasedSubkeyTest.createDuDeObject(subkeyData.getKey()));

			assertEquals(expectedSubkey, actualSubkey);
		}

		for (JsonValue[] equalValues : this.equalValues) {
			TextBasedSubkeyTest.testEquality(this.subkey, equalValues);
		}

		TextBasedSubkeyTest.testOrder(this.subkey, this.orderedValues);
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String)}.
	 */
	@Test
	public void testString() {
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);

		this.addSubkeyValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));
		this.addSubkeyValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));

		this.addEqualValues(null, null);
		this.addEqualValues(JsonNull.NULL, JsonNull.NULL);
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));

		this.setOrderedValues((JsonValue) null, JsonNull.NULL, new JsonNumber(0), new JsonNumber(1), new JsonString("ASDASDASD"), new JsonString(
				"aaaazzzzz"), new JsonString("asdasdasd"));

		TextBasedSubkeyTest.testOrder(this.subkey, "ASD", "asd");

		assertTrue(this.subkey.caseSensitivityEnabled());
		this.subkey.disableCaseSensitivity();
		assertFalse(this.subkey.caseSensitivityEnabled());

		TextBasedSubkeyTest.testEquality(this.subkey, "ASD", "asd");

		this.subkey.enableCaseSensitivity();
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String, String)} with no vowels.
	 * 
	 * @see TextBasedSubkey#NO_VOWELS_REGEX
	 */
	@Test
	public void testStringStringWithoutVowels() {
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME, TextBasedSubkey.NO_VOWELS_REGEX);

		this.addSubkeyValues(new JsonString("asdasdasd"), new JsonString("sdsdsd"));
		this.addSubkeyValues(new JsonString("aaaazzzzz"), new JsonString("zzzzz"));

		this.addEqualValues(null, null);
		this.addEqualValues(JsonNull.NULL, JsonNull.NULL);
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));

		this.setOrderedValues((JsonValue) null, JsonNull.NULL, new JsonNumber(0), new JsonNumber(1), new JsonString("ASDASDASD"), new JsonString(
				"asdasdasd"), new JsonString("aaaazzzzz"));
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String, String)} with ignoring 's' and 'A'.
	 */
	@Test
	public void testStringStringWithoutsA() {
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME, "[s|A]");

		this.addSubkeyValues(new JsonString("asdasdasd"), new JsonString("adadad"));
		this.addSubkeyValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));

		this.addEqualValues(null, null);
		this.addEqualValues(JsonNull.NULL, JsonNull.NULL);
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));

		this.setOrderedValues((JsonValue) null, JsonNull.NULL, new JsonNumber(0), new JsonNumber(1), new JsonString("ASDASDASD"), new JsonString(
				"aaaazzzzz"), new JsonString("asdasdasd"));

		// case-sensitivity enabled -> Asd > asd (since 'A' will be erased)
		assertTrue(this.subkey.compare(TextBasedSubkeyTest.createDuDeObject("Asd"), TextBasedSubkeyTest.createDuDeObject("asd")) > 0);
		this.subkey.disableCaseSensitivity();
		// case-sensitivity disabled -> Asd == asd (since 'A' and 'a' will be erased)
		assertEquals(0, this.subkey.compare(TextBasedSubkeyTest.createDuDeObject("Asd"), TextBasedSubkeyTest.createDuDeObject("asd")));

		// enable case-sensitivity for #runTests
		this.subkey.enableCaseSensitivity();
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String)} and a range starting at <code>20</code>.
	 */
	@Test
	public void testStringRange20() {
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);
		this.subkey.setRange(20);

		this.addSubkeyValues(new JsonString("asdasdasd"), new JsonString(""));
		this.addSubkeyValues(new JsonString("aaaazzzzz"), new JsonString(""));

		this.addEqualValues(null, null);
		this.addEqualValues(JsonNull.NULL, JsonNull.NULL);
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));

		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("aaaazzzzz"));

		this.setOrderedValues((JsonValue) null, JsonNull.NULL, new JsonNumber(0), new JsonString("asdasdasd"));
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String)} and a range starting at <code>3</code>.
	 */
	@Test
	public void testStringRange3() {
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);
		this.subkey.setRange(3);

		this.addSubkeyValues(new JsonString("asdasdasd"), new JsonString("asdasd"));
		this.addSubkeyValues(new JsonString("aaaazzzzz"), new JsonString("azzzzz"));

		this.addEqualValues(null, null);
		this.addEqualValues(JsonNull.NULL, JsonNull.NULL);
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));

		this.addEqualValues(new JsonString("BLAasdasd"), new JsonString("asdasdasd"));

		this.setOrderedValues((JsonValue) null, JsonNull.NULL, new JsonNumber(0), new JsonNumber(20000), new JsonNumber(10011), new JsonString(
				"asdasdasd"), new JsonString("aaaazzzzz"));
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String)} and a range starting at <code>-4</code>.
	 */
	@Test
	public void testStringRangeNegative4() {
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);
		this.subkey.setRange(-4);

		this.addSubkeyValues(new JsonString("asdasdasd"), new JsonString("dasd"));
		this.addSubkeyValues(new JsonString("aaaazzzzz"), new JsonString("zzzz"));

		this.addEqualValues(null, null);
		this.addEqualValues(JsonNull.NULL, JsonNull.NULL);
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));

		this.addEqualValues(new JsonString("BLAasdasd"), new JsonString("asdasdasd"));

		this.setOrderedValues((JsonValue) null, JsonNull.NULL, new JsonNumber(0), new JsonNumber(20000), new JsonNumber(10001), new JsonString(
				"asdasdasd"), new JsonString("aaaazzzzz"));
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String)} and a range starting at <code>0</code> and a length of <code>20</code>.
	 */
	@Test
	public void testStringRange0Length20() {
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);
		this.subkey.setRange(0, 20);

		this.addSubkeyValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));
		this.addSubkeyValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));

		this.addEqualValues(null, null);
		this.addEqualValues(JsonNull.NULL, JsonNull.NULL);
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));

		this.setOrderedValues((JsonValue) null, JsonNull.NULL, new JsonNumber(0), new JsonNumber(1), new JsonString("ASDASDASD"), new JsonString(
				"aaaazzzzz"), new JsonString("asdasdasd"));
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String)} and a range starting at <code>3</code> and a length of <code>20</code>.
	 */
	@Test
	public void testStringRange3Length20() {
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);
		this.subkey.setRange(3, 20);

		this.addSubkeyValues(new JsonString("asdasdasd"), new JsonString("asdasd"));
		this.addSubkeyValues(new JsonString("aaaazzzzz"), new JsonString("azzzzz"));

		this.addEqualValues(null, null);
		this.addEqualValues(JsonNull.NULL, JsonNull.NULL);
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));

		this.addEqualValues(new JsonString("BLAasdasd"), new JsonString("asdasdasd"));

		this.setOrderedValues((JsonValue) null, JsonNull.NULL, new JsonNumber(0), new JsonNumber(20000), new JsonNumber(10011), new JsonString(
				"asdasdasd"), new JsonString("aaaazzzzz"));
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String)} and a range starting at <code>-4</code> and a length of <code>20</code>.
	 */
	@Test
	public void testStringRangeNegative4Length20() {
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);
		this.subkey.setRange(-4, 20);

		this.addSubkeyValues(new JsonString("asdasdasd"), new JsonString("dasd"));
		this.addSubkeyValues(new JsonString("aaaazzzzz"), new JsonString("zzzz"));

		this.addEqualValues(null, null);
		this.addEqualValues(JsonNull.NULL, JsonNull.NULL);
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));

		this.addEqualValues(new JsonString("BLAasdasd"), new JsonString("asdasdasd"));

		this.setOrderedValues((JsonValue) null, JsonNull.NULL, new JsonNumber(0), new JsonNumber(20000), new JsonNumber(10001), new JsonString(
				"asdasdasd"), new JsonString("aaaazzzzz"));
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String)} and a range starting at <code>3</code> and a length of <code>2</code>.
	 */
	@Test
	public void testStringRange3Length2() {
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);
		this.subkey.setRange(3, 2);

		this.addSubkeyValues(new JsonString("asdasdasd"), new JsonString("as"));
		this.addSubkeyValues(new JsonString("aaaazzzzz"), new JsonString("az"));

		this.addEqualValues(null, null);
		this.addEqualValues(JsonNull.NULL, JsonNull.NULL);
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));

		this.addEqualValues(new JsonString("BLAasBLABLA"), new JsonString("asdasdasd"));

		this.setOrderedValues((JsonValue) null, JsonNull.NULL, new JsonNumber(0), new JsonNumber(20000), new JsonNumber(10001), new JsonString(
				"asdasdasd"), new JsonString("aaaazzzzz"));
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String)} and a range starting at <code>-4</code> and a length of <code>2</code>.
	 */
	@Test
	public void testStringRangeNegative4Length2() {
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);
		this.subkey.setRange(-4, 2);

		this.addSubkeyValues(new JsonString("asdasdasd"), new JsonString("da"));
		this.addSubkeyValues(new JsonString("aaaazzzzz"), new JsonString("zz"));

		this.addEqualValues(null, null);
		this.addEqualValues(JsonNull.NULL, JsonNull.NULL);
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));

		this.addEqualValues(new JsonString("BLAasST"), new JsonString("asdasda"));

		this.setOrderedValues((JsonValue) null, JsonNull.NULL, new JsonNumber(0), new JsonNumber(20000), new JsonNumber(10101), new JsonString(
				"asdasdasd"), new JsonString("aaaazzzzz"));
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String)} and a range with negative length.
	 */
	@Test
	public void testStringRangeNegativeLength() {
		try {
			this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);
			this.subkey.setRange(-1, -2);
			fail("IllegalArgumentException should have been thrown...");
		} catch (IllegalArgumentException e) {
			// nothing to do
		}

		// initialize members in order to rum #runTests without errors
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);
		this.setOrderedValues();
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String)} and a range starting at <code>0</code> and a length of <code>20</code> ignoring all
	 * vowels.
	 */
	@Test
	public void testStringRange0Length20NoVowels() {
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);
		this.subkey.setIgnoredCharactersRegEx(TextBasedSubkey.NO_VOWELS_REGEX);
		this.subkey.setRange(0, 20);

		this.addSubkeyValues(new JsonString("asdasdasd"), new JsonString("sdsdsd"));
		this.addSubkeyValues(new JsonString("aaaazzzzz"), new JsonString("zzzzz"));

		this.addEqualValues(null, null);
		this.addEqualValues(JsonNull.NULL, JsonNull.NULL);
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));

		this.setOrderedValues((JsonValue) null, JsonNull.NULL, new JsonNumber(0), new JsonNumber(1), new JsonString("ASDASDASD"), new JsonString(
				"asdasdasd"), new JsonString("aaaazzzzz"));
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String)} and a range starting at <code>3</code> and a length of <code>20</code> ignoring all
	 * vowels.
	 */
	@Test
	public void testStringRange3Length20NoVowels() {
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);
		this.subkey.setIgnoredCharactersRegEx(TextBasedSubkey.NO_VOWELS_REGEX);
		this.subkey.setRange(3, 20);

		this.addSubkeyValues(new JsonString("asdasdasd"), new JsonString("dsd"));
		this.addSubkeyValues(new JsonString("aaaazzzzz"), new JsonString("zz"));

		this.addEqualValues(null, null);
		this.addEqualValues(JsonNull.NULL, JsonNull.NULL);
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));

		this.addEqualValues(new JsonString("BLAAsdAsd"), new JsonString("asdasdasd"));

		this.setOrderedValues((JsonValue) null, JsonNull.NULL, new JsonNumber(0), new JsonNumber(20000), new JsonNumber(10011), new JsonString(
				"asdasdasd"), new JsonString("aaaazzzzz"));
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String)} and a range starting at <code>-4</code> and a length of <code>20</code> ignoring all
	 * vowels.
	 */
	@Test
	public void testStringRangeNegative4Length20NoVowels() {
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);
		this.subkey.setIgnoredCharactersRegEx(TextBasedSubkey.NO_VOWELS_REGEX);
		this.subkey.setRange(-4, 20);

		this.addSubkeyValues(new JsonString("asdasdasd"), new JsonString("sdsd"));
		this.addSubkeyValues(new JsonString("aaaazzzzz"), new JsonString("zzzz"));

		this.addEqualValues(null, null);
		this.addEqualValues(JsonNull.NULL, JsonNull.NULL);
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));

		this.addEqualValues(new JsonString("BLAasdasd"), new JsonString("asdasdAsd"));

		this.setOrderedValues((JsonValue) null, JsonNull.NULL, new JsonNumber(0), new JsonNumber(20000), new JsonNumber(10001), new JsonString(
				"asdasdasd"), new JsonString("aaaazzzzz"));
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String)} and a range starting at <code>3</code> and a length of <code>2</code> ignoring all
	 * vowels.
	 */
	@Test
	public void testStringRange3Length2NoVowels() {
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);
		this.subkey.setIgnoredCharactersRegEx(TextBasedSubkey.NO_VOWELS_REGEX);
		this.subkey.setRange(3, 2);

		this.addSubkeyValues(new JsonString("asdasdasd"), new JsonString("ds"));
		this.addSubkeyValues(new JsonString("aaaazzzzz"), new JsonString("zz"));

		this.addEqualValues(null, null);
		this.addEqualValues(JsonNull.NULL, JsonNull.NULL);
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));

		this.addEqualValues(new JsonString("BLAasBLABLA"), new JsonString("mfgBLABLA"));

		this.setOrderedValues((JsonValue) null, JsonNull.NULL, new JsonNumber(0), new JsonNumber(20000), new JsonNumber(10001), new JsonString(
				"asdasdasd"), new JsonString("aaaazzzzz"));
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String)} and a range starting at <code>-4</code> and a length of <code>2</code> ignoring all
	 * vowels.
	 */
	@Test
	public void testStringRangeNegative4Length2NoVowels() {
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);
		this.subkey.setIgnoredCharactersRegEx(TextBasedSubkey.NO_VOWELS_REGEX);
		this.subkey.setRange(-4, 2);

		this.addSubkeyValues(new JsonString("asdasdasd"), new JsonString("sd"));
		this.addSubkeyValues(new JsonString("aaaazzzzz"), new JsonString("zz"));

		this.addEqualValues(null, null);
		this.addEqualValues(JsonNull.NULL, JsonNull.NULL);
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));

		this.addEqualValues(new JsonString("BLAasdasST"), new JsonString("asdasSasdasdd"));

		this.setOrderedValues((JsonValue) null, JsonNull.NULL, new JsonNumber(0), new JsonNumber(20000), new JsonNumber(10101), new JsonString(
				"asdasdasd"), new JsonString("aaaazzzzz"));
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String)} using concrete positions.
	 */
	@Test
	public void testPositions() {
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);
		this.subkey.setPositions(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

		this.addSubkeyValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));
		this.addSubkeyValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));

		this.addEqualValues(null, null);
		this.addEqualValues(JsonNull.NULL, JsonNull.NULL);
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));

		this.setOrderedValues((JsonValue) null, JsonNull.NULL, new JsonNumber(0), new JsonNumber(1), new JsonString("ASDASDASD"), new JsonString(
				"aaaazzzzz"), new JsonString("asdasdasd"));

		TextBasedSubkeyTest.testOrder(this.subkey, "ASD", "asd");

		assertTrue(this.subkey.caseSensitivityEnabled());
		this.subkey.disableCaseSensitivity();
		assertFalse(this.subkey.caseSensitivityEnabled());

		TextBasedSubkeyTest.testEquality(this.subkey, "ASD", "asd");

		this.subkey.enableCaseSensitivity();
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String)} with concrete positions <code>4</code> and <code>1</code>.
	 */
	@Test
	public void testPositions41() {
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);
		this.subkey.setPositions(4, 1);

		this.addSubkeyValues(new JsonString("asdasdasd"), new JsonString("ss"));
		this.addSubkeyValues(new JsonString("aaaazzzzz"), new JsonString("za"));

		this.addEqualValues(null, null);
		this.addEqualValues(JsonNull.NULL, JsonNull.NULL);
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));
		this.addEqualValues(new JsonString("MsJKsLKO"), new JsonString("asdasdasd"));

		this.setOrderedValues((JsonValue) null, JsonNull.NULL, new JsonNumber(11), new JsonNumber(22410), new JsonString("ASDASDASD"),
				new JsonString("asdasdasd"), new JsonString("aaaazzzzz"));

		TextBasedSubkeyTest.testOrder(this.subkey, "ASDASD", "asdasd");

		assertTrue(this.subkey.caseSensitivityEnabled());
		this.subkey.disableCaseSensitivity();
		assertFalse(this.subkey.caseSensitivityEnabled());

		TextBasedSubkeyTest.testEquality(this.subkey, "ASDASD", "asdasd");

		this.subkey.enableCaseSensitivity();
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String)} addressing the same position several times.
	 */
	@Test
	public void testPositions111() {
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);
		this.subkey.setPositions(1, 1, 1);

		this.addSubkeyValues(new JsonString("asdasdasd"), new JsonString("sss"));
		this.addSubkeyValues(new JsonString("aaaazzzzz"), new JsonString("aaa"));

		this.addEqualValues(null, null);
		this.addEqualValues(JsonNull.NULL, JsonNull.NULL);
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));
		this.addEqualValues(new JsonString("MsJKsLKO"), new JsonString("asdasdasd"));

		this.setOrderedValues((JsonValue) null, JsonNull.NULL, new JsonNumber(11), new JsonNumber(22410), new JsonString("ASDASDASD"),
				new JsonString("aaaazzzzz"), new JsonString("asdasdasd"));
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String)} if explicitly no concrete positions are set.
	 */
	@Test
	public void testNoPositions() {
		try {
			this.subkey = new TextBasedSubkey("attr");
			this.subkey.setPositions((Integer[]) null);
			fail("NullPointerException should have been thrown...");
		} catch (NullPointerException e) {
			// nothing to do
		}
		
		try {
			this.subkey = new TextBasedSubkey("attr");
			this.subkey.setPositions((Integer) null);
			fail("NullPointerException should have been thrown...");
		} catch (NullPointerException e) {
			// nothing to do
		}

		// initialize members in order to rum #runTests without errors
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);
		this.setOrderedValues();
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String)} with concrete positions <code>4</code>, <code>1</code>, and <code>-1</code>.
	 */
	@Test
	public void testPositions41Negative1() {
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);
		this.subkey.setPositions(4, 1, -1);

		this.addSubkeyValues(new JsonString("asdasdasd"), new JsonString("ssd"));
		this.addSubkeyValues(new JsonString("aaaazzzzz"), new JsonString("zaz"));

		this.addEqualValues(null, null);
		this.addEqualValues(JsonNull.NULL, JsonNull.NULL);
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));
		this.addEqualValues(new JsonString("MsJKsLd"), new JsonString("asdasdasd"));

		this.setOrderedValues((JsonValue) null, JsonNull.NULL, new JsonNumber(11), new JsonNumber(22410), new JsonString("ASDASDASD"),
				new JsonString("asdasdasd"), new JsonString("aaaazzzzz"));

		TextBasedSubkeyTest.testOrder(this.subkey, "ASDASD", "asdasd");

		assertTrue(this.subkey.caseSensitivityEnabled());
		this.subkey.disableCaseSensitivity();
		assertFalse(this.subkey.caseSensitivityEnabled());

		TextBasedSubkeyTest.testEquality(this.subkey, "ASDASD", "asdasd");

		this.subkey.enableCaseSensitivity();
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String)} using concrete positions ignoring vowels.
	 */
	@Test
	public void testPositionsNoVowels() {
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);
		this.subkey.setIgnoredCharactersRegEx(TextBasedSubkey.NO_VOWELS_REGEX);
		this.subkey.setPositions(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

		this.addSubkeyValues(new JsonString("asdasdasd"), new JsonString("sdsdsd"));
		this.addSubkeyValues(new JsonString("aaaazzzzz"), new JsonString("zzzzz"));

		this.addEqualValues(null, null);
		this.addEqualValues(JsonNull.NULL, JsonNull.NULL);
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));

		this.setOrderedValues((JsonValue) null, JsonNull.NULL, new JsonNumber(0), new JsonNumber(1), new JsonString("ASDASDASD"), new JsonString(
				"asdasdasd"), new JsonString("aaaazzzzz"));
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String)} with concrete positions <code>4</code> and <code>1</code> ignoring vowels.
	 */
	@Test
	public void testPositions41NoVowels() {
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);
		this.subkey.setIgnoredCharactersRegEx(TextBasedSubkey.NO_VOWELS_REGEX);
		this.subkey.setPositions(4, 1);

		this.addSubkeyValues(new JsonString("asdasdasd"), new JsonString("sd"));
		this.addSubkeyValues(new JsonString("aaaazzzzz"), new JsonString("zz"));

		this.addEqualValues(null, null);
		this.addEqualValues(JsonNull.NULL, JsonNull.NULL);
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));
		this.addEqualValues(new JsonString("MdJKsLKO"), new JsonString("asdasdasd"));

		this.setOrderedValues((JsonValue) null, JsonNull.NULL, new JsonNumber(11), new JsonNumber(22410), new JsonString("ASDASDASD"),
				new JsonString("asdasdasd"), new JsonString("aaaazzzzz"));
	}

	/**
	 * Tests {@link TextBasedSubkey#TextBasedSubkey(String)} with concrete positions <code>4</code>, <code>1</code>, and <code>-1</code> ignoring
	 * vowels.
	 */
	@Test
	public void testPositions41Negative1NoVowels() {
		this.subkey = new TextBasedSubkey(TextBasedSubkeyTest.ATTRIBUTE_NAME);
		this.subkey.setIgnoredCharactersRegEx(TextBasedSubkey.NO_VOWELS_REGEX);
		this.subkey.setPositions(4, 1, -1);

		this.addSubkeyValues(new JsonString("asdasdasd"), new JsonString("sdd"));
		this.addSubkeyValues(new JsonString("aaaazzzzz"), new JsonString("zzz"));

		this.addEqualValues(null, null);
		this.addEqualValues(JsonNull.NULL, JsonNull.NULL);
		this.addEqualValues(new JsonString("ASDASDASD"), new JsonString("ASDASDASD"));
		this.addEqualValues(new JsonString("aaaazzzzz"), new JsonString("aaaazzzzz"));
		this.addEqualValues(new JsonString("asdasdasd"), new JsonString("asdasdasd"));
		this.addEqualValues(new JsonString("MdJKsLd"), new JsonString("asdasdasd"));

		this.setOrderedValues((JsonValue) null, JsonNull.NULL, new JsonNumber(11), new JsonNumber(22410), new JsonString("ASDASDASD"),
				new JsonString("asdasdasd"), new JsonString("aaaazzzzz"));
	}

}
