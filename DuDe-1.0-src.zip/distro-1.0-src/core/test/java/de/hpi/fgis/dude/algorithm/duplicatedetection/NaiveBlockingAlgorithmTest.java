/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.algorithm.duplicatedetection;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.algorithm.AbstractDuplicateDetectionTest;
import de.hpi.fgis.dude.algorithm.AlgorithmTest;
import de.hpi.fgis.dude.datasource.DataSource;
import de.hpi.fgis.dude.datasource.DuDeObjectSource;
import de.hpi.fgis.dude.util.data.DuDeObject;
import de.hpi.fgis.dude.util.data.DuDeObjectPair;
import de.hpi.fgis.dude.util.data.json.JsonArray;
import de.hpi.fgis.dude.util.data.json.JsonRecord;
import de.hpi.fgis.dude.util.data.json.JsonString;
import de.hpi.fgis.dude.util.sorting.sortingkey.SortingKey;
import de.hpi.fgis.dude.util.sorting.sortingkey.TextBasedSubkey;

/**
 * Tests {@link NaiveBlockingAlgorithm}.
 * 
 * @author Matthias Pohl
 */
public class NaiveBlockingAlgorithmTest extends AbstractDuplicateDetectionTest<NaiveBlockingAlgorithm> {

	@Override
	@Before
	public void setUp() throws Exception {
		super.setUp();

		SortingKey sortingKey = new SortingKey();
		sortingKey.addSubkey(new TextBasedSubkey(AlgorithmTest.ATTR_ATTRIBUTE_NAME));

		this.algorithm = new NaiveBlockingAlgorithm(sortingKey);
		this.algorithm.enableInMemoryProcessing();
	}

	@Override
	@After
	public void tearDown() throws Exception {
		super.tearDown();
	}

	/**
	 * Tests the algorithm's result if a {@link DataSource} containing several {@link DuDeObject}s is attached.
	 */
	@Test
	public void testSeveralElementsDataSource() {
		this.algorithm.addDataSource(this.dataSource2);

		this.testIterator(this.algorithm.iterator());
	}

	/**
	 * Tests the algorithm's result if several non-empty {@link DataSource}s are attached.
	 */
	@Test
	public void testSeveralDataSources() {
		this.algorithm.addDataSource(this.dataSource0);
		this.algorithm.addDataSource(this.dataSource1);
		this.algorithm.addDataSource(this.dataSource2);

		DuDeObjectPair[] expectedContent = new DuDeObjectPair[] { this.getPair(this.obj_a0, this.obj_a1), this.getPair(this.obj_a0, this.obj_a2),
				this.getPair(this.obj_a1, this.obj_a2), this.getPair(this.obj_b1, this.obj_b2) };

		this.testIterator(this.algorithm.iterator(), expectedContent);
	}

	/**
	 * Tests the algorithm's result if several {@link DataSource}s (empty and non-empty) are attached.
	 */
	@Test
	public void testSeveralDataSourcesWithEmptyDataSource() {
		this.algorithm.addDataSource(this.emptyDataSource0);
		this.algorithm.addDataSource(this.dataSource1);
		this.algorithm.addDataSource(this.dataSource2);

		DuDeObjectPair[] expectedContent = new DuDeObjectPair[] { this.getPair(this.obj_a1, this.obj_a2), this.getPair(this.obj_b1, this.obj_b2) };

		this.testIterator(this.algorithm.iterator(), expectedContent);
	}
	
	/**
	 * Tests the algorithm with just a substring of the sorting key as blocking criterion.
	 */
	@Test
	public void testSubstringAsBlockingCriterion() {
		// Test data preparation
		String sourceID = "src";
		
		JsonRecord data = new JsonRecord();
		data.put("Name", new JsonArray(new JsonString("AAA1")));
		DuDeObject a1_Object = new DuDeObject(data, sourceID, "0");
		
		data = new JsonRecord();
		data.put("Name", new JsonArray(new JsonString("AAA2")));
		DuDeObject a2_Object = new DuDeObject(data, sourceID, "1");
		
		data = new JsonRecord();
		data.put("Name", new JsonArray(new JsonString("BBB1")));
		DuDeObject b1_Object = new DuDeObject(data, sourceID, "2");
		
		data = new JsonRecord();
		data.put("Name", new JsonArray(new JsonString("BBB2")));
		DuDeObject b2_Object = new DuDeObject(data, sourceID, "3");
		
		data = new JsonRecord();
		data.put("Name", new JsonArray(new JsonString("BBB3")));
		DuDeObject b3_Object = new DuDeObject(data, sourceID, "4");
		
		
		Collection<DuDeObject> coll = new ArrayList<DuDeObject>();
		coll.add(a1_Object);
		coll.add(b1_Object);
		coll.add(a2_Object);
		coll.add(b2_Object);
		coll.add(b3_Object);
		DataSource dataSource = new DuDeObjectSource(sourceID, coll);
		
		Collection<DuDeObjectPair> validResult= new ArrayList<DuDeObjectPair>();
		validResult.add(new DuDeObjectPair(a1_Object, a2_Object));
		validResult.add(new DuDeObjectPair(b1_Object, b2_Object));
		validResult.add(new DuDeObjectPair(b1_Object, b3_Object));
		validResult.add(new DuDeObjectPair(b2_Object, b3_Object));	
	
		int nrCharBlockCriterion = 2;
		SortingKey sortingKey = new SortingKey(new TextBasedSubkey("Name"));
		NaiveBlockingAlgorithm algorithm = new NaiveBlockingAlgorithm(sortingKey, nrCharBlockCriterion);
		algorithm.enableInMemoryProcessing();
		algorithm.setNrCharForBlocking(nrCharBlockCriterion);
		
		Iterator<DuDeObjectPair> iterator = algorithm.iterator();
		assertFalse(iterator.hasNext());
		
		algorithm.addDataSource(dataSource);
		
		iterator = algorithm.iterator();
		Iterator<DuDeObjectPair> validResultIterator = validResult.iterator();

		for (int i = 0; i < validResult.size(); ++i) {
			assertTrue("Error at iteration step: " + i, iterator.hasNext());

			DuDeObjectPair currentPair = null;
			try {
				currentPair = iterator.next();
			} catch (NoSuchElementException e) {
				fail("NoSuchElementException occurred...");
			}

			assertEquals("Error at iteration step: " + i, validResultIterator.next(), currentPair);
		}

		assertFalse(iterator.hasNext());
		
		
	}

}
