/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.similarityfunction.contentbased.impl;

import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.similarityfunction.contentbased.ContentBasedSimilarityFunctionTest;
import de.hpi.fgis.dude.util.data.json.JsonNumber;

/**
 * Tests {@link AbsoluteNumberDiffFunction}.
 * 
 * @author Matthias Pohl
 */
public class AbsoluteNumberDiffFunctionTest extends ContentBasedSimilarityFunctionTest {

	/**
	 * The preset of each test method.
	 * 
	 * @throws Exception
	 *             If an error occurs while initializing the test methods.
	 */
	@Before
	public void setUp() throws Exception {
		this.similarityFunction = new AbsoluteNumberDiffFunction(10, ContentBasedSimilarityFunctionTest.ATTRIBUTE_NAME);
	}

	/**
	 * Tests the behavior of the {@link AbsoluteNumberDiffFunction}.
	 */
	@Test
	public void testBehavior() {
		this.testSimilarity(new JsonNumber(10), new JsonNumber(10), 1.0);
		this.testSimilarity(new JsonNumber(10), new JsonNumber(5), 0.5);
		this.testSimilarity(new JsonNumber(5), new JsonNumber(10), 0.5);
		this.testSimilarity(new JsonNumber(5), new JsonNumber(15), 0.0);
		this.testSimilarity(new JsonNumber(5), new JsonNumber(100), 0.0);
	}

}
