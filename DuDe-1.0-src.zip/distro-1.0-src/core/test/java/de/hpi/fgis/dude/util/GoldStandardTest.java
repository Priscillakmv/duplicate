package de.hpi.fgis.dude.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileWriter;
import java.util.Vector;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import de.hpi.fgis.dude.datasource.CSVSource;
import de.hpi.fgis.dude.datasource.DataSource;
import de.hpi.fgis.dude.exceptions.ExtractionFailedException;
import de.hpi.fgis.dude.util.csv.CSVWriter;
import de.hpi.fgis.dude.util.data.DuDeObject;
import de.hpi.fgis.dude.util.data.DuDeObjectPair;

/**
 * Tests the {@link GoldStandard} class.
 * 
 * @author Matthias Pohl
 */
public class GoldStandardTest {

	private static File csvFile = new File("goldstandard.csv");

	private static String sourceIdAttr1 = "sourceId1";
	private static String sourceIdAttr2 = "sourceId2";

	private static String objectIdAttr1 = "objectId1";
	private static String objectIdAttr2 = "objectId2";

	private static char separatorChar = ';';
	private static char quoteChar = '"';
	
	private static Vector<DuDeObject> dataRecords = new Vector<DuDeObject>();

	private static String[] refData1 = new String[] { "src1", "src2", "0", "1" };
	private static String[] refData2 = new String[] { "src1", "src2", "2", "3" };
	private static String[] refData3 = new String[] { "src1", "src2", "4", "1" };
	private static String[] refData4 = new String[] { "src1", "src2", "2", "4" };

	private static DataSource dataSource;

	private GoldStandard goldStandard;

	/**
	 * The preset of the whole test case.
	 * 
	 * @throws Exception
	 *             If an error occurs while initializing the test case.
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		CSVWriter writer = new CSVWriter(new FileWriter(GoldStandardTest.csvFile));

		writer.setSeparator(GoldStandardTest.separatorChar);
		writer.setQuoteCharacter(GoldStandardTest.quoteChar);

		writer.write(GoldStandardTest.sourceIdAttr1, GoldStandardTest.sourceIdAttr2, GoldStandardTest.objectIdAttr1, GoldStandardTest.objectIdAttr2);
		writer.write(GoldStandardTest.refData1[0], GoldStandardTest.refData1[1], GoldStandardTest.refData1[2], GoldStandardTest.refData1[3]);
		writer.write(GoldStandardTest.refData2[0], GoldStandardTest.refData2[1], GoldStandardTest.refData2[2], GoldStandardTest.refData2[3]);
		writer.write(GoldStandardTest.refData3[0], GoldStandardTest.refData3[1], GoldStandardTest.refData3[2], GoldStandardTest.refData3[3]);
		writer.write(GoldStandardTest.refData4[0], GoldStandardTest.refData4[1], GoldStandardTest.refData4[2], GoldStandardTest.refData4[3]);

		writer.close();
		
		
		DuDeObject object = new DuDeObject("", "0");
		dataRecords.add(object);
		object = new DuDeObject("", "1");
		dataRecords.add(object);
		object = new DuDeObject("", "2");
		dataRecords.add(object);
		object = new DuDeObject("", "3");
		dataRecords.add(object);
		object = new DuDeObject("", "4");
		dataRecords.add(object);
		

		GoldStandardTest.dataSource = new CSVSource("goldStandard", GoldStandardTest.csvFile).withHeader()
				.withSeparatorCharacter(GoldStandardTest.separatorChar).withQuoteCharacter(GoldStandardTest.quoteChar);
	}

	/**
	 * The test case' overall tear-down method.
	 * 
	 * @throws Exception
	 *             If an error occurs while initializing the test case.
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		GoldStandardTest.dataSource.close();
		GoldStandardTest.csvFile.delete();
	}

	/**
	 * The preset of each test method.
	 * 
	 * @throws Exception
	 *             If an error occurs while initializing the test methods.
	 */
	@Before
	public void setUp() throws Exception {
		this.goldStandard = new GoldStandard(GoldStandardTest.dataSource);
	
	}

	/**
	 * The tear-down method for each test method.
	 * 
	 * @throws Exception
	 *             If an error occurs during the method call.
	 */
	@After
	public void tearDown() throws Exception {
		// the gold standard is not closed since its data source is closed in tearDownAfterClass()
	}

	private DuDeObjectPair generateReference(String... data) {
		return new DuDeObjectPair(data[0], data[2], data[1], data[3]);
	}
	
	/**
	 * Tests {@link GoldStandard#getCluster()}, {@link GoldStandard#writeClusterFile(LinkedList<LinkedList<DuDeObject>> goldCluster)}, {@link GoldStandard#readClusterFile()}, {@link GoldStandard#processLine(String str)}
	 * @throws Exception 
	 */
	@Test
	public void testGetCluster() throws Exception{
		
		this.goldStandard.clear();

		this.goldStandard.setFirstElementsObjectIdAttributes(GoldStandardTest.objectIdAttr1);
		this.goldStandard.setSecondElementsObjectIdAttributes(GoldStandardTest.objectIdAttr2);
		
		//let the gold standard generate 2 more clusters with unique elements
		DuDeObject object = new DuDeObject("", "5");
		dataRecords.add(object);
		object = new DuDeObject("", "6");
		dataRecords.add(object);
		this.goldStandard.setExtractedData(dataRecords);
		
		Vector<Vector<DuDeObject>> clusters = this.goldStandard.getCluster();
		assertEquals(3,clusters.size());
		
		this.goldStandard.setFilename("test.csv");
		this.goldStandard.writeClusterFile("test.csv");
		
	}

	/**
	 * Tests {@link GoldStandard#enableSourceIdMapping()}, {@link GoldStandard#disableSourceIdMapping()}, and
	 * {@link GoldStandard#sourceIdMappingEnabled()}.
	 */
	@Test
	public void testSourceIdMappingEnabled() {
		assertFalse(this.goldStandard.sourceIdMappingEnabled());

		this.goldStandard.enableSourceIdMapping();

		assertTrue(this.goldStandard.sourceIdMappingEnabled());

		this.goldStandard.disableSourceIdMapping();

		assertFalse(this.goldStandard.sourceIdMappingEnabled());
	}

	/**
	 * Tests the behavior of {@link GoldStandard#contains(DuDeObjectPair)} with different settings.
	 */
	@Test
	public void testContains() {
		try {
			this.goldStandard.contains(this.generateReference(GoldStandardTest.refData1));
			fail("ExtractionFailedException should have been thrown...");
		} catch (ExtractionFailedException e) {
			// nothing to do
		}

		this.goldStandard.clear();

		this.goldStandard.setFirstElementsObjectIdAttributes(GoldStandardTest.objectIdAttr1);
		this.goldStandard.setSecondElementsObjectIdAttributes(GoldStandardTest.objectIdAttr2);

		this.goldStandard.setSourceIdLiteral("src");

		assertTrue(this.goldStandard.contains(this.generateReference("src", "src", GoldStandardTest.refData1[2], GoldStandardTest.refData1[3])));
		assertTrue(this.goldStandard.contains(this.generateReference("src", "src", GoldStandardTest.refData2[2], GoldStandardTest.refData2[3])));

		assertFalse(this.goldStandard.contains(this.generateReference("src", "src", "-1", "-1")));

		this.goldStandard.clear();

		this.goldStandard.setFirstElementsSourceIdLiteral(GoldStandardTest.sourceIdAttr1);
		this.goldStandard.setSecondElementsSourceIdLiteral(GoldStandardTest.sourceIdAttr2);

		assertTrue(this.goldStandard.contains(this.generateReference(GoldStandardTest.sourceIdAttr1, GoldStandardTest.sourceIdAttr2,
				GoldStandardTest.refData1[2], GoldStandardTest.refData1[3])));
		assertTrue(this.goldStandard.contains(this.generateReference(GoldStandardTest.sourceIdAttr1, GoldStandardTest.sourceIdAttr2,
				GoldStandardTest.refData2[2], GoldStandardTest.refData2[3])));

		assertFalse(this.goldStandard.contains(this.generateReference("src1", "src2", "-1", "-1")));

		this.goldStandard.clear();

		this.goldStandard.enableSourceIdMapping();

		assertTrue(this.goldStandard.contains(this.generateReference(GoldStandardTest.refData1)));
		assertTrue(this.goldStandard.contains(this.generateReference(GoldStandardTest.refData2)));
		assertTrue(this.goldStandard.contains(this.generateReference(GoldStandardTest.refData3)));
		assertTrue(this.goldStandard.contains(this.generateReference(GoldStandardTest.refData4)));

		assertFalse(this.goldStandard.contains(this.generateReference("src1", "src2", "-1", "-1")));
	}

	/**
	 * Tests {@link GoldStandard#size()}.
	 */
	@Test
	public void testSize() {
		try {
			this.goldStandard.size();
			fail("ExtractionFailedException should have been thrown...");
		} catch (ExtractionFailedException e) {
			// nothing to do
		}

		this.goldStandard.clear();

		this.goldStandard.setFirstElementsObjectIdAttributes(GoldStandardTest.objectIdAttr1);
		this.goldStandard.setSecondElementsObjectIdAttributes(GoldStandardTest.objectIdAttr2);

		assertEquals(4, this.goldStandard.size());
	}
}
