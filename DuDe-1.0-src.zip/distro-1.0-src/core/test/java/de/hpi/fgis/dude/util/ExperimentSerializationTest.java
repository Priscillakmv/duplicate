/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.util;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.fail;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.algorithm.duplicatedetection.DuplicateCountSNM;
import de.hpi.fgis.dude.algorithm.duplicatedetection.DuplicateCountSNM.AdaptionMode;
import de.hpi.fgis.dude.algorithm.duplicatedetection.NaiveDuplicateDetection;
import de.hpi.fgis.dude.algorithm.duplicatedetection.SortedNeighborhoodMethod;
import de.hpi.fgis.dude.datasource.BibtexSource;
import de.hpi.fgis.dude.datasource.CSVSource;
import de.hpi.fgis.dude.datasource.JSONSource;
import de.hpi.fgis.dude.output.statisticoutput.SimpleStatisticOutput;
import de.hpi.fgis.dude.similarityfunction.aggregators.Average;
import de.hpi.fgis.dude.similarityfunction.contentbased.impl.AbsoluteNumberDiffFunction;
import de.hpi.fgis.dude.similarityfunction.contentbased.impl.simmetrics.JaroDistanceFunction;
import de.hpi.fgis.dude.similarityfunction.contentbased.impl.simmetrics.LevenshteinDistanceFunction;
import de.hpi.fgis.dude.util.bibtex.expander.ExpansionException;
import de.hpi.fgis.dude.util.bibtex.parser.ParseException;
import de.hpi.fgis.dude.util.data.json.JsonUtil;
import de.hpi.fgis.dude.util.sorting.sortingkey.NumberBasedSubkey;
import de.hpi.fgis.dude.util.sorting.sortingkey.SortingKey;
import de.hpi.fgis.dude.util.sorting.sortingkey.TextBasedSubkey;

/**
 * Tests the serialization of {@link Experiment}
 * 
 * @author Arvid Heise
 */
public class ExperimentSerializationTest {
	private Experiment experiment;

	private File getFile(String string) {
		try {
			return File.createTempFile(string, "tmp");
		} catch (final IOException e) {
			fail(e.toString());
			return null;
		}
	}

	private String getIdentifier(String identifier) {
		return identifier + System.currentTimeMillis();
	}

	/**
	 * Serializes the experiment and compares the deserialized experiment with the original one.
	 */
	@After
	public void performTest() {
		final String json = JsonUtil.toJson(this.experiment);
		assertEquals(this.experiment, JsonUtil.fromJson(json, this.experiment.getClass()));
	}

	/**
	 * 
	 */
	@Before
	public void setup() {
		this.experiment = new Experiment();
	}

	/**
	 * 
	 */
	@Test
	public void testAdaptiveWindowSizeSNM() {
		this.experiment.setAlgorithm(new DuplicateCountSNM.AdaptiveWindowSizeSNMBuilder(new SortingKey(new TextBasedSubkey("name"),
				new NumberBasedSubkey("zip")), AdaptionMode.BASIC).build());
	}

	/**
	 * @throws IOException
	 *             if an I/O error occurred
	 * @throws ParseException
	 * @throws ExpansionException
	 */
	@Test
	public void testBibtexDataSource() throws IOException, ExpansionException, ParseException {
		this.experiment.addDataSource(new BibtexSource(this.getIdentifier("bib"), this.getFile("data.bib")));
	}

	/**
	 * 
	 */
	@Test
	public void testSimilarityFunction() {
		this.experiment.setSimilarityFunction(new Average(new LevenshteinDistanceFunction("name"), new JaroDistanceFunction("phone"),
				new AbsoluteNumberDiffFunction(3, "zip")));
	}

	/**
	 * @throws IOException
	 * 
	 */
	@Test
	public void testCompleteExperiment() throws IOException {
		this.experiment.addDataSource(new JSONSource(getIdentifier("json"), File.createTempFile("testfile", ".json")));
		this.experiment.setAlgorithm(new SortedNeighborhoodMethod(new SortingKey(new TextBasedSubkey("lastName", TextBasedSubkey.NO_VOWELS_REGEX))));
		this.experiment.enableStatistics();
		this.experiment.enableTransitiveClosures();

		this.experiment.setSimilarityFunction(new Average(new LevenshteinDistanceFunction("lastName"), new LevenshteinDistanceFunction("firstName")));
		this.experiment.addStatisticOutput(new SimpleStatisticOutput(System.out));
	}

	/**
	 */
	@Test
	public void testStatisticOutput() {
		this.experiment.addStatisticOutput(new SimpleStatisticOutput(System.out));
	}

	/**
	 * @throws IOException
	 *             if an I/O error occurred
	 */
	@Test
	public void testCSVDataSource() throws IOException {
		this.experiment.addDataSource(new CSVSource(this.getIdentifier("csv"), this.getFile("data.csv")));
	}

	/**
	 * 
	 */
	@Test
	public void testEmptyExperiment() {
		// nothing to do
	}

	/**
	 * @throws FileNotFoundException
	 */
	@Test
	public void testGoldStandard() throws FileNotFoundException {
		this.experiment.setGoldStandard(new GoldStandard(new CSVSource(this.getIdentifier("csv"), this.getFile("data.csv"))));
	}

	// TODO: implement MultiPassSortedNeighborhoodMethod
	// /**
	// *
	// */
	// @Test
	// public void testMultiSNMAlgorithm() {
	// this.experiment.setAlgorithm(new MultiPassSortedNeighborhoodMethod(20, new SortingKey(new TextBasedSubkey("name"), new NumberBasedSubkey(
	// "zip")), new SortingKey(new TextBasedSubkey("street"), new NumberBasedSubkey("phone"))));
	// }

	/**
	 * 
	 */
	@Test
	public void testNaiveDuplicateDetection() {
		this.experiment.setAlgorithm(new NaiveDuplicateDetection());
	}

	/**
	 * @throws IOException
	 */
	@Test
	public void testJsonDataSource() throws IOException {
		this.experiment.addDataSource(new JSONSource(this.getIdentifier("json"), this.getFile("data.json")));
	}

	/**
	 * 
	 */
	@Test
	public void testSortedNeighborhoodMethod() {
		this.experiment.setAlgorithm(new SortedNeighborhoodMethod(new SortingKey(new TextBasedSubkey("name"), new NumberBasedSubkey("zip")), 20));
	}

	// TODO: implement SortedBlocks
	// /**
	// *
	// */
	// @Test
	// public void testSortedBlocksAlgorithm() {
	// this.experiment.setAlgorithm(new SortedBlocks(new SortingKey(new TextBasedSubkey("name"), new NumberBasedSubkey("zip")), 20, 50));
	// }
}
