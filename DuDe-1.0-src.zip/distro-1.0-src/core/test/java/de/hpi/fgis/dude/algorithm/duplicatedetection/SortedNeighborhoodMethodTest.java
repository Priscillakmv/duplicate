/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.algorithm.duplicatedetection;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.algorithm.AbstractDuplicateDetectionTest;
import de.hpi.fgis.dude.algorithm.AlgorithmTest;
import de.hpi.fgis.dude.datasource.DataSource;
import de.hpi.fgis.dude.util.data.DuDeObject;
import de.hpi.fgis.dude.util.data.DuDeObjectPair;
import de.hpi.fgis.dude.util.sorting.sortingkey.SortingKey;
import de.hpi.fgis.dude.util.sorting.sortingkey.TextBasedSubkey;

/**
 * Tests {@link SortedNeighborhoodMethod}.
 * 
 * @author Matthias Pohl
 */
public class SortedNeighborhoodMethodTest extends AbstractDuplicateDetectionTest<SortedNeighborhoodMethod> {

	@Override
	@Before
	public void setUp() throws Exception {
		super.setUp();

		SortingKey sortingKey = new SortingKey();
		sortingKey.addSubkey(new TextBasedSubkey(AlgorithmTest.ATTR_ATTRIBUTE_NAME));

		this.algorithm = new SortedNeighborhoodMethod(sortingKey, 2);
		this.algorithm.enableInMemoryProcessing();
	}

	@Override
	@After
	public void tearDown() throws Exception {
		super.tearDown();
	}

	/**
	 * Tests the algorithm's result if a {@link DataSource} containing several {@link DuDeObject}s is attached.
	 */
	@Test
	public void testSeveralElementsDataSource() {
		this.algorithm.addDataSource(this.dataSource2);

		DuDeObjectPair[] expectedContent = new DuDeObjectPair[] { this.getPair(this.obj_a2, this.obj_b2), this.getPair(this.obj_b2, this.obj_c2) };

		this.testIterator(this.algorithm.iterator(), expectedContent);
	}

	/**
	 * Tests the algorithm's result if several non-empty {@link DataSource}s are attached.
	 */
	@Test
	public void testSeveralDataSources() {
		this.algorithm.addDataSource(this.dataSource0);
		this.algorithm.addDataSource(this.dataSource1);
		this.algorithm.addDataSource(this.dataSource2);

		DuDeObjectPair[] expectedContent = new DuDeObjectPair[] { this.getPair(this.obj_a0, this.obj_a1), this.getPair(this.obj_a1, this.obj_a2),
				this.getPair(this.obj_a2, this.obj_b1), this.getPair(this.obj_b1, this.obj_b2), this.getPair(this.obj_b2, this.obj_c2) };

		this.testIterator(this.algorithm.iterator(), expectedContent);
	}

	/**
	 * Tests the algorithm's result if several {@link DataSource}s (empty and non-empty) are attached.
	 */
	@Test
	public void testSeveralDataSourcesWithEmptyDataSource() {
		this.algorithm.addDataSource(this.emptyDataSource0);
		this.algorithm.addDataSource(this.dataSource1);
		this.algorithm.addDataSource(this.dataSource2);

		DuDeObjectPair[] expectedContent = new DuDeObjectPair[] { this.getPair(this.obj_a1, this.obj_a2), this.getPair(this.obj_a2, this.obj_b1),
				this.getPair(this.obj_b1, this.obj_b2), this.getPair(this.obj_b2, this.obj_c2) };

		this.testIterator(this.algorithm.iterator(), expectedContent);
	}

}
