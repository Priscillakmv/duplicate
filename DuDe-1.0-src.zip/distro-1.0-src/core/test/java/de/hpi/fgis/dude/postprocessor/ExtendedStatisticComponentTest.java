/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2011  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.postprocessor;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Vector;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.postprocessor.ExtendedStatisticComponent.Config;
import de.hpi.fgis.dude.util.data.DuDeObject;
import de.hpi.fgis.dude.util.data.DuDeObjectPair;
import de.hpi.fgis.dude.util.data.json.JsonArray;
import de.hpi.fgis.dude.util.data.json.JsonRecord;
import de.hpi.fgis.dude.util.data.json.JsonString;

public class ExtendedStatisticComponentTest {
	
	private ExtendedStatisticComponent statistic;
	
	private DuDeObjectPair firstPositivePair;
	private DuDeObjectPair secondPositivePair;
	
	private DuDeObjectPair firstNegativePair;
	private DuDeObjectPair secondNegativePair;

	private Vector<Vector<DuDeObject>> erCluster = new Vector<Vector<DuDeObject>>();
	private Vector<Vector<DuDeObject>> goldCluster = new Vector<Vector<DuDeObject>>();
	/**
	 * The preset of each test method. Sets up an artificial gold standard and er result
	 * 
	 * @throws Exception
	 *             If an error occurs while initializing the test methods.
	 */
	@Before
	public void setUp() throws Exception {
		
		
		Vector<DuDeObject> erCluster1 = new Vector<DuDeObject>();
		Vector<DuDeObject> erCluster2 = new Vector<DuDeObject>();
		
		Vector<DuDeObject> goldCluster1 = new Vector<DuDeObject>();
		Vector<DuDeObject> goldCluster2 = new Vector<DuDeObject>();
		Vector<DuDeObject> goldCluster3 = new Vector<DuDeObject>();
		//create DuDe-Objects
		JsonRecord data1, data2;
		
		data1 = new JsonRecord(); data1.put("Name", new JsonArray(new JsonString("A")));
		DuDeObject d1 = new DuDeObject(data1, "1", "1");
		data2 = new JsonRecord(); data2.put("Name", new JsonArray(new JsonString("B")));
		DuDeObject d2 = new DuDeObject(data2, "1", "2");
		this.firstPositivePair = new DuDeObjectPair(new DuDeObject(data1, "", "1"), new DuDeObject(data2, "", "2"));
		data1 = new JsonRecord(); data1.put("Name", new JsonArray(new JsonString("C")));
		DuDeObject d3 = new DuDeObject(data1, "1", "3");
		data2 = new JsonRecord(); data2.put("Name", new JsonArray(new JsonString("D")));
		DuDeObject d4 = new DuDeObject(data2, "1", "4");
		this.secondPositivePair = new DuDeObjectPair(new DuDeObject(data1, "", "3"), new DuDeObject(data2, "", "4"));
		data1 = new JsonRecord(); data1.put("Name", new JsonArray(new JsonString("E")));
		DuDeObject d5 = new DuDeObject(data1, "1", "5");
		data2 = new JsonRecord(); data2.put("Name", new JsonArray(new JsonString("F")));
		DuDeObject d6 = new DuDeObject(data2, "1", "6");
		this.firstNegativePair = new DuDeObjectPair(new DuDeObject(data1, "", "5"), new DuDeObject(data2, "", "6"));
		data1 = new JsonRecord(); data1.put("Name", new JsonArray(new JsonString("G")));
		DuDeObject d7 = new DuDeObject(data1, "1", "7");
		data2 = new JsonRecord(); data2.put("Name", new JsonArray(new JsonString("H")));
		DuDeObject d8 = new DuDeObject(data2, "1", "8");
		this.secondNegativePair = new DuDeObjectPair(new DuDeObject(data1, "", "11"), new DuDeObject(data2, "", "12"));
		
		erCluster1.add(d1);
		erCluster1.add(d2);
		erCluster1.add(d5);
		erCluster1.add(d8);
		erCluster1.add(d7);
		
		erCluster2.add(d3);
		erCluster2.add(d4);
		erCluster2.add(d6);
		
		erCluster.add(erCluster1);
		erCluster.add(erCluster2);
		
		goldCluster1.add(d3);
		goldCluster1.add(d1);
		goldCluster1.add(d7);
		goldCluster1.add(d4);
		
		goldCluster3.add(d8);
		goldCluster3.add(d2);
		
		goldCluster2.add(d6);
		goldCluster2.add(d5);
		
		goldCluster.add(goldCluster1);
		goldCluster.add(goldCluster2);
		goldCluster.add(goldCluster3);
		
		this.statistic = new ExtendedStatisticComponent();
	}
	
	/**
	 * The tear-down method for each test method.
	 * 
	 * @throws Exception
	 *             If an error occurs during the method call.
	 */
	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void testNormalize(){
		float val1 = 2;
		float val2 = 2;
		assertTrue(0 == this.statistic.normalize(val1, val2));
		
		val1 = 3;
		val2 = 4;
		assertTrue(0.25 == this.statistic.normalize(val1, val2));
		
		val1 = 5;
		val2 = 10;
		assertTrue(0.5 == this.statistic.normalize(val1, val2));	
	}
	
	@Test
	public void testComputeF1(){
		float precision = (float) 0.5;
		float recall = (float) 0.5;
		assertTrue(0.5 == this.statistic.computeF1(precision, recall));
		
		precision = (float) 1;
		recall = (float) 0;
		assertTrue(0 == this.statistic.computeF1(precision, recall));
		
		precision = (float) 0;
		recall = (float) 1;
		assertTrue( 0 == this.statistic.computeF1(precision, recall));
	}
	
	@Test
	public void testSetConfigs(){
		
		this.statistic.setConfig(Config.DEFAULT);
		assertTrue(this.statistic.getConfig() == Config.DEFAULT);
		
		this.statistic.setConfig(Config.PRECISION);
		assertTrue(this.statistic.getConfig() == Config.PRECISION);
		
		this.statistic.setConfig(Config.RECALL);
		assertTrue(this.statistic.getConfig() == Config.RECALL);
		
		this.statistic.setConfig(Config.HYBRID);
		assertTrue(this.statistic.getConfig() == Config.HYBRID);
	}
	
	@Test
	public void testFindCluster(){
		//first create a hashmap where each dudeobject is assigned to an id
		//then search the dudeObjects
		HashMap<DuDeObject, Integer> test = new HashMap<DuDeObject, Integer>();
		DuDeObject a1 = new DuDeObject("1", "2");
		DuDeObject a2 = new DuDeObject("2", "2");
		DuDeObject a3 = new DuDeObject("3", "2");
		DuDeObject a4 = new DuDeObject("4", "2");
		
		test.put(a1, 1);
		test.put(a2, 2);
		test.put(a3, 1);
		test.put(a4, 3);
		
		assertTrue(1 == this.statistic.findCluster(test, a1));
		assertTrue(2 == this.statistic.findCluster(test, a2));
		assertTrue(1 == this.statistic.findCluster(test, a3));
		assertTrue(3 == this.statistic.findCluster(test, a4));
	}
	
	@Test
	public void testComputeSingleClusters(){
			
		assertTrue(this.statistic.computeSingleClusters(this.goldCluster).size() == 8);
		assertTrue(this.statistic.computeSingleClusters(this.erCluster).size() == 8);
	}
	
	@Test
	public void testAddDuplicate(){
		
		this.statistic.addDuplicate(this.firstPositivePair, true);
	
		assertTrue(this.statistic.duplicates.contains(this.firstPositivePair));
		
		this.statistic.addDuplicate(this.secondPositivePair, true);
		assertTrue(this.statistic.duplicates.contains(this.secondPositivePair));	
	}
	
	@Test
	public void testAddNonDuplicate(){
		this.statistic.addNonDuplicate(this.firstNegativePair, true);
		
		assertFalse(this.statistic.duplicates.contains(this.firstNegativePair));
		
		this.statistic.addNonDuplicate(this.secondNegativePair, true);
		assertFalse(this.statistic.duplicates.contains(this.secondNegativePair));
	}
	
	@Test
	public void testComputeGMD(){
		this.statistic.setConfig(Config.DEFAULT);
		assertTrue(this.statistic.computeGMD(erCluster, goldCluster) == 5);
		
		this.statistic.setConfig(Config.HYBRID);
		assertTrue(this.statistic.computeGMD(erCluster, goldCluster) == 20);
		
		JsonRecord data1 = new JsonRecord(); data1.put("Name", new JsonArray(new JsonString("X")));
		DuDeObject d1 = new DuDeObject(data1, "1", "9");
		Vector<DuDeObject> cluster = new Vector<DuDeObject>();
		cluster.add(d1);
		
		goldCluster.add(cluster);
		
		erCluster.elementAt(0).add(d1);
		
		this.statistic.setConfig(Config.DEFAULT);
		assertTrue(this.statistic.computeGMD(erCluster, goldCluster) == 6);
		
	
		this.statistic.setConfig(Config.HYBRID);
		assertTrue(this.statistic.computeGMD(erCluster, goldCluster) == 26);
		
		
		
	}	
}
