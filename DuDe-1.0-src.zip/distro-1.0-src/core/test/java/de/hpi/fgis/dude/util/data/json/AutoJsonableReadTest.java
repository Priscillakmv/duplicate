/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.util.data.json;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import de.hpi.fgis.dude.util.ReflectUtil;
import de.hpi.fgis.dude.util.data.AutoJsonable;

/**
 * Tests the deserialization of the {@link AutoJsonable}.
 * 
 * @author Arvid.Heise
 */
public class AutoJsonableReadTest {
	private static class ArrayClass implements AutoJsonable {
		private final PrimitiveClass[] primitiveClasses = { new PrimitiveClass(), null, new PrimitiveClass() };
		private final int[] ints = { 1, 2, 3 };

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (this.getClass() != obj.getClass())
				return false;
			final ArrayClass other = (ArrayClass) obj;
			if (!Arrays.equals(this.ints, other.ints))
				return false;
			if (!Arrays.equals(this.primitiveClasses, other.primitiveClasses))
				return false;
			return true;
		}

		@Override
		public int hashCode() {
			return super.hashCode();
		}
	}

	private static class CollectionClass implements AutoJsonable {
		private final List<PrimitiveClass> primitiveClasses = new ArrayList<PrimitiveClass>(Arrays.asList(new PrimitiveClass(), null,
				new PrimitiveClass()));
		private final List<Integer> ints = new ArrayList<Integer>(Arrays.asList(1, 2, 3));

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (this.getClass() != obj.getClass())
				return false;
			final CollectionClass other = (CollectionClass) obj;
			if (this.ints == null) {
				if (other.ints != null)
					return false;
			} else if (!this.ints.equals(other.ints))
				return false;
			if (this.primitiveClasses == null) {
				if (other.primitiveClasses != null)
					return false;
			} else if (!this.primitiveClasses.equals(other.primitiveClasses))
				return false;
			return true;
		}

		@Override
		public int hashCode() {
			return super.hashCode();
		}
	}

	private static class EmptyClass implements AutoJsonable {
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (this.getClass() != obj.getClass())
				return false;
			return true;
		}

		@Override
		public int hashCode() {
			return super.hashCode();
		}
	}

	private static class NestedClass implements AutoJsonable {
		private final PrimitiveClass primitiveClass = new PrimitiveClass();
		private final EmptyClass emptyClass = new EmptyClass();

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (this.getClass() != obj.getClass())
				return false;
			final NestedClass other = (NestedClass) obj;
			if (this.emptyClass == null) {
				if (other.emptyClass != null)
					return false;
			} else if (!this.emptyClass.equals(other.emptyClass))
				return false;
			if (this.primitiveClass == null) {
				if (other.primitiveClass != null)
					return false;
			} else if (!this.primitiveClass.equals(other.primitiveClass))
				return false;
			return true;
		}

		@Override
		public int hashCode() {
			return super.hashCode();
		}
	}

	private static class PolymorphsmArrayClass implements AutoJsonable {
		private final AutoJsonable[] jsonables = { new EmptyClass(), null, new PrimitiveClass() };

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (this.getClass() != obj.getClass())
				return false;
			final PolymorphsmArrayClass other = (PolymorphsmArrayClass) obj;
			if (!Arrays.equals(this.jsonables, other.jsonables))
				return false;
			return true;
		}

		@Override
		public int hashCode() {
			return super.hashCode();
		}
	}

	private static class PolymorphsmClass implements AutoJsonable {
		private final AutoJsonable jsonable = new EmptyClass();

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (this.getClass() != obj.getClass())
				return false;
			final PolymorphsmClass other = (PolymorphsmClass) obj;
			if (this.jsonable == null) {
				if (other.jsonable != null)
					return false;
			} else if (!this.jsonable.equals(other.jsonable))
				return false;
			return true;
		}

		@Override
		public int hashCode() {
			return super.hashCode();
		}
	}

	private static class PolymorphsmCollectionClass implements AutoJsonable {
		private final List<AutoJsonable> jsonables = new ArrayList<AutoJsonable>(Arrays.asList(new EmptyClass(), null, new PrimitiveClass()));

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (this.getClass() != obj.getClass())
				return false;
			final PolymorphsmCollectionClass other = (PolymorphsmCollectionClass) obj;
			if (this.jsonables == null) {
				if (other.jsonables != null)
					return false;
			} else if (!this.jsonables.equals(other.jsonables))
				return false;
			return true;
		}

		@Override
		public int hashCode() {
			return super.hashCode();
		}
	}

	private static class PrimitiveClass implements AutoJsonable {
		private final int a = 42;
		private final String foo = "bar";
		private final boolean flag = true;

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (this.getClass() != obj.getClass())
				return false;
			final PrimitiveClass other = (PrimitiveClass) obj;
			if (this.a != other.a)
				return false;
			if (this.flag != other.flag)
				return false;
			if (this.foo == null) {
				if (other.foo != null)
					return false;
			} else if (!this.foo.equals(other.foo))
				return false;
			return true;
		}

		@Override
		public int hashCode() {
			return super.hashCode();
		}
	}

	private void testClass(Class<? extends AutoJsonable> klazz) {
		final AutoJsonable instance = ReflectUtil.newInstance(klazz);
		assertEquals(instance, JsonUtil.fromJson(JsonUtil.toJson(instance), klazz));
	}

	/**
	 * 
	 */
	@Test
	public void testWriteArrayClass() {
		this.testClass(ArrayClass.class);
	}

	/**
	 * 
	 */
	@Test
	public void testWriteCollectionClass() {
		this.testClass(CollectionClass.class);
	}

	/**
	 * 
	 */
	@Test
	public void testWriteEmptyClass() {
		this.testClass(EmptyClass.class);
	}

	/**
	 * 
	 */
	@Test
	public void testWriteNestedClass() {
		this.testClass(NestedClass.class);
	}

	/**
	 * 
	 */
	@Test
	public void testWritePolymorphsmArrayClass() {
		this.testClass(PolymorphsmArrayClass.class);
	}

	/**
	 * 
	 */
	@Test
	public void testWritePolymorphsmClass() {
		this.testClass(PolymorphsmClass.class);
	}

	/**
	 * 
	 */
	@Test
	public void testWritePolymorphsmCollectionClass() {
		this.testClass(PolymorphsmCollectionClass.class);
	}

	/**
	 * 
	 */
	@Test
	public void testWritePrimitiveClass() {
		this.testClass(PrimitiveClass.class);
	}
}
