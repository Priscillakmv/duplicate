/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.algorithm;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.datasource.DataSource;

/**
 * Tests {@link AbstractDuplicateDetection}.
 * 
 * @author Matthias Pohl
 * 
 * @param <T>
 *            The algorithm type to test.
 */
public abstract class AbstractDuplicateDetectionTest<T extends AbstractDuplicateDetection> extends AlgorithmTest<T> {

	@Override
	@Before
	public void setUp() throws Exception {
		super.setUp();
	}

	@Override
	@After
	public void tearDown() throws Exception {
		super.tearDown();
	}

	/**
	 * Tests {@link AbstractDuplicateDetection#getMaximumPairCount()}, when an empty {@link DataSource} is attached.
	 */
	@Test
	public void testGetMaximumPairCount1() {
		this.algorithm.addDataSource(this.emptyDataSource0);

		assertEquals(0, this.algorithm.getMaximumPairCount());
		this.algorithm.iterator();
		assertEquals(0, this.algorithm.getMaximumPairCount());
	}

	/**
	 * Tests {@link AbstractDuplicateDetection#getMaximumPairCount()}, when two empty {@link DataSource}s is attached.
	 */
	@Test
	public void testGetMaximumPairCount2() {
		this.algorithm.addDataSource(this.emptyDataSource0);
		this.algorithm.addDataSource(this.emptyDataSource1);

		assertEquals(0, this.algorithm.getMaximumPairCount());
		this.algorithm.iterator();
		assertEquals(0, this.algorithm.getMaximumPairCount());
	}

	/**
	 * Tests {@link AbstractDuplicateDetection#getMaximumPairCount()}, when one {@link DataSource} containing only one element is attached.
	 */
	@Test
	public void testGetMaximumPairCount3() {
		this.algorithm.addDataSource(this.dataSource0);

		assertEquals(0, this.algorithm.getMaximumPairCount());
		this.algorithm.iterator();
		assertEquals(0, this.algorithm.getMaximumPairCount());
	}

	/**
	 * Tests {@link AbstractDuplicateDetection#getMaximumPairCount()}, when a {@link DataSource} containing two elements is attached.
	 */
	@Test
	public void testGetMaximumPairCount4() {
		this.algorithm.addDataSource(this.dataSource1);

		assertEquals(0, this.algorithm.getMaximumPairCount());
		this.algorithm.iterator();
		assertEquals(1, this.algorithm.getMaximumPairCount());
	}

	/**
	 * Tests {@link AbstractDuplicateDetection#getMaximumPairCount()}, when a {@link DataSource} containing more than two elements is attached.
	 */
	@Test
	public void testGetMaximumPairCount5() {
		this.algorithm.addDataSource(this.dataSource2);

		assertEquals(0, this.algorithm.getMaximumPairCount());
		this.algorithm.iterator();
		assertEquals(3, this.algorithm.getMaximumPairCount());
	}

	/**
	 * Tests {@link AbstractDuplicateDetection#getMaximumPairCount()}, when several non-empty {@link DataSource} are attached.
	 */
	@Test
	public void testGetMaximumPairCount6() {
		this.algorithm.addDataSource(this.dataSource0);
		this.algorithm.addDataSource(this.dataSource1);
		this.algorithm.addDataSource(this.dataSource2);

		assertEquals(0, this.algorithm.getMaximumPairCount());
		this.algorithm.iterator();
		assertEquals(15, this.algorithm.getMaximumPairCount());
	}

	/**
	 * Tests {@link AbstractDuplicateDetection#getMaximumPairCount()}, when several empty and non-empty {@link DataSource}s are attached.
	 */
	@Test
	public void testGetMaximumPairCount7() {
		this.algorithm.addDataSource(this.emptyDataSource0);
		this.algorithm.addDataSource(this.dataSource1);
		this.algorithm.addDataSource(this.dataSource2);

		assertEquals(0, this.algorithm.getMaximumPairCount());
		this.algorithm.iterator();
		assertEquals(10, this.algorithm.getMaximumPairCount());
	}
}
