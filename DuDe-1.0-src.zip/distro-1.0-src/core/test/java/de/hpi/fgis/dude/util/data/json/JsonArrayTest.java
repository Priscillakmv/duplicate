/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.util.data.json;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.LinkedList;
import java.util.TreeMap;

import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.util.data.json.JsonValue.JsonType;

/**
 * Tests {@link JsonArray}.
 * 
 * @author Matthias Pohl
 */
public class JsonArrayTest {
	
	private JsonArray array = new JsonArray();
	
	private JsonRecord record = new JsonRecord();
	private JsonNumber integerValue = new JsonNumber(1);
	private JsonBoolean booleanValue = JsonBoolean.FALSE;
	private JsonString strValue = new JsonString("text");
	private JsonArray emptyArray = new JsonArray();
	
	private JsonString subrecordAttribute = new JsonString("subrecord attribute");

	/**
	 * The preset of each test method.
	 * 
	 * @throws Exception
	 *             If an error occurs while initializing the test methods.
	 */
	@Before
	public void setUp() throws Exception {
		this.record.put("key", this.subrecordAttribute);
		
		this.array.add(this.record);
		this.array.add(this.integerValue);
		this.array.add(this.booleanValue);
		this.array.add(this.strValue);
		this.array.add(JsonNull.NULL);
		this.array.add(this.emptyArray);
	}

	/**
	 * Tests {@link JsonArray#getType()}.
	 */
	@Test
	public void testGetType() {
		assertEquals(JsonType.Array, this.array.getType());
	}

	/**
	 * Tests {@link JsonArray#compareTo(JsonValue)}.
	 */
	@Test
	public void testCompareTo() {
		assertEquals(0, this.array.compareTo(this.array));
		assertTrue(this.array.compareTo(this.booleanValue) < 0);
		assertTrue(this.array.compareTo(this.integerValue) < 0);
		assertTrue(this.array.compareTo(this.strValue) < 0);
		assertTrue(this.array.compareTo(this.record) < 0);
		assertTrue(this.array.compareTo(JsonNull.NULL) > 0);
		assertTrue(this.array.compareTo(null) > 0);
		assertTrue(this.array.compareTo(this.emptyArray) > 0);
	}

	/**
	 * Tests {@link JsonArray#getJsonValue(String)}.
	 */
	@Test
	public void testGetJsonValueString() {
		assertNull(this.array.getJsonValue(""));
		assertNull(this.array.getJsonValue(null));
		assertEquals(this.subrecordAttribute, this.array.getJsonValue("key"));
	}

	/**
	 * Tests {@link JsonArray#generateString()}.
	 */
	@Test
	public void testGenerateString() {
		final String nullValue = "";
		final String emptyArrayValue = "";
		assertEquals("" + this.subrecordAttribute + " " + this.integerValue.toString() + " " + this.booleanValue.toString() + " " + this.strValue.toString() + " " + nullValue + " " + emptyArrayValue, this.array.generateString());
	}

	/**
	 * Tests {@link JsonArray#add(JsonValue)}.
	 */
	@Test
	public void testAddJsonValue() {
		assertTrue(this.array.add(true));
		assertEquals(JsonBoolean.TRUE, this.array.get(this.array.size() - 1));

		assertTrue(this.array.add(false));
		assertEquals(JsonBoolean.FALSE, this.array.get(this.array.size() - 1));
		
		assertTrue(this.array.add(1));
		assertEquals(new JsonNumber(1), this.array.get(this.array.size() - 1));
		
		assertTrue(this.array.add(2L));
		assertEquals(new JsonNumber(2L), this.array.get(this.array.size() - 1));
		
		assertTrue(this.array.add(3.3));
		assertEquals(new JsonNumber(3.3), this.array.get(this.array.size() - 1));
		
		assertTrue(this.array.add("String"));
		assertEquals(new JsonString("String"), this.array.get(this.array.size() - 1));
		
		assertTrue(this.array.addCollection(new LinkedList<JsonValue>()));
		assertEquals(new JsonArray(), this.array.get(this.array.size() - 1));
		
		assertTrue(this.array.addMap(new TreeMap<String, JsonValue>()));
		assertEquals(new JsonRecord(), this.array.get(this.array.size() - 1));
		
		assertTrue(this.array.add(JsonNull.NULL));
		assertEquals(JsonNull.NULL, this.array.get(this.array.size() - 1));

		assertTrue(this.array.add((JsonValue) null));
		assertEquals(JsonNull.NULL, this.array.get(this.array.size() - 1));
	}

}
