/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.similarityfunction.aggregators;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.similarityfunction.SimilarityFunction;
import de.hpi.fgis.dude.similarityfunction.structurebased.ConstantSimilarityFunction;
import de.hpi.fgis.dude.util.data.DuDeObject;
import de.hpi.fgis.dude.util.data.DuDeObjectPair;

/**
 * Tests the different {@link Aggregator} implementations.
 * 
 * @author Matthias Pohl
 */
public class AggregatorsTest {

	private static double ACCURACY = 0.0000000000001;

	private DuDeObjectPair pair;

	/**
	 * The initialization that is done before each test.
	 * 
	 * @throws Exception
	 *             If an error occurs while initializing the test.
	 */
	@Before
	public void setUp() throws Exception {
		DuDeObject obj1 = new DuDeObject("srcId", "obj1");
		DuDeObject obj2 = new DuDeObject("srcId", "obj2");

		this.pair = new DuDeObjectPair(obj1, obj2);
	}

	private SimilarityFunction[] getConstantSimilarityFunctions(double... sims) {
		SimilarityFunction[] similarityFunctions = new SimilarityFunction[sims.length];
		for (int i = 0; i < sims.length; i++) {
			similarityFunctions[i] = new ConstantSimilarityFunction(sims[i]);
		}

		return similarityFunctions;
	}

	/**
	 * Tests {@link Minimum}.
	 */
	@Test
	public void testMinimum() {
		assertEquals(1.0, new Minimum().getSimilarity(this.pair), AggregatorsTest.ACCURACY);

		assertEquals(0.5, new Minimum(this.getConstantSimilarityFunctions(0.5)).getSimilarity(this.pair), AggregatorsTest.ACCURACY);
		assertEquals(0.4, new Minimum(this.getConstantSimilarityFunctions(0.5, 0.4)).getSimilarity(this.pair), AggregatorsTest.ACCURACY);
		assertEquals(0.0, new Minimum(this.getConstantSimilarityFunctions(0.4, 0.0, 0.5)).getSimilarity(this.pair), AggregatorsTest.ACCURACY);
	}

	/**
	 * Tests {@link Maximum}.
	 */
	@Test
	public void testMaximum() {
		assertEquals(0.0, new Maximum().getSimilarity(this.pair), AggregatorsTest.ACCURACY);

		assertEquals(0.0, new Maximum(this.getConstantSimilarityFunctions(0.0)).getSimilarity(this.pair), AggregatorsTest.ACCURACY);
		assertEquals(0.4, new Maximum(this.getConstantSimilarityFunctions(0.4, 0.0)).getSimilarity(this.pair), AggregatorsTest.ACCURACY);
		assertEquals(0.5, new Maximum(this.getConstantSimilarityFunctions(0.4, 0.0, 0.5)).getSimilarity(this.pair), AggregatorsTest.ACCURACY);
	}

	/**
	 * Tests {@link Average}.
	 */
	@Test
	public void testAverage() {
		assertEquals(0.0, new Average().getSimilarity(this.pair), AggregatorsTest.ACCURACY);

		assertEquals(0.0, new Average(this.getConstantSimilarityFunctions(0.0)).getSimilarity(this.pair), AggregatorsTest.ACCURACY);
		assertEquals(0.2, new Average(this.getConstantSimilarityFunctions(0.4, 0.0)).getSimilarity(this.pair), AggregatorsTest.ACCURACY);
		assertEquals(0.3, new Average(this.getConstantSimilarityFunctions(0.4, 0.0, 0.5)).getSimilarity(this.pair), AggregatorsTest.ACCURACY);

		Average avg;

		avg = new Average();
		assertEquals(0.0, avg.getSimilarity(this.pair), AggregatorsTest.ACCURACY);

		avg = new Average();
		avg.add(new ConstantSimilarityFunction(0.5), 2);
		avg.add(new ConstantSimilarityFunction(0.2), 4);
		assertEquals(0.3, avg.getSimilarity(this.pair), AggregatorsTest.ACCURACY);

		avg = new Average();
		avg.add(new ConstantSimilarityFunction(0.1), 5);
		avg.add(new ConstantSimilarityFunction(0.1), 7);
		assertEquals(0.1, avg.getSimilarity(this.pair), AggregatorsTest.ACCURACY);
	}

	/**
	 * Tests {@link HarmonicMean}.
	 */
	@Test
	public void testHarmonicMean() {
		double expectedSimilarity = 0.0;
		assertEquals(expectedSimilarity, new HarmonicMean().getSimilarity(this.pair), AggregatorsTest.ACCURACY);

		expectedSimilarity = 0.0;
		assertEquals(expectedSimilarity, new HarmonicMean(this.getConstantSimilarityFunctions(0.0)).getSimilarity(this.pair),
				AggregatorsTest.ACCURACY);

		expectedSimilarity = 2.0 / (1 / 0.4);
		assertEquals(expectedSimilarity, new HarmonicMean(this.getConstantSimilarityFunctions(0.4, 0.0)).getSimilarity(this.pair),
				AggregatorsTest.ACCURACY);

		expectedSimilarity = 3.0 / ((1 / 0.4) + (1 / 0.5));
		assertEquals(expectedSimilarity, new HarmonicMean(this.getConstantSimilarityFunctions(0.4, 0.0, 0.5)).getSimilarity(this.pair),
				AggregatorsTest.ACCURACY);

		HarmonicMean harmMean;

		harmMean = new HarmonicMean();
		expectedSimilarity = 0.0;
		assertEquals(expectedSimilarity, harmMean.getSimilarity(this.pair), AggregatorsTest.ACCURACY);

		harmMean = new HarmonicMean();
		harmMean.add(new ConstantSimilarityFunction(0.5), 2);
		harmMean.add(new ConstantSimilarityFunction(0.2), 4);

		expectedSimilarity = 6.0 / ((2 / 0.5) + (4 / 0.2));
		assertEquals(expectedSimilarity, harmMean.getSimilarity(this.pair), AggregatorsTest.ACCURACY);

		harmMean = new HarmonicMean();
		harmMean.add(new ConstantSimilarityFunction(0.1), 5);
		harmMean.add(new ConstantSimilarityFunction(0.1), 7);

		expectedSimilarity = 12.0 / ((5 / 0.1) + (7 / 0.1));
		assertEquals(expectedSimilarity, harmMean.getSimilarity(this.pair), AggregatorsTest.ACCURACY);
	}

}
