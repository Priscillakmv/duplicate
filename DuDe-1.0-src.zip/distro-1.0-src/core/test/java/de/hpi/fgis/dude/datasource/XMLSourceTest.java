/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.datasource;

import java.io.File;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;

import de.hpi.fgis.dude.util.data.json.JsonArray;
import de.hpi.fgis.dude.util.data.json.JsonRecord;
import de.hpi.fgis.dude.util.data.json.JsonString;

/**
 * Tests {@link XMLSource}.
 * 
 * @author Matthias Pohl
 */
public class XMLSourceTest extends AbstractDataSourceTest<XMLSource> {

	private File dataFile;
	
	@Override
	@Before
	public void setUp() throws Exception {
		super.setUp();
		
		this.dataSource = new XMLSource("xml", this.dataFile, "root");
	}

	@Override
	@After
	public void tearDown() throws Exception {
		super.tearDown();
		
		this.dataFile.delete();
	}

	@Override
	protected void initializeData() throws Exception {
		String idAttr = AbstractDataSourceTest.DEFAULT_ID_ATTRIBUTE;
		
		this.dataFile = File.createTempFile("XMLSourceTest", ".xml");

		PrintStream writer = new PrintStream(this.dataFile);

		writer.println("<root>");
		
		writer.println("<record attr1=\"0\">");
		writer.println("<" + idAttr + ">a</" + idAttr + ">");
		writer.println("asd0");
		writer.println("<attr2 attr21=\"00\">asd00</attr2>");
		writer.println("asd0");
		writer.println("</record>");
		
		writer.println("<record attr1=\"1\">");
		writer.println("<" + idAttr + ">b</" + idAttr + ">");
		writer.println("asd1");
		writer.println("<attr2 attr21=\"11\">asd11</attr2>");
		writer.println("asd1");
		writer.println("</record>");

		writer.println("<record attr1=\"2\">");
		writer.println("<" + idAttr + ">c</" + idAttr + ">");
		writer.println("asd2");
		writer.println("<attr2 attr21=\"22\">asd22</attr2>");
		writer.println("asd2");
		writer.println("</record>");
		
		writer.println("</root>");

		writer.close();
	}

	@Override
	protected void initializeRecords() {
		String idAttr = AbstractDataSourceTest.DEFAULT_ID_ATTRIBUTE;
		JsonArray textContent;
		JsonRecord attr2;
		
		this.record0 = new JsonRecord();
		this.record0.put(idAttr, new JsonString("a"));
		this.record0.put("attr1", new JsonString("0"));
		textContent = new JsonArray();
		textContent.add("asd0");
		textContent.add("asd0");
		this.record0.put("record", textContent);
		attr2 = new JsonRecord();
		attr2.put("attr21", new JsonString("00"));
		attr2.put("attr2", new JsonString("asd00"));
		this.record0.put("attr2", attr2);
		
		this.record1 = new JsonRecord();
		this.record1.put(idAttr, new JsonString("b"));
		this.record1.put("attr1", new JsonString("1"));
		textContent = new JsonArray();
		textContent.add("asd1");
		textContent.add("asd1");
		this.record1.put("record", textContent);
		attr2 = new JsonRecord();
		attr2.put("attr21", new JsonString("11"));
		attr2.put("attr2", new JsonString("asd11"));
		this.record1.put("attr2", attr2);
		
		this.record2 = new JsonRecord();
		this.record2.put(idAttr, new JsonString("c"));
		this.record2.put("attr1", new JsonString("2"));
		textContent = new JsonArray();
		textContent.add("asd2");
		textContent.add("asd2");
		this.record2.put("record", textContent);
		attr2 = new JsonRecord();
		attr2.put("attr21", new JsonString("22"));
		attr2.put("attr2", new JsonString("asd22"));
		this.record2.put("attr2", attr2);
	}

}
