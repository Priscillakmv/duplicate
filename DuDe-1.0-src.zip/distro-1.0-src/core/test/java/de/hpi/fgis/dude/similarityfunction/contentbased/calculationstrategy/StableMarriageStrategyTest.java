/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.similarityfunction.contentbased.calculationstrategy;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.similarityfunction.contentbased.ContentBasedSimilarityFunction;
import de.hpi.fgis.dude.similarityfunction.contentbased.impl.AbsoluteNumberDiffFunction;
import de.hpi.fgis.dude.util.data.json.JsonArray;

/**
 * Tests {@link StableMarriageStrategy}.
 * 
 * @author Matthias Pohl
 */
public class StableMarriageStrategyTest {

	private StableMarriageStrategy strategy;
	private ContentBasedSimilarityFunction<?> similarityFunction;

	/**
	 * The preset of each test method.
	 * 
	 * @throws Exception
	 *             If an error occurs while initializing the test methods.
	 */
	@Before
	public void setUp() throws Exception {
		this.strategy = new StableMarriageStrategy();
		this.similarityFunction = new AbsoluteNumberDiffFunction(10, "");
	}

	private void testValues(JsonArray men, JsonArray women, double expectedSimilarity) {
		assertEquals(this.strategy.calculateSimilarity(this.similarityFunction, men, women), expectedSimilarity, 0.0001);
	}
	
	private JsonArray createJsonArray(int... values) {
		JsonArray arr = new JsonArray();
		for (int value : values) {
			arr.add(value);
		}
		
		return arr;
	}

	/**
	 * Tests the behavior of the <code>Stable-Marriage</code> algorithm.
	 */
	@Test
	public void testBehavior() {
		this.testValues(this.createJsonArray(), this.createJsonArray(), 1.0);
		
		this.testValues(this.createJsonArray(), this.createJsonArray(1), 0.0);
		this.testValues(this.createJsonArray(2), this.createJsonArray(), 0.0);
		
		this.testValues(this.createJsonArray(1), this.createJsonArray(1), 1.0);
		this.testValues(this.createJsonArray(1), this.createJsonArray(2), 0.9);
		
		this.testValues(this.createJsonArray(1, 2), this.createJsonArray(2, 1), 1.0);
		this.testValues(this.createJsonArray(2, 1), this.createJsonArray(1, 2), 1.0);
		
		this.testValues(this.createJsonArray(1, 4, 7), this.createJsonArray(6, 5, 2), 0.9);
		this.testValues(this.createJsonArray(1, 4, 7), this.createJsonArray(6, 5, 2, 10, 20), 0.9);
		this.testValues(this.createJsonArray(1, 4, 7, 10, 20), this.createJsonArray(6, 5, 2), 0.9);
		
		this.testValues(this.createJsonArray(0, 1, 2), this.createJsonArray(100, 101, 102, 103), 0.0);
	}

}
