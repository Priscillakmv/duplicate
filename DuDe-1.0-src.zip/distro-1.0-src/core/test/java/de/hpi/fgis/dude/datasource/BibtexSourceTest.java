/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.datasource;

import java.io.File;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;

import de.hpi.fgis.dude.util.data.json.JsonBoolean;
import de.hpi.fgis.dude.util.data.json.JsonRecord;
import de.hpi.fgis.dude.util.data.json.JsonString;

/**
 * Tests {@link BibtexSource}.
 * 
 * @author Matthias Pohl
 */
public class BibtexSourceTest extends AbstractDataSourceTest<BibtexSource> {

	private File dataFile;
	
	@Override
	@Before
	public void setUp() throws Exception {
		super.setUp();
		
		this.dataSource = new BibtexSource("bibtex", this.dataFile, true);
	}

	@Override
	@After
	public void tearDown() throws Exception {
		// close all file connections before the file is deleted
		super.tearDown();
		
		this.dataFile.delete();
	}

	@Override
	protected void initializeData() throws Exception {
		this.dataFile = File.createTempFile("BibtexSourceTest", ".bib");

		PrintStream writer = new PrintStream(this.dataFile);

		writer.println("@article{test1,");
		writer.println("	Author = {Theodor Miller},");
		writer.println("	Date-Added = {2010-03-12 11:32:20 +0100},");
		writer.println("	Date-Modified = {2010-03-12 11:33:44 +0100},");
		writer.println("	Journal = {Here comes the journal},");
		writer.println("	Keywords = {Theodor Raden},");
		writer.println("	Month = {March},");
		writer.println("	Number = {1},");
		writer.println("	Pages = {12},");
		writer.println("	Title = {That's the title},");
		writer.println("	Volume = {1},");
		writer.println("	Year = {2010}");
		writer.println("}");

		writer.println("@article{test2,");
		writer.println("	Author = {Marvin Kean},");
		writer.println("	Date-Added = {2010-03-12 11:33:54 +0100},");
		writer.println("	Date-Modified = {2010-03-12 11:35:38 +0100},");
		writer.println("	Journal = {From another Journal},");
		writer.println("	Keywords = {Marvin Motown},");
		writer.println("	Month = {December},");
		writer.println("	Number = {2},");
		writer.println("	Pages = {12},");
		writer.println("	Title = {Another title},");
		writer.println("	Volume = {2},");
		writer.println("	Year = {2010}");
		writer.println("}");

		writer.println("@article{test3-unicode,");
		writer.println("	Author = {G{\"u}nther Schabowski},");
		writer.println("	Date-Added = {2010-03-12 11:36:04 +0100},");
		writer.println("	Date-Modified = {2010-03-12 11:37:45 +0100},");
		writer.println("	Journal = {Unicode Journal},");
		writer.println("	Title = {G{\\\"u}ltiger {\\\"A}ltestenrat mit Umlauten im Namen},");
		writer.println("	Year = {1337}");
		writer.println("}");

		writer.close();
	}

	@Override
	protected void initializeRecords() {
		JsonRecord author;
		
		this.record0 = new JsonRecord();
		
		this.record0.put(BibtexSource.KEY_ATTRIBUTE, new JsonString("test1"));
		this.record0.put(BibtexSource.TYPE_ATTRIBUTE, new JsonString("article"));
		
		author = new JsonRecord();
		author.put(BibtexSource.PERSON_LAST_NAME_ATTRIBUTE, "Miller");
		author.put(BibtexSource.PERSON_FIRST_NAME_ATTRIBUTE, "Theodor");
		
		this.record0.put("author", author);
		this.record0.put("date-added", new JsonString("2010-03-12 11:32:20 +0100"));
		this.record0.put("date-modified", new JsonString("2010-03-12 11:33:44 +0100"));
		this.record0.put("journal", new JsonString("Here comes the journal"));
		this.record0.put("month", new JsonString("March"));
		this.record0.put("number", new JsonString("1"));
		this.record0.put("pages", new JsonString("12"));
		this.record0.put("title", new JsonString("That's the title"));
		this.record0.put("volume", new JsonString("1"));
		this.record0.put("year", new JsonString("2010"));
		this.record0.put("keywords", new JsonString("Theodor Raden"));
		this.record0.put(BibtexSource.ADDITIONAL_AUTHORS_EXISTS_ATTRIBUTE, JsonBoolean.FALSE);
		
		this.record1 = new JsonRecord();
		
		this.record1.put(BibtexSource.KEY_ATTRIBUTE, new JsonString("test2"));
		this.record1.put(BibtexSource.TYPE_ATTRIBUTE, new JsonString("article"));
		
		author = new JsonRecord();
		author.put(BibtexSource.PERSON_LAST_NAME_ATTRIBUTE, "Kean");
		author.put(BibtexSource.PERSON_FIRST_NAME_ATTRIBUTE, "Marvin");
		
		this.record1.put("author", author);
		this.record1.put("date-added", new JsonString("2010-03-12 11:33:54 +0100"));
		this.record1.put("date-modified", new JsonString("2010-03-12 11:35:38 +0100"));
		this.record1.put("journal", new JsonString("From another Journal"));
		this.record1.put("month", new JsonString("December"));
		this.record1.put("number", new JsonString("2"));
		this.record1.put("pages", new JsonString("12"));
		this.record1.put("title", new JsonString("Another title"));
		this.record1.put("volume", new JsonString("2"));
		this.record1.put("year", new JsonString("2010"));
		this.record1.put("keywords", new JsonString("Marvin Motown"));
		this.record1.put(BibtexSource.ADDITIONAL_AUTHORS_EXISTS_ATTRIBUTE, JsonBoolean.FALSE);
		
		this.record2 = new JsonRecord();
		
		this.record2.put(BibtexSource.KEY_ATTRIBUTE, new JsonString("test3-unicode"));
		this.record2.put(BibtexSource.TYPE_ATTRIBUTE, new JsonString("article"));
		
		author = new JsonRecord();
		author.put(BibtexSource.PERSON_LAST_NAME_ATTRIBUTE, "Schabowski");
		author.put(BibtexSource.PERSON_FIRST_NAME_ATTRIBUTE, "G{\"u}nther");
		
		this.record2.put("author", author);
		this.record2.put("date-added", new JsonString("2010-03-12 11:36:04 +0100"));
		this.record2.put("date-modified", new JsonString("2010-03-12 11:37:45 +0100"));
		this.record2.put("journal", new JsonString("Unicode Journal"));
		this.record2.put("title", new JsonString("G{\\\"u}ltiger {\\\"A}ltestenrat mit Umlauten im Namen"));
		this.record2.put("year", new JsonString("1337"));
		this.record2.put(BibtexSource.ADDITIONAL_AUTHORS_EXISTS_ATTRIBUTE, JsonBoolean.FALSE);
	}

	@Override
	protected void initializeIdAttributes() {
		this.idAttributes = new String[] { BibtexSource.KEY_ATTRIBUTE };
	}

}
