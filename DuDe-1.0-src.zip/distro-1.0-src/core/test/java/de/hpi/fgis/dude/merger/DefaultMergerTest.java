/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.merger;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.util.data.DuDeObject;
import de.hpi.fgis.dude.util.data.json.JsonArray;
import de.hpi.fgis.dude.util.data.json.JsonRecord;
import de.hpi.fgis.dude.util.merger.DefaultMerger;
import de.hpi.fgis.dude.util.merger.Merger;

/**
 * Tests {@link DefaultMerger}.
 * 
 * @author Johannes Dyck
 */
public class DefaultMergerTest {
	
	private Merger merger; 
	
	@Before
	public void setUp() throws Exception {
		this.merger = new DefaultMerger();
	}
	
	@After
	public void tearDown() throws Exception {
		
	}

	/**
	 * Tests the merger's result if both {@link DuDeObjects} contain similar data.
	 */
	@Test
	public void testSimilarElementsMerge() {
		JsonRecord resData = new JsonRecord();
		DuDeObject originalLeft = getDefaultLeftObject();
		DuDeObject originalRight = getDefaultRightObject();
		DuDeObject left = getDefaultLeftObject();
		DuDeObject right = getDefaultRightObject();
	
		JsonArray firstArray = new JsonArray();
		firstArray.add("eins");
		firstArray.add("zwei");
		firstArray.add("drei");
		JsonArray secondArray = new JsonArray();
		secondArray.add(1);
		secondArray.add(2);
		secondArray.add(3);
		secondArray.add(4);
		JsonArray thirdArray = new JsonArray();
		thirdArray.add("erstes");
		thirdArray.add("zweites");		
		JsonArray fourthArray = new JsonArray();
		fourthArray.add("einzeln");
		fourthArray.add("zweizeln");
		JsonArray fifthArray = new JsonArray();
		fifthArray.add("einzeln2");
		fifthArray.add("zweizeln2");		
		resData.put("string", firstArray);
		resData.put("int", secondArray);
		resData.put("stint", thirdArray);
		resData.put("fourth", fourthArray);
		resData.put("fifth", fifthArray);
		
		DuDeObject result = new DuDeObject(resData, "src1", "a");
		result.addIdentifier(right.getIdentifier());
		
		DuDeObject testRes = merger.merge(left, right);
		assertEquals(testRes, result);
		assertEquals(testRes.getData(), result.getData());
		
		// ensure that original data is preserved
		assertEquals(left.getData(), originalLeft.getData());
		assertEquals(right.getData(), originalRight.getData());		
	}
	
	/**
	 * Tests the merger's result if both {@link DuDeObjects} do not contain any data.
	 */
	@Test
	public void testDataNullMerge() {		
		DuDeObject left = new DuDeObject(null, "src1", "a");
		DuDeObject right = new DuDeObject(null, "src1", "ab");				
		
		DuDeObject result = new DuDeObject(null, "src1", "a");
		result.addIdentifier(right.getIdentifier());
		
		DuDeObject testRes = merger.merge(left, right);
		
		assertEquals(testRes, result);
		assertEquals(testRes.getData(), result.getData());
	}
	
	/**
	 * Tests the merger's result if the left {@link DuDeObject} does not contain any data.
	 */
	@Test
	public void testLeftDataNullMerge() {		
		DuDeObject left = new DuDeObject(null, "src1", "a");
		DuDeObject originalRight = getDefaultRightObject();
		
		DuDeObject right = getDefaultRightObject();
				
		DuDeObject result = new DuDeObject(right.getData(), "src1", left.getObjectId());
		result.addIdentifier(right.getIdentifier());
		
		DuDeObject testRes = merger.merge(left, right);
		
		assertEquals(testRes, result);
		assertEquals(testRes.getData(), result.getData());
		
		// ensure that original data is preserved
		assertEquals(right.getData(), originalRight.getData());	
		
	}
	
	/**
	 * Tests the merger's result if the right {@link DuDeObject} does not contain any data.
	 */
	@Test
	public void testRightDataNullMerge() {
		DuDeObject left = getDefaultLeftObject();
		DuDeObject originalLeft = getDefaultLeftObject();
		DuDeObject right = new DuDeObject(null, "src1", "ab");
			
		DuDeObject result = new DuDeObject(left.getData(), "src1", "a");
		result.addIdentifier(right.getIdentifier());
		
		DuDeObject testRes = merger.merge(left, right);
		
		assertEquals(testRes, result);
		assertEquals(testRes.getData(), result.getData());
		
		// ensure that original data is preserved
		assertEquals(left.getData(), originalLeft.getData());	

	}
	
	/**
	 * Tests the merger's result if a {@link DuDeObject} is merged with itself.
	 */
	@Test
	public void testIdenticalObjectsMerge() {
		DuDeObject left = getDefaultLeftObject();
		DuDeObject originalLeft = getDefaultLeftObject();
		DuDeObject right = getDefaultLeftObject();
		DuDeObject originalRight = getDefaultLeftObject();
			
		DuDeObject wrongResult = new DuDeObject(left.getData(), "src1", "a");
		wrongResult.addIdentifier(new DuDeObject(null, "src1", "a").getIdentifier());
		
		DuDeObject result = new DuDeObject(left.getData(), "src1", "a");
				
		DuDeObject testRes = merger.merge(left, right);
		
		assertFalse(testRes.equals(wrongResult));
		assertEquals(testRes, result);
		assertEquals(testRes, left);		
		assertEquals(testRes.getData(), left.getData());
		
		// ensure that original data is preserved
		assertEquals(left.getData(), originalLeft.getData());	
		assertEquals(left.getData(), originalRight.getData());

	}
	
	/**
	 * Tests the merger's result if three {@link DuDeObject} are merged.
	 */
	@Test
	public void testTripleMerge() {
		DuDeObject originalLeft = getDefaultLeftObject();
		DuDeObject originalRight = getDefaultRightObject();
		DuDeObject originalThird = getDefaultThirdObject();
		DuDeObject left = getDefaultLeftObject();
		DuDeObject right = getDefaultRightObject();
		DuDeObject third = getDefaultThirdObject();
		JsonRecord resData = new JsonRecord();		
				
		JsonArray firstArray = new JsonArray();
		firstArray.add("eins");
		firstArray.add("zwei");
		firstArray.add("drei");
		JsonArray secondArray = new JsonArray();
		secondArray.add(1);
		secondArray.add(2);
		secondArray.add(3);
		secondArray.add(4);
		JsonArray thirdArray = new JsonArray();
		thirdArray.add("erstes");
		thirdArray.add("zweites");		
		JsonArray fourthArray = new JsonArray();
		fourthArray.add("einzeln");
		fourthArray.add("zweizeln");
		JsonArray fifthArray = new JsonArray();
		fifthArray.add("einzeln2");
		fifthArray.add("zweizeln2");		
		resData.put("string", firstArray);
		resData.put("int", secondArray);
		resData.put("stint", thirdArray);
		resData.put("fourth", fourthArray);
		resData.put("fifth", fifthArray);
		
		firstArray = new JsonArray();
		firstArray.add("eins");
		firstArray.add("zwei");
		firstArray.add("drei");
		secondArray = new JsonArray();
		secondArray.add(1);
		secondArray.add(2);
		secondArray.add(4);
		thirdArray = new JsonArray();
		thirdArray.add("zweites");		
		fourthArray = new JsonArray();
		fourthArray.add("einzeln2");
		fourthArray.add("zweizeln2");		
		resData.put("unique1", firstArray);
		resData.put("unique2", secondArray);
		resData.put("unique3", thirdArray);
		resData.put("unique4", fourthArray);
				
		DuDeObject result = new DuDeObject(resData, "src1", "a");
		result.addIdentifier(right.getIdentifier());
		result.addIdentifier(third.getIdentifier());
		
		DuDeObject testRes = merger.merge(left, right);
		testRes = merger.merge(testRes, third);
		
		assertEquals(testRes, result);
		assertEquals(testRes.getData(), result.getData());
		
		// ensure that original data is preserved
		assertEquals(left.getData(), originalLeft.getData());
		assertEquals(right.getData(), originalRight.getData());
		assertEquals(third.getData(), originalThird.getData());
	}
	
	/**
	 * Tests if the merging algorithm is symmetric
	 */
	@Test
	public void testSymmetry() {
		
		DuDeObject left = getDefaultLeftObject();
		DuDeObject right = getDefaultLeftObject();
		
		DuDeObject merge1 = this.merger.merge(left, right);
		DuDeObject merge2 = this.merger.merge(right, left);
		
		assertEquals(merge1, merge2);
	}

	/**
	 * Tests the merger's result if two {@link DuDeObject}s with
	 * different source ids abd similar object ids are merged.
	 */
	@Test
	public void testIdMerge() {		
		DuDeObject left = getDefaultLeftObject();
		DuDeObject right = getSpecialRightObject();
		
		DuDeObject trueResult = getDefaultLeftObject();
		trueResult.addIdentifier(right.getIdentifier());
		
		DuDeObject result = merger.merge(left, right);
		
		assertFalse(result.equals(left));
		assertEquals(result, trueResult);
		assertEquals(result.getData(), left.getData());
	}
	
	/**
	 * 
	 * Creates a {@link DuDeObject} to be used in the merger tests.
	 * 
	 * @return A {@link DuDeObject} containing data.
	 */
	private DuDeObject getDefaultLeftObject() {
		JsonRecord leftData = new JsonRecord();
		
		JsonArray firstArray = new JsonArray();
		firstArray.add("eins");
		firstArray.add("zwei");
		firstArray.add("drei");
		JsonArray secondArray = new JsonArray();
		secondArray.add(1);
		secondArray.add(2);
		secondArray.add(3);
		JsonArray thirdArray = new JsonArray();
		thirdArray.add("erstes");		
		JsonArray fourthArray = new JsonArray();
		fourthArray.add("einzeln");
		fourthArray.add("zweizeln");
		leftData.put("string", firstArray);
		leftData.put("int", secondArray);
		leftData.put("stint", thirdArray);
		leftData.put("fourth", fourthArray);
		DuDeObject left = new DuDeObject(leftData, "src1", "a");
		return left;
	}
	
	/**
	 * 
	 * Creates a {@link DuDeObject} to be used in the merger tests.
	 * 
	 * @return A {@link DuDeObject} containing data.
	 */	
	private DuDeObject getDefaultRightObject() {
		JsonRecord rightData = new JsonRecord();
		
		JsonArray firstArray = new JsonArray();
		firstArray.add("eins");
		firstArray.add("zwei");
		firstArray.add("drei");
		JsonArray secondArray = new JsonArray();
		secondArray.add(1);
		secondArray.add(2);
		secondArray.add(4);
		JsonArray thirdArray = new JsonArray();
		thirdArray.add("zweites");		
		JsonArray fourthArray = new JsonArray();
		fourthArray.add("einzeln2");
		fourthArray.add("zweizeln2");
		rightData.put("string", firstArray);
		rightData.put("int", secondArray);
		rightData.put("stint", thirdArray);
		rightData.put("fifth", fourthArray);
		DuDeObject right = new DuDeObject(rightData, "src1", "ab");
		return right;
	}
	
	/**
	 * 
	 * Creates a {@link DuDeObject} to be used in the merger tests.
	 * 
	 * @return A {@link DuDeObject} containing data.
	 */
	private DuDeObject getDefaultThirdObject() {
		JsonRecord data = new JsonRecord();
		
		JsonArray firstArray = new JsonArray();
		firstArray.add("eins");
		firstArray.add("zwei");
		firstArray.add("drei");
		JsonArray secondArray = new JsonArray();
		secondArray.add(1);
		secondArray.add(2);
		secondArray.add(4);
		JsonArray thirdArray = new JsonArray();
		thirdArray.add("zweites");		
		JsonArray fourthArray = new JsonArray();
		fourthArray.add("einzeln2");
		fourthArray.add("zweizeln2");
		data.put("unique1", firstArray);
		data.put("unique2", secondArray);
		data.put("unique3", thirdArray);
		data.put("unique4", fourthArray);
		DuDeObject result = new DuDeObject(data, "src2", "abc");
		return result;
	}
	
	/**
	 * 
	 * Creates a {@link DuDeObject} to be used in the merger test
	 * testing the merge operation with different source ids and similar object ids.
	 * 
	 * @return A {@link DuDeObject} containing data.
	 */
	private DuDeObject getSpecialRightObject() {
		JsonRecord rightData = new JsonRecord();
		
		JsonArray firstArray = new JsonArray();
		firstArray.add("eins");
		firstArray.add("zwei");
		firstArray.add("drei");
		JsonArray secondArray = new JsonArray();
		secondArray.add(1);
		secondArray.add(2);
		secondArray.add(3);
		JsonArray thirdArray = new JsonArray();
		thirdArray.add("erstes");		
		JsonArray fourthArray = new JsonArray();
		fourthArray.add("einzeln");
		fourthArray.add("zweizeln");
		rightData.put("string", firstArray);
		rightData.put("int", secondArray);
		rightData.put("stint", thirdArray);
		rightData.put("fourth", fourthArray);
		DuDeObject right = new DuDeObject(rightData, "src2", "a");
		return right;
	}
}
