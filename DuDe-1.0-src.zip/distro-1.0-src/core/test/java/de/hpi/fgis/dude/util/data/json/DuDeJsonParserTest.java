/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.util.data.json;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.codehaus.jackson.JsonParseException;
import org.junit.Test;

/**
 * Tests the {@link DuDeJsonParser} class.
 * 
 * @author Matthias Pohl
 */
public class DuDeJsonParserTest {

	/**
	 * Tests the {@link JsonString} parsing.
	 */
	@Test
	public void testNextJsonString() {
		try {
			DuDeJsonParser<JsonString> parser = new DuDeJsonParser<JsonString>("\"  \\\"asd\"");
			assertEquals(new JsonString("  \"asd"), parser.nextJsonString());
		} catch (JsonParseException e) {
			fail("JsonParseException occurred...");
		} catch (IOException e) {
			fail("IOException occurred...");
		}

		try {
			DuDeJsonParser<JsonString> parser = new DuDeJsonParser<JsonString>("\"  \\\"asd");
			assertEquals(new JsonString("  \\\"asd"), parser.nextJsonString());
			fail("JsonParseException should have been thrown...");
		} catch (JsonParseException e) {
			// nothing to do
		} catch (IOException e) {
			fail("IOException occurred...");
		} 
	}

	/**
	 * Tests the {@link JsonNumber} parsing.
	 */
	@Test
	public void testNextJsonNumber() {
		try {
			DuDeJsonParser<JsonNumber> parser = new DuDeJsonParser<JsonNumber>("1");
			assertEquals(new JsonNumber(1), parser.nextJsonNumber());
		} catch (JsonParseException e) {
			fail("JsonParseException occurred...");
		} catch (IOException e) {
			fail("IOException occurred...");
		}
		
		try {
			// larger than Integer.MAX_VALUE
			DuDeJsonParser<JsonNumber> parser = new DuDeJsonParser<JsonNumber>("3147483647");
			assertEquals(new JsonNumber(3147483647L), parser.nextJsonNumber());
		} catch (JsonParseException e) {
			fail("JsonParseException occurred...");
		} catch (IOException e) {
			fail("IOException occurred...");
		}
		
		try {
			// larger than Long.MAX_VALUE
			DuDeJsonParser<JsonNumber> parser = new DuDeJsonParser<JsonNumber>("10000000000000000000");
			assertEquals(new JsonNumber(new BigInteger("10000000000000000000")), parser.nextJsonNumber());
		} catch (JsonParseException e) {
			fail("JsonParseException occurred...");
		} catch (IOException e) {
			fail("IOException occurred...");
		}

		try {
			DuDeJsonParser<JsonNumber> parser = new DuDeJsonParser<JsonNumber>("2.2");
			assertEquals(new JsonNumber(2.2), parser.nextJsonNumber());
		} catch (JsonParseException e) {
			fail("JsonParseException occurred...");
		} catch (IOException e) {
			fail("IOException occurred...");
		}
		
		try {
			DuDeJsonParser<JsonNumber> parser = new DuDeJsonParser<JsonNumber>("2.2e10");
			assertEquals(new JsonNumber(2.2e10D), parser.nextJsonNumber());
		} catch (JsonParseException e) {
			fail("JsonParseException occurred...");
		} catch (IOException e) {
			fail("IOException occurred...");
		}
		
		try {
			DuDeJsonParser<JsonNumber> parser = new DuDeJsonParser<JsonNumber>("2.2E10");
			assertEquals(new JsonNumber(2.2e10D), parser.nextJsonNumber());
		} catch (JsonParseException e) {
			fail("JsonParseException occurred...");
		} catch (IOException e) {
			fail("IOException occurred...");
		}
		
		try {
			DuDeJsonParser<JsonNumber> parser = new DuDeJsonParser<JsonNumber>("123.456789e400");
			assertEquals(new JsonNumber(new BigDecimal("123.456789e400")), parser.nextJsonNumber());
		} catch (JsonParseException e) {
			fail("JsonParseException occurred...");
		} catch (IOException e) {
			fail("IOException occurred...");
		}

		try {
			DuDeJsonParser<JsonNumber> parser = new DuDeJsonParser<JsonNumber>("asd");
			parser.nextJsonNumber();
			fail("JsonParseException should have been thrown...");
		} catch (JsonParseException e) {
			// nothing to do
		} catch (IOException e) {
			fail("IOException occurred...");
		}
	}

	/**
	 * Tests the {@link JsonBoolean} parsing.
	 */
	@Test
	public void testNextJsonBoolean() {
		try {
			DuDeJsonParser<JsonBoolean> parser = new DuDeJsonParser<JsonBoolean>("true");
			assertEquals(JsonBoolean.TRUE, parser.nextJsonBoolean());
		} catch (JsonParseException e) {
			fail("JsonParseException occurred...");
		} catch (IOException e) {
			fail("IOException occurred...");
		}

		try {
			DuDeJsonParser<JsonBoolean> parser = new DuDeJsonParser<JsonBoolean>("TRUE");
			parser.nextJsonBoolean();
			fail("JsonParseException should have been thrown...");
		} catch (JsonParseException e) {
			// nothing to do
		} catch (IOException e) {
			fail("IOException occurred...");
		}

		try {
			DuDeJsonParser<JsonBoolean> parser = new DuDeJsonParser<JsonBoolean>("tRue");
			parser.nextJsonBoolean();
			fail("JsonParseException should have been thrown...");
		} catch (JsonParseException e) {
			// nothing to do
		} catch (IOException e) {
			fail("IOException occurred...");
		}

		try {
			DuDeJsonParser<JsonBoolean> parser = new DuDeJsonParser<JsonBoolean>("false");
			assertEquals(JsonBoolean.FALSE, parser.nextJsonBoolean());
		} catch (JsonParseException e) {
			fail("JsonParseException occurred...");
		} catch (IOException e) {
			fail("IOException occurred...");
		}

		try {
			DuDeJsonParser<JsonBoolean> parser = new DuDeJsonParser<JsonBoolean>("FALSE");
			parser.nextJsonBoolean();
			fail("JsonParseException should have been thrown...");
		} catch (JsonParseException e) {
			// nothing to do
		} catch (IOException e) {
			fail("IOException occurred...");
		}

		try {
			DuDeJsonParser<JsonBoolean> parser = new DuDeJsonParser<JsonBoolean>("falSe");
			parser.nextJsonBoolean();
			fail("JsonParseException should have been thrown...");
		} catch (JsonParseException e) {
			// nothing to do
		} catch (IOException e) {
			fail("IOException occurred...");
		}
	}

	/**
	 * Tests the <code>JsonNull</code> parsing.
	 */
	@Test
	public void testNextJsonNull() {
		try {
			DuDeJsonParser<JsonNull> parser = new DuDeJsonParser<JsonNull>("null");
			assertEquals(JsonNull.NULL, parser.nextJsonNull());
		} catch (JsonParseException e) {
			fail("JsonParseException occurred...");
		} catch (IOException e) {
			fail("IOException occurred...");
		}
	}

	/**
	 * Tests the {@link JsonArray} parsing.
	 */
	@Test
	public void testNextJsonArray() {
		try {
			JsonArray array = new JsonArray();
			array.add(JsonNull.NULL);
			array.add(JsonBoolean.TRUE);
			array.add(new JsonNumber(1.0));
			array.add(new JsonString("asd\\\"  asd"));
			array.add(new JsonArray());

			DuDeJsonParser<JsonArray> parser = new DuDeJsonParser<JsonArray>("[null, true, 1.0, \"asd\\\\\\\"  asd\", []]");
			assertEquals(array, parser.nextJsonArray());
		} catch (JsonParseException e) {
			fail("JsonParseException occurred...");
		} catch (IOException e) {
			fail("IOException occurred...");
		}
	}

	/**
	 * Tests the {@link JsonArray} parsing.
	 */
	@Test
	public void testNextJsonRecord() {
		try {
			JsonRecord record = new JsonRecord();
			record.put("attr1", new JsonString("string"));
			record.put("attr2", new JsonNumber(1));
			record.put("attr3", JsonNull.NULL);
			
			JsonArray arr = new JsonArray();
			arr.add(JsonBoolean.TRUE);
			arr.add(JsonBoolean.FALSE);
			record.put("attr4", arr);
			
			record.put("attr5", new JsonRecord());
			DuDeJsonParser<JsonRecord> parser = new DuDeJsonParser<JsonRecord>("{ \"attr1\"  : \"string\",\"attr2\":1,\"attr3\"  :  null,  \"attr4\": [true, false], \"attr5\":{}}");
			assertEquals(record, parser.nextJsonRecord());
		} catch (JsonParseException e) {
			fail("JsonParseException occurred...");
		} catch (IOException e) {
			fail("IOException occurred...");
		}
	}

	/**
	 * Tests the {@link Iterator} functionality of {@link DuDeJsonParser}.
	 */
	@Test
	public void testJsonArrayIteration() {
		DuDeJsonParser<JsonValue> parser = null;
		try {
			parser = new DuDeJsonParser<JsonValue>("[null, true, 1.0, \"asd\\\\\\\"  asd\", []]");
		} catch (JsonParseException e) {
			fail("JsonParseException occurred...");
		} catch (IOException e) {
			fail("IOException occurred...");
		}

		assertTrue(parser.hasNext());
		assertEquals(JsonNull.NULL, parser.next());

		assertTrue(parser.hasNext());
		assertEquals(JsonBoolean.TRUE, parser.next());

		assertTrue(parser.hasNext());
		assertEquals(new JsonNumber(1.0), parser.next());

		assertTrue(parser.hasNext());
		assertEquals(new JsonString("asd\\\"  asd"), parser.next());

		assertTrue(parser.hasNext());
		assertEquals(new JsonArray(), parser.next());

		assertFalse(parser.hasNext());
		try {
			parser.next();
			fail("NoSuchElementException should have been thrown...");
		} catch (NoSuchElementException e) {
			// nothing to do
		}
		
		try {
			parser = new DuDeJsonParser<JsonValue>("[]");
		} catch (JsonParseException e) {
			fail("JsonJsonParseException occurred...");
		} catch (IOException e) {
			fail("IOException occurred...");
		}
		
		assertFalse(parser.hasNext());
		try {
			parser.next();
			fail("NoSuchElementException should have been thrown...");
		} catch (NoSuchElementException e) {
			// nothing to do
		}
	}
}
