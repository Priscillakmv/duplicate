/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.util;

import static junit.framework.Assert.assertEquals;

import org.junit.Test;

import de.hpi.fgis.dude.util.data.json.JsonUtil;
import de.hpi.fgis.dude.util.sorting.sortingkey.NumberBasedSubkey;
import de.hpi.fgis.dude.util.sorting.sortingkey.SortingKey;
import de.hpi.fgis.dude.util.sorting.sortingkey.Subkey;
import de.hpi.fgis.dude.util.sorting.sortingkey.TextBasedSubkey;

/**
 * Tests the serialization of {@link SortingKey} and {@link Subkey}s.
 * 
 * @author Arvid.Heise
 */
public class SortingKeySerializationTest {
	/**
	 * 
	 */
	@Test
	public void testEmptyKey() {
		testKey(new SortingKey());
	}

	/**
	 * 
	 */
	@Test
	public void testSimpleTextKey() {
		testKey(new SortingKey(new TextBasedSubkey("name")));
	}

	/**
	 * 
	 */
	@Test
	public void testCombinedTextKey() {
		testKey(new SortingKey(new TextBasedSubkey("name"), new TextBasedSubkey("zip"), new TextBasedSubkey("city")));
	}

	/**
	 * 
	 */
	@Test
	public void testRegexTextKey() {
		TextBasedSubkey subkey = new TextBasedSubkey("name");
		subkey.setIgnoredCharactersRegEx("regex");
		testKey(new SortingKey(subkey));
	}

	/**
	 * 
	 */
	@Test
	public void testFirstCharacterTextKey() {
		TextBasedSubkey subkey = new TextBasedSubkey("name");
		subkey.setRange(13);
		testKey(new SortingKey(subkey));
	}

	/**
	 * 
	 */
	@Test
	public void testPositionsTextKey() {
		TextBasedSubkey subkey = new TextBasedSubkey("name");
		subkey.setPositions(3, 4, 5, 10);
		testKey(new SortingKey(subkey));
	}

	/**
	 * 
	 */
	@Test
	public void testSimpleNumberKey() {
		testKey(new SortingKey(new NumberBasedSubkey("name")));
	}

	/**
	 * 
	 */
	@Test
	public void testCombinedNumberKey() {
		testKey(new SortingKey(new NumberBasedSubkey("name"), new NumberBasedSubkey("zip"), new NumberBasedSubkey("city")));
	}

	/**
	 * 
	 */
	@Test
	public void testFirstCharacterNumberKey() {
		NumberBasedSubkey subkey = new NumberBasedSubkey("name");
		subkey.setRange(13);
		testKey(new SortingKey(subkey));
	}

	/**
	 * 
	 */
	@Test
	public void testPositionsNumberKey() {
		NumberBasedSubkey subkey = new NumberBasedSubkey("name");
		subkey.setPositions(1, 3, 5);
		testKey(new SortingKey(subkey));
	}

	/**
	 * Serializes and deserializes the given key and checks for equality.
	 */
	private void testKey(SortingKey sortingKey) {
		String json = JsonUtil.toJson(sortingKey);
//		System.out.println(json);
		assertEquals(sortingKey, JsonUtil.fromJson(json, sortingKey.getClass()));
	}
}
