/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.util.data.storage;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.util.GlobalConfig;
import de.hpi.fgis.dude.util.data.Jsonable;
import de.hpi.fgis.dude.util.data.json.DuDeJsonGenerator;
import de.hpi.fgis.dude.util.data.json.JsonArray;
import de.hpi.fgis.dude.util.data.json.JsonBoolean;
import de.hpi.fgis.dude.util.data.json.JsonNull;
import de.hpi.fgis.dude.util.data.json.JsonNumber;
import de.hpi.fgis.dude.util.data.json.JsonRecord;
import de.hpi.fgis.dude.util.data.json.JsonString;
import de.hpi.fgis.dude.util.data.json.JsonValue;

/**
 * Tests {@link InputStreamReadable}.
 * 
 * @author Matthias Pohl
 */
public class InputStreamReadableTest {

	private File jsonFile;

	/**
	 * The directory where the test file is located.
	 */
	protected final String filePath = GlobalConfig.getInstance().getWorkingDirectory();

	/**
	 * Name of the file.
	 */
	protected final String filename = "inputStreamReadableTest";

	/**
	 * The content of the test file.
	 */
	protected final Collection<JsonValue> fileContent = new ArrayList<JsonValue>();

	private void initializeValues() {
		this.fileContent.add(new JsonString("test"));
		this.fileContent.add(new JsonNumber(123));
		this.fileContent.add(JsonBoolean.TRUE);
		this.fileContent.add(JsonNull.NULL);
		this.fileContent.add(new JsonArray(new JsonString("array")));

		JsonRecord record = new JsonRecord();
		record.put("attr", "record");
		this.fileContent.add(record);
	}

	/**
	 * The preset of each test method.
	 * 
	 * @throws Exception
	 *             If an error occurs while initializing the test methods.
	 */
	@Before
	public void setUp() throws Exception {
		this.initializeValues();

		this.jsonFile = new File(this.filePath + this.filename + FileBasedStorage.JSON_FILE_EXTENSION);

		DuDeJsonGenerator jsonGenerator = new DuDeJsonGenerator(new FileWriter(this.jsonFile));
		jsonGenerator.writeArrayStart();
		for (Jsonable jsonable : this.fileContent) {
			jsonable.toJson(jsonGenerator);
		}
		jsonGenerator.writeArrayEnd();
		jsonGenerator.close();
	}

	/**
	 * The tear-down method for each test method.
	 * 
	 * @throws Exception
	 *             If an error occurs during the method call.
	 */
	@After
	public void tearDown() throws Exception {
		this.jsonFile.delete();
	}

	/**
	 * Tests {@link InputStreamReadable#getReader()}.
	 */
	@Test
	public void testGetReader() {
		InputStreamReadable<JsonValue> jsonReadable = null;
		try {
			jsonReadable = new InputStreamReadable<JsonValue>(new FileInputStream(this.jsonFile));
		} catch (FileNotFoundException e) {
			fail("FileNotFoundException occurred...");
		}

		JsonableReader<JsonValue> reader = jsonReadable.getReader();

		assertNotNull(reader);

		Iterator<JsonValue> iterator = reader.iterator();
		for (JsonValue expectedValue : this.fileContent) {
			assertTrue(iterator.hasNext());
			assertEquals(expectedValue, iterator.next());
		}

		assertFalse(iterator.hasNext());
		try {
			iterator.next();
			fail("NoSuchElementException should have been thrown...");
		} catch (NoSuchElementException e) {
			// nothing to do
		}

		try {
			reader.close();
		} catch (IOException e) {
			fail("IOException occurred...");
		}
	}

	/**
	 * Tests {@link InputStreamReadable#size()}.
	 */
	@Test
	public void testSize() {
		try {
			new InputStreamReadable<JsonValue>(new FileInputStream(this.jsonFile)).size();
			fail("UnsupportedOperationException should have been thrown...");
		} catch (FileNotFoundException e) {
			fail("FileNotFoundException occurred...");
		} catch (UnsupportedOperationException e) {
			// nothing to do
		}
	}

}
