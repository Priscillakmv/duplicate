/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.datasource;

import java.io.File;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;

import de.hpi.fgis.dude.util.data.json.JsonRecord;
import de.hpi.fgis.dude.util.data.json.JsonString;

/**
 * Tests {@link CSVSource}.
 * 
 * @author Matthias Pohl
 * 
 */
public class CSVSourceTest extends AbstractDataSourceTest<CSVSource> {

	private File dataFile;

	@Override
	@Before
	public void setUp() throws Exception {
		super.setUp();

		this.dataSource = new CSVSource("csv", this.dataFile);
		this.dataSource.enableHeader();
	}

	@Override
	@After
	public void tearDown() throws Exception {
		// close all file connections before the file is deleted
		super.tearDown();
		
		this.dataFile.delete();
	}

	@Override
	protected void initializeData() throws Exception {
		this.dataFile = File.createTempFile("CSVSourceTest", ".csv");

		PrintStream writer = new PrintStream(this.dataFile);

		writer.println("attr1;" + AbstractDataSourceTest.DEFAULT_ID_ATTRIBUTE + ";attr2;attr3");
		writer.println("0;asd0;true;null");
		writer.println("1;asd1;false;null");
		writer.println("2;asd2;true;null");

		writer.close();
	}

	@Override
	protected void initializeRecords() {
		this.record0 = new JsonRecord();
		this.record0.put(AbstractDataSourceTest.DEFAULT_ID_ATTRIBUTE, new JsonString("asd0"));
		this.record0.put("attr1", new JsonString("0"));
		this.record0.put("attr2", new JsonString("true"));
		this.record0.put("attr3", new JsonString("null"));

		this.record1 = new JsonRecord();
		this.record1.put(AbstractDataSourceTest.DEFAULT_ID_ATTRIBUTE, new JsonString("asd1"));
		this.record1.put("attr1", new JsonString("1"));
		this.record1.put("attr2", new JsonString("false"));
		this.record1.put("attr3", new JsonString("null"));

		this.record2 = new JsonRecord();
		this.record2.put(AbstractDataSourceTest.DEFAULT_ID_ATTRIBUTE, new JsonString("asd2"));
		this.record2.put("attr1", new JsonString("2"));
		this.record2.put("attr2", new JsonString("true"));
		this.record2.put("attr3", new JsonString("null"));
	}

}
