/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.algorithm;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.datasource.DataSource;
import de.hpi.fgis.dude.datasource.DuDeObjectSource;
import de.hpi.fgis.dude.util.data.DuDeObject;
import de.hpi.fgis.dude.util.data.DuDeObjectPair;
import de.hpi.fgis.dude.util.data.DuDeObjectPair.GeneratedBy;
import de.hpi.fgis.dude.util.data.json.JsonArray;
import de.hpi.fgis.dude.util.data.json.JsonRecord;
import de.hpi.fgis.dude.util.data.json.JsonString;

/**
 * <code>AlgorithmTest</code> is a super class for all algorithm tests. It collects several {@link DataSource}s that can be used for testing the
 * algorithm's behavior.
 * 
 * @author Matthias Pohl
 * @param <T>
 *            The algorithm type to test.
 */
public abstract class AlgorithmTest<T extends Algorithm> {

	/**
	 * The {@link Algorithm} instance to test.
	 */
	protected T algorithm;

	/**
	 * The name of the id attribute.
	 */
	protected static final String ID_ATTRIBUTE_NAME = "id";

	/**
	 * The name of a normal attribute.
	 */
	protected static final String ATTR_ATTRIBUTE_NAME = "attr";

	/**
	 * An empty {@link DataSource}.
	 */
	protected DataSource emptyDataSource0;
	/**
	 * A second empty {@link DataSource}.
	 */
	protected DataSource emptyDataSource1;

	/**
	 * A {@link DataSource} containing one element.
	 */
	protected DataSource dataSource0;

	/**
	 * The first and only element of {@link #dataSource0}.
	 */
	protected DuDeObject obj_a0;

	/**
	 * A {@link DataSource} containing two elements.
	 */
	protected DataSource dataSource1;

	/**
	 * The first element of {@link #dataSource1}.
	 */
	protected DuDeObject obj_a1;
	/**
	 * The second element of {@link #dataSource1}.
	 */
	protected DuDeObject obj_b1;

	/**
	 * A {@link DataSource} containing three elements.
	 */
	protected DataSource dataSource2;

	/**
	 * The first element of {@link #dataSource2}.
	 */
	protected DuDeObject obj_a2;
	/**
	 * The second element of {@link #dataSource2}.
	 */
	protected DuDeObject obj_b2;
	/**
	 * The third element of {@link #dataSource2}.
	 */
	protected DuDeObject obj_c2;

	/**
	 * Initializes all {@link DataSource}s.
	 * 
	 * @throws Exception
	 *             If an error occurs while initializing the <code>DataSources</code>.
	 */
	@Before
	public void setUp() throws Exception {
		this.emptyDataSource0 = new DuDeObjectSource("empty0", new ArrayList<DuDeObject>());
		this.emptyDataSource1 = new DuDeObjectSource("empty1", new ArrayList<DuDeObject>());

		JsonRecord data;

		data = new JsonRecord();
		data.put(AlgorithmTest.ID_ATTRIBUTE_NAME, new JsonArray(new JsonString("a0")));
		data.put(AlgorithmTest.ATTR_ATTRIBUTE_NAME, new JsonArray(new JsonString("aaa")));

		this.obj_a0 = new DuDeObject(data, "src0", "a0");

		data = new JsonRecord();
		data.put(AlgorithmTest.ID_ATTRIBUTE_NAME, new JsonArray(new JsonString("a1")));
		data.put(AlgorithmTest.ATTR_ATTRIBUTE_NAME, new JsonArray(new JsonString("aaa")));

		this.obj_a1 = new DuDeObject(data, "src1", "a1");

		data = new JsonRecord();
		data.put(AlgorithmTest.ID_ATTRIBUTE_NAME, new JsonArray(new JsonString("b1")));
		data.put(AlgorithmTest.ATTR_ATTRIBUTE_NAME, new JsonArray(new JsonString("bbb")));

		this.obj_b1 = new DuDeObject(data, "src1", "b1");

		data = new JsonRecord();
		data.put(AlgorithmTest.ID_ATTRIBUTE_NAME, new JsonArray(new JsonString("a2")));
		data.put(AlgorithmTest.ATTR_ATTRIBUTE_NAME, new JsonArray(new JsonString("aaa")));

		this.obj_a2 = new DuDeObject(data, "src2", "a2");

		data = new JsonRecord();
		data.put(AlgorithmTest.ID_ATTRIBUTE_NAME, new JsonArray(new JsonString("b2")));
		data.put(AlgorithmTest.ATTR_ATTRIBUTE_NAME, new JsonArray(new JsonString("bbb")));

		this.obj_b2 = new DuDeObject(data, "src2", "b2");

		data = new JsonRecord();
		data.put(AlgorithmTest.ID_ATTRIBUTE_NAME, new JsonArray(new JsonString("c2")));
		data.put(AlgorithmTest.ATTR_ATTRIBUTE_NAME, new JsonArray(new JsonString("ccc")));

		this.obj_c2 = new DuDeObject(data, "src2", "c2");

		Collection<DuDeObject> coll;

		coll = new ArrayList<DuDeObject>();

		coll.add(this.obj_a0);
		this.dataSource0 = new DuDeObjectSource("src0", coll);

		coll = new ArrayList<DuDeObject>();

		coll.add(this.obj_b1);
		coll.add(this.obj_a1);
		this.dataSource1 = new DuDeObjectSource("src1", coll);

		coll = new ArrayList<DuDeObject>();

		coll.add(this.obj_c2);
		coll.add(this.obj_b2);
		coll.add(this.obj_a2);
		this.dataSource2 = new DuDeObjectSource("src2", coll);
	}

	/**
	 * Finalization method.
	 * 
	 * @throws Exception
	 *             If an error occurs while initializing the <code>DataSources</code>.
	 */
	@After
	public void tearDown() throws Exception {
		// nothing to do
	}

	/**
	 * Generates a algorithm-generated pair that contains the passed {@link DuDeObject}s.
	 * 
	 * @param obj1
	 *            The first object of the pair.
	 * @param obj2
	 *            The second object of the pair.
	 * @return The corresponding {@link DuDeObjectPair}.
	 */
	protected DuDeObjectPair getPair(DuDeObject obj1, DuDeObject obj2) {
		DuDeObjectPair pair = new DuDeObjectPair(obj1, obj2);

		pair.setLineage(GeneratedBy.Algorithm);

		return pair;
	}

	/**
	 * Tests the algorithm's result if an empty {@link DataSource} is attached.
	 */
	@Test
	public void testEmptyDataSource() {
		this.algorithm.addDataSource(this.emptyDataSource0);

		this.testIterator(this.algorithm.iterator());
	}

	/**
	 * Tests the algorithm's result if several empty {@link DataSource}s are attached.
	 */
	@Test
	public void testMultipleEmptyDataSources() {
		this.algorithm.addDataSource(this.emptyDataSource0);
		this.algorithm.addDataSource(this.emptyDataSource1);

		this.testIterator(this.algorithm.iterator());
	}

	/**
	 * Tests the algorithm's result if a {@link DataSource} containing one {@link DuDeObject} is attached.
	 */
	@Test
	public void testOneElementDataSource() {
		this.algorithm.addDataSource(this.dataSource0);

		this.testIterator(this.algorithm.iterator());
	}

	/**
	 * Tests the content returned by the passed iterator.
	 * 
	 * @param iterator
	 *            The iterator of which the content shall be checked.
	 * @param expectedContent
	 *            The expected content.
	 */
	protected void testIterator(Iterator<DuDeObjectPair> iterator, DuDeObjectPair... expectedContent) {
		assertNotNull(iterator);

		for (int i = 0; i < expectedContent.length; i++) {
			assertTrue("hasNext() failed: All elements starting with index #" + i + " are missing.", iterator.hasNext());
			try {
				assertEquals("next() failed: Element #" + i + " is wrong.", expectedContent[i], iterator.next());
			} catch (NoSuchElementException e) {
				fail("NoSuchElementException occurred...");
			}
		}

		assertFalse(iterator.hasNext());
		try {
			iterator.next();
			fail("NoSuchElementException should have been thrown...");
		} catch (NoSuchElementException e) {
			// expected behavior
		}
	}
}
