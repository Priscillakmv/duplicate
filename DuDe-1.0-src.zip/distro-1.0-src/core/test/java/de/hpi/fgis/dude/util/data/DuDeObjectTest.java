/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.util.data;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.text.ParseException;
import java.util.Iterator;

import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.util.data.json.DuDeJsonGenerator;
import de.hpi.fgis.dude.util.data.json.DuDeJsonParser;
import de.hpi.fgis.dude.util.data.json.JsonArray;
import de.hpi.fgis.dude.util.data.json.JsonNumber;
import de.hpi.fgis.dude.util.data.json.JsonRecord;
import de.hpi.fgis.dude.util.data.json.JsonString;

/**
 * Tests the {@link DuDeObject} class.
 * 
 * @author Matthias Pohl
 */
public class DuDeObjectTest {

	private DuDeObject obj;
	private DuDeObject objReference;

	private String sourceId;
	private JsonArray objectId = new JsonArray();

	private JsonRecord data;

	private JsonArray nameAttribute;
	private JsonArray ageAttribute;

	/**
	 * The preset of each test method.
	 * 
	 * @throws Exception
	 *             If an error occurs while initializing the test methods.
	 */
	@Before
	public void setUp() throws Exception {
		this.sourceId = "sourceId";
		this.objectId.add(new JsonString("objectId"));

		this.data = new JsonRecord();

		this.nameAttribute = new JsonArray(new JsonString("Gustav"));
		this.data.put("name", this.nameAttribute);

		this.ageAttribute = new JsonArray(new JsonNumber(35));
		this.data.put("age", this.ageAttribute);

		this.obj = new DuDeObject(this.data, this.sourceId, this.objectId);
		this.objReference = new DuDeObject(this.sourceId, this.objectId);
	}

	/**
	 * Tests {@link DuDeObject#DuDeObject(JsonRecord, String, String)}.
	 */
	@Test
	public void testDuDeObject() {
		DuDeObject obj = new DuDeObject(this.data, this.sourceId, this.objectId);
		assertNotNull(obj);

		try {
			obj = new DuDeObject(new JsonRecord(), null, "");
			fail("NullPointerException should have been thrown...");
		} catch (NullPointerException e) {
			// nothing to do
		}

		try {
			obj = new DuDeObject(new JsonRecord(), "", (String) null);
			fail("NullPointerException should have been thrown...");
		} catch (NullPointerException e) {
			// nothing to do
		}

		try {
			obj = new DuDeObject(new JsonRecord(), null, (String) null);
			fail("NullPointerException should have been thrown...");
		} catch (NullPointerException e) {
			// nothing to do
		}

		try {
			obj = new DuDeObject((String) null, "");
			fail("NullPointerException should have been thrown...");
		} catch (NullPointerException e) {
			// nothing to do
		}

		try {
			obj = new DuDeObject("", (String) null);
			fail("NullPointerException should have been thrown...");
		} catch (NullPointerException e) {
			// nothing to do
		}

		try {
			obj = new DuDeObject((String) null, (String) null);
			fail("NullPointerException should have been thrown...");
		} catch (NullPointerException e) {
			// nothing to do
		}
	}

	/**
	 * Tests the merge functionality of a {@link DuDeObject}.
	 */
	@Test
	public void testMergedObjectFunctionality() {
		DuDeObject object = new DuDeObject(new JsonRecord(), "srcId", "objId1");

		assertFalse(object.isMerged());
		assertEquals(0, object.getMergeCount());
		Iterator<DuDeObjectId> idIterator = object.getIdentifiers().iterator();
		assertEquals(object.getIdentifier(), idIterator.next());
		assertFalse(idIterator.hasNext());

		DuDeObjectId id2 = new DuDeObjectId("srcId", new JsonArray(new JsonString("objId2")));
		object.addIdentifier(id2);

		assertTrue(object.isMerged());
		assertEquals(2, object.getMergeCount());

		idIterator = object.getIdentifiers().iterator();
		assertTrue(idIterator.hasNext());
		assertEquals(object.getIdentifier(), idIterator.next());
		assertTrue(idIterator.hasNext());
		assertEquals(id2, idIterator.next());

		assertFalse(idIterator.hasNext());
	}
	
	/**
	 * Tests the serialization of a merged {@link DuDeObject}.
	 * @throws IOException 
	 * @throws ParseException 
	 */
	@Test
	public void testMergedObjectSerialization() throws IOException, ParseException {
		DuDeObjectId id1 = new DuDeObjectId("srcId", new JsonArray(new JsonString("objId1")));
		DuDeObjectId id2 = new DuDeObjectId("srcId", new JsonArray(new JsonString("objId2")));
		
		DuDeObject object = new DuDeObject(new JsonRecord(), id1.getSourceId(), id1.getObjectId());
		object.addIdentifier(id2);

		StringWriter strWriter = new StringWriter();
		DuDeJsonGenerator jsonGenerator = new DuDeJsonGenerator(strWriter);
		object.toJson(jsonGenerator);
		
		DuDeJsonParser<DuDeObject> jsonParser = new DuDeJsonParser<DuDeObject>(DuDeObject.class, new StringReader(strWriter.toString()));
		DuDeObject parsedObject = jsonParser.next();
		
		assertEquals(object, parsedObject);
	}

	/**
	 * Tests {@link DuDeObject#getIdentifier()}.
	 */
	@Test
	public void testGetIdentifier() {
		assertTrue(this.obj.getIdentifier().equals(this.objReference.getIdentifier()));
		assertEquals(this.obj.getIdentifier(), this.objReference.getIdentifier());
	}

	/**
	 * Tests {@link DuDeObject#getSourceId()}.
	 */
	@Test
	public void testGetSourceId() {
		assertEquals(this.sourceId, this.obj.getSourceId());
		assertEquals(this.obj.getSourceId(), this.objReference.getSourceId());
	}

	/**
	 * Tests {@link DuDeObject#getObjectId()}.
	 */
	@Test
	public void testGetObjectId() {
		assertEquals(this.objectId, this.obj.getObjectId());
		assertEquals(this.obj.getObjectId(), this.objReference.getObjectId());
	}

	/**
	 * Tests {@link DuDeObject#getData()}.
	 */
	@Test
	public void testGetObjectData() {
		assertEquals(this.data, this.obj.getData());
		assertNull(this.objReference.getData());
	}

	/**
	 * Tests {@link DuDeObject#equals(Object)}.
	 */
	@Test
	public void testEqualsObject() {
		DuDeObject otherObj = new DuDeObject(new JsonRecord(), this.obj.getSourceId(), this.obj.getObjectId() + "2");

		assertTrue(this.obj.equals(this.obj));

		assertFalse(this.obj.equals(otherObj));
		assertFalse(otherObj.equals(this.obj));

		assertFalse(this.obj.equals(null));

		assertFalse(this.obj.equals(null));
		assertFalse(this.obj.equals("A string representing another object"));

		assertTrue(this.objReference.equals(this.obj));
		assertTrue(this.obj.equals(this.objReference));
	}

	/**
	 * Tests {@link DuDeObject#getAttributeValues(String)}.
	 */
	@Test
	public void testGetJsonValue() {
		assertEquals(this.nameAttribute, this.obj.getAttributeValues("name"));
		assertEquals(this.ageAttribute, this.obj.getAttributeValues("age"));
		assertNull(this.obj.getAttributeValues("xyz"));
		assertNull(this.obj.getAttributeValues(null));

		assertNull(this.objReference.getAttributeValues("does not exist"));
	}

}
