/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Tests the {@link FilenameManager} class.
 * 
 * @author Matthias Pohl
 */
public class FilenameManagerTest {

	private File notExistingDirectory = new File("./notExistingDir");
	private File existingFile = new File("./bla.txt");

	/**
	 * The preset of each test method.
	 * 
	 * @throws Exception
	 *             If an error occurs while initializing the test methods.
	 */
	@Before
	public void setUp() throws Exception {
		this.existingFile.createNewFile();
	}

	/**
	 * The tear-down method for each test method.
	 * 
	 * @throws Exception
	 *             If an error occurs during the method call.
	 */
	@After
	public void tearDown() throws Exception {
		this.notExistingDirectory.delete();
		this.existingFile.delete();
	}

	/**
	 * Tests {@link FilenameManager#FilenameManager(String)}.
	 */
	@Test
	public void testFilenameManager() {
		assertFalse(this.notExistingDirectory.exists());

		try {
			@SuppressWarnings("unused")
			FilenameManager filenameManager = new FilenameManager(this.notExistingDirectory.getPath());
		} catch (IllegalArgumentException e) {
			fail("IllegalArgumentException occurred...");
		}
		assertTrue(this.notExistingDirectory.exists());

		try {
			@SuppressWarnings("unused")
			FilenameManager filenameManager = new FilenameManager(this.existingFile.getPath());
			fail("IllegalArgumentException should have been thrown...");
		} catch (IllegalArgumentException e) {
			// nothing to do
		}

	}

	/**
	 * Tests {@link FilenameManager#getNextValidFilename(String)}.
	 */
	@Test
	public void testGetNextValidFilename() {
		FilenameManager filenameManager = new FilenameManager(this.notExistingDirectory.getPath());

		assertEquals("bla", filenameManager.getNextValidFilename("bla"));
		assertEquals("bla1", filenameManager.getNextValidFilename("bla"));
		assertEquals("bla2", filenameManager.getNextValidFilename("bla"));
		assertEquals("bla3", filenameManager.getNextValidFilename("bla"));
	}

}
