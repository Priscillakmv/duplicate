/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2011  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.algorithm.duplicatedetection;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.algorithm.AbstractDuplicateDetectionTest;
import de.hpi.fgis.dude.algorithm.AlgorithmTest;
import de.hpi.fgis.dude.datasource.DataSource;
import de.hpi.fgis.dude.datasource.DuDeObjectSource;
import de.hpi.fgis.dude.util.data.DuDeObject;
import de.hpi.fgis.dude.util.data.DuDeObjectId;
import de.hpi.fgis.dude.util.data.DuDeObjectPair;
import de.hpi.fgis.dude.util.data.json.JsonArray;
import de.hpi.fgis.dude.util.data.json.JsonRecord;
import de.hpi.fgis.dude.util.data.json.JsonString;
import de.hpi.fgis.dude.util.merger.DefaultMerger;
import de.hpi.fgis.dude.util.merger.Merger;
import de.hpi.fgis.dude.util.sorting.sortingkey.SortingKey;
import de.hpi.fgis.dude.util.sorting.sortingkey.TextBasedSubkey;

/**
 * Tests {@link Lego}.
 * 
 * @author Florian Thomas
 */
public class LegoTest extends AbstractDuplicateDetectionTest<Lego> {
	
	private static final String ATTR2_ATTRIBUTE_NAME = "attr2";
	
	private DuDeObject obj_r;
	private DuDeObject obj_s;
	private DuDeObject obj_t;
	private DataSource legoSource0;
	
	private DuDeObject obj_u;
	private DuDeObject obj_v;
	private DataSource legoSource1;
	
	private DuDeObject obj_w;
	private DuDeObject obj_x;
	private DuDeObject obj_y;
	private DuDeObject obj_z;
	private DataSource legoSource2;
	
	@Override
	@Before
	public void setUp() throws Exception {
		
		super.setUp();
		
		JsonRecord data;
		
		data = new JsonRecord();
		data.put(ID_ATTRIBUTE_NAME, new JsonArray(new JsonString("r")));
		data.put(ATTR_ATTRIBUTE_NAME, new JsonArray(new JsonString("1")));
		data.put(ATTR2_ATTRIBUTE_NAME, new JsonArray(new JsonString("213")));

		this.obj_r = new DuDeObject(data, "src1", "r");

		data = new JsonRecord();
		data.put(ID_ATTRIBUTE_NAME, new JsonArray(new JsonString("s")));
		data.put(ATTR_ATTRIBUTE_NAME, new JsonArray(new JsonString("2")));
		data.put(ATTR2_ATTRIBUTE_NAME, new JsonArray(new JsonString("214")));

		this.obj_s = new DuDeObject(data, "src1", "s");

		data = new JsonRecord();
		data.put(ID_ATTRIBUTE_NAME, new JsonArray(new JsonString("t")));
		data.put(ATTR_ATTRIBUTE_NAME, new JsonArray(new JsonString("2")));
		data.put(ATTR2_ATTRIBUTE_NAME, new JsonArray(new JsonString("2")));

		this.obj_t = new DuDeObject(data, "src1", "t");

		data = new JsonRecord();
		data.put(ID_ATTRIBUTE_NAME, new JsonArray(new JsonString("u")));
		data.put(ATTR_ATTRIBUTE_NAME, new JsonArray(new JsonString("3")));
		data.put(ATTR2_ATTRIBUTE_NAME, new JsonArray(new JsonString("3")));

		this.obj_u = new DuDeObject(data, "src1", "u");

		data = new JsonRecord();
		data.put(ID_ATTRIBUTE_NAME, new JsonArray(new JsonString("v")));
		data.put(ATTR_ATTRIBUTE_NAME, new JsonArray(new JsonString("3")));
		data.put(ATTR2_ATTRIBUTE_NAME, new JsonArray(new JsonString("3")));

		this.obj_v = new DuDeObject(data, "src1", "v");

		data = new JsonRecord();
		data.put(ID_ATTRIBUTE_NAME, new JsonArray(new JsonString("w")));
		data.put(ATTR_ATTRIBUTE_NAME, new JsonArray(new JsonString("4")));
		data.put(ATTR2_ATTRIBUTE_NAME, new JsonArray(new JsonString("2")));

		this.obj_w = new DuDeObject(data, "src2", "w");

		data = new JsonRecord();
		data.put(ID_ATTRIBUTE_NAME, new JsonArray(new JsonString("x")));
		data.put(ATTR_ATTRIBUTE_NAME, new JsonArray(new JsonString("5")));
		data.put(ATTR2_ATTRIBUTE_NAME, new JsonArray(new JsonString("3")));

		this.obj_x = new DuDeObject(data, "src2", "x");

		data = new JsonRecord();
		data.put(ID_ATTRIBUTE_NAME, new JsonArray(new JsonString("y")));
		data.put(ATTR_ATTRIBUTE_NAME, new JsonArray(new JsonString("4")));
		data.put(ATTR2_ATTRIBUTE_NAME, new JsonArray(new JsonString("5")));

		this.obj_y = new DuDeObject(data, "src2", "y");

		data = new JsonRecord();
		data.put(ID_ATTRIBUTE_NAME, new JsonArray(new JsonString("z")));
		data.put(ATTR_ATTRIBUTE_NAME, new JsonArray(new JsonString("5")));
		data.put(ATTR2_ATTRIBUTE_NAME, new JsonArray(new JsonString("5")));

		this.obj_z = new DuDeObject(data, "src2", "z");

		Collection<DuDeObject> coll;

		coll = new ArrayList<DuDeObject>();

		coll.add(this.obj_r);
		coll.add(this.obj_s);
		coll.add(this.obj_t);
		this.legoSource0 = new DuDeObjectSource("src0", coll);

		coll = new ArrayList<DuDeObject>();

		coll.add(this.obj_r);
		coll.add(this.obj_s);
		coll.add(this.obj_t);
		coll.add(this.obj_u);
		coll.add(this.obj_v);
		this.legoSource1 = new DuDeObjectSource("src1", coll);

		coll.add(this.obj_w);
		coll.add(this.obj_x);
		coll.add(this.obj_y);
		coll.add(this.obj_z);
		this.legoSource2 = new DuDeObjectSource("src2", coll);
		
		SortingKey firstBlockingCriterion =
			new SortingKey(new TextBasedSubkey(AlgorithmTest.ATTR_ATTRIBUTE_NAME));
		
		// Use only a part of the attribute value as blocking criterion
		TextBasedSubkey secondSubkey = new TextBasedSubkey(ATTR2_ATTRIBUTE_NAME);
		secondSubkey.setRange(0, 2);
		SortingKey secondBlockingCriterion = new SortingKey(secondSubkey);
		
		this.algorithm = new Lego(firstBlockingCriterion, secondBlockingCriterion);
		
		this.algorithm.setCoreERAlgorithm(new NaiveDuplicateDetection());
		this.algorithm.setMerger(new DefaultMerger());
		this.algorithm.enableInMemoryProcessing();
	}
	
	@Override
	@After
	public void tearDown() throws Exception {
		super.tearDown();
	}
	
	protected boolean isDuplicate(DuDeObjectPair pair, DuDeObjectPair... duplicates) {
		for (DuDeObjectId left: pair.getFirstElement().getIdentifiers()) {
			for (DuDeObjectId right: pair.getSecondElement().getIdentifiers()) {
				for (DuDeObjectPair duplicate: duplicates) {
					DuDeObjectId firstId = duplicate.getFirstElement().getIdentifier();
					DuDeObjectId secondId = duplicate.getSecondElement().getIdentifier();
					if ((firstId.equals(left) && secondId.equals(right)) ||
							(firstId.equals(right) && secondId.equals(left)))
						return true;
				}
			}
		}
		return false;
	}
	
	protected void legoTestIterator(Iterator<DuDeObjectPair> iterator, DuDeObjectPair[] duplicates,
			DuDeObjectPair... expectedContent) {
		
		assertNotNull(iterator);
		
		for (int i = 0; i < expectedContent.length; i++) {
			assertTrue("hasNext() failed: All elements starting with index #" + i + " are missing.", iterator.hasNext());
			try {
				DuDeObjectPair next = iterator.next();
				assertEquals("next() failed: Element #" + i + " is wrong.", expectedContent[i], next);
				if (isDuplicate(next, duplicates)) {
					this.algorithm.notifyOfLatestComparisonResult(Lego.ComparisonResult.DUPLICATE);
				} else {
					this.algorithm.notifyOfLatestComparisonResult(Lego.ComparisonResult.NON_DUPLICATE);
				}
			} catch (NoSuchElementException e) {
				fail("NoSuchElementException occurred...");
			}
		}

		assertFalse(iterator.hasNext());
		try {
			iterator.next();
			fail("NoSuchElementException should have been thrown...");
		} catch (NoSuchElementException e) {
			// expected behavior
		}
	}
	
	protected DuDeObject merge(DuDeObject... objects) {
		
		Merger merger = this.algorithm.getMerger();
		
		if (objects.length == 1)
			return objects[0];
		
		if (objects.length < 1)
			return null;
		
		DuDeObject mergedObject = objects[0];
		for (int i = 1; i < objects.length; i++)
			mergedObject = merger.merge(mergedObject, objects[i]);
		
		return mergedObject;
	}
	
	@Test
	public void testLego() {
		
		this.algorithm.addDataSource(this.legoSource0);

		DuDeObjectPair[] duplicates = new DuDeObjectPair[]{getPair(this.obj_r, this.obj_s),
				getPair(this.obj_s, this.obj_t)};
		DuDeObjectPair[] expectedContent = new DuDeObjectPair[]{getPair(this.obj_r, this.obj_s),
				getPair(merge(this.obj_r, this.obj_s), this.obj_t)};

		this.legoTestIterator(this.algorithm.iterator(), duplicates, expectedContent);
	}

	/**
	 * Tests the algorithm's result if several non-empty {@link DataSource}s are attached.
	 */
	@Test
	public void testSeveralDataSources() {
		
		this.algorithm.addDataSource(this.legoSource1);
		this.algorithm.addDataSource(this.legoSource2);
		
		DuDeObjectPair[] duplicates = new DuDeObjectPair[]{getPair(this.obj_r, this.obj_s),
				getPair(this.obj_s, this.obj_t), getPair(this.obj_u, this.obj_v),
				getPair(this.obj_x, this.obj_z), getPair(this.obj_v, this.obj_x),
				getPair(this.obj_x, this.obj_y)};
		DuDeObjectPair[] expectedContent = new DuDeObjectPair[] {getPair(this.obj_r, this.obj_s),
				getPair(this.obj_t, this.obj_w), getPair(this.obj_v, this.obj_x), 
				getPair(this.obj_u, this.obj_v), getPair(this.obj_y, this.obj_z),
				getPair(merge(this.obj_r, this.obj_s), this.obj_t), getPair(this.obj_w, this.obj_y),
				getPair(merge(this.obj_u, this.obj_v, this.obj_x), this.obj_z),
				getPair(merge(this.obj_r, this.obj_s, this.obj_t), this.obj_w),
				getPair(merge(this.obj_u, this.obj_v, this.obj_x, this.obj_z), this.obj_y),
				getPair(merge(this.obj_u, this.obj_v, this.obj_x, this.obj_z, this.obj_y), this.obj_w)};
		
		this.legoTestIterator(this.algorithm.iterator(), duplicates, expectedContent);
	}
	
	/**
	 * Tests the algorithm's result if several {@link DataSource}s (empty and non-empty) are attached.
	 */
	@Test
	public void testSeveralDataSourcesWithEmptyDataSource() {
		
		this.algorithm.addDataSource(this.emptyDataSource0);
		this.algorithm.addDataSource(this.legoSource1);
		this.algorithm.addDataSource(this.legoSource2);
		
		DuDeObjectPair[] duplicates = new DuDeObjectPair[]{getPair(this.obj_r, this.obj_s),
				getPair(this.obj_s, this.obj_t), getPair(this.obj_u, this.obj_v),
				getPair(this.obj_x, this.obj_z), getPair(this.obj_v, this.obj_x),
				getPair(this.obj_x, this.obj_y)};
		DuDeObjectPair[] expectedContent = new DuDeObjectPair[] {getPair(this.obj_r, this.obj_s),
				getPair(this.obj_t, this.obj_w), getPair(this.obj_v, this.obj_x), 
				getPair(this.obj_u, this.obj_v), getPair(this.obj_y, this.obj_z),
				getPair(merge(this.obj_r, this.obj_s), this.obj_t), getPair(this.obj_w, this.obj_y),
				getPair(merge(this.obj_u, this.obj_v, this.obj_x), this.obj_z),
				getPair(merge(this.obj_r, this.obj_s, this.obj_t), this.obj_w),
				getPair(merge(this.obj_u, this.obj_v, this.obj_x, this.obj_z), this.obj_y),
				getPair(merge(this.obj_u, this.obj_v, this.obj_x, this.obj_z, this.obj_y), this.obj_w)};
		
		this.legoTestIterator(this.algorithm.iterator(), duplicates, expectedContent);
	}
	
	/**
	 * Tests if the pairs provided by the core entity resolution algorithm are preprocessed correctly
	 */
	@Test
	public void testLegoPairPreprocessing() {
		
		JsonRecord data;
		
		data = new JsonRecord();
		data.put(ID_ATTRIBUTE_NAME, new JsonArray(new JsonString("r")));
		data.put(ATTR_ATTRIBUTE_NAME, new JsonArray(new JsonString("1")));
		data.put(ATTR2_ATTRIBUTE_NAME, new JsonArray(new JsonString("1")));
		
		DuDeObject r = new DuDeObject(data, "src", "r");
		
		data = new JsonRecord();
		data.put(ID_ATTRIBUTE_NAME, new JsonArray(new JsonString("s")));
		data.put(ATTR_ATTRIBUTE_NAME, new JsonArray(new JsonString("1")));
		data.put(ATTR2_ATTRIBUTE_NAME, new JsonArray(new JsonString("2")));
		
		DuDeObject s = new DuDeObject(data, "src", "s");
		
		data = new JsonRecord();
		data.put(ID_ATTRIBUTE_NAME, new JsonArray(new JsonString("t")));
		data.put(ATTR_ATTRIBUTE_NAME, new JsonArray(new JsonString("1")));
		data.put(ATTR2_ATTRIBUTE_NAME, new JsonArray(new JsonString("2")));
		
		DuDeObject t = new DuDeObject(data, "src", "t");
		
		data = new JsonRecord();
		data.put(ID_ATTRIBUTE_NAME, new JsonArray(new JsonString("u")));
		data.put(ATTR_ATTRIBUTE_NAME, new JsonArray(new JsonString("2")));
		data.put(ATTR2_ATTRIBUTE_NAME, new JsonArray(new JsonString("2")));
		
		DuDeObject u = new DuDeObject(data, "src", "u");
		
		List<DuDeObject> coll = new ArrayList<DuDeObject>();
		
		coll.add(r);
		coll.add(s);
		coll.add(t);
		coll.add(u);
		DuDeObjectSource source = new DuDeObjectSource("src", coll);
		
		this.algorithm.addDataSource(source);
		
		DuDeObjectPair[] duplicates = new DuDeObjectPair[]{getPair(r, s),
				getPair(r, u), getPair(t, u)};
		DuDeObjectPair[] expectedContent = new DuDeObjectPair[] {getPair(s, t), 
				getPair(t, u), getPair(s, merge(t, u)), getPair(r, s), getPair(merge(r, s), merge(t, u))};
		
		this.legoTestIterator(this.algorithm.iterator(), duplicates, expectedContent);
	}
}
