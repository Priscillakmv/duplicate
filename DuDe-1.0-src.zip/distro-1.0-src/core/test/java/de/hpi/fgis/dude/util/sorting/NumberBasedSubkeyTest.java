/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.util.sorting;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.util.data.DuDeObject;
import de.hpi.fgis.dude.util.data.json.JsonArray;
import de.hpi.fgis.dude.util.data.json.JsonNull;
import de.hpi.fgis.dude.util.data.json.JsonNumber;
import de.hpi.fgis.dude.util.data.json.JsonRecord;
import de.hpi.fgis.dude.util.data.json.JsonString;
import de.hpi.fgis.dude.util.sorting.sortingkey.NumberBasedSubkey;

/**
 * Tests the {@link NumberBasedSubkey} class.
 * 
 * @author Matthias Pohl
 */
public class NumberBasedSubkeyTest {

	private DuDeObject obj_12345;
	private DuDeObject obj_54321;
	private DuDeObject obj_11111;
	private DuDeObject obj_1234;
	private DuDeObject obj_asd;
	private DuDeObject obj_null;
	private DuDeObject obj_;

	/**
	 * The preset of each test method.
	 * 
	 * @throws Exception
	 *             If an error occurs while initializing the test methods.
	 */
	@Before
	public void setUp() throws Exception {
		JsonRecord data;

		data = new JsonRecord();
		data.put("Count", new JsonArray(new JsonNumber(12345)));
		this.obj_12345 = new DuDeObject(data, "", "0");

		data = new JsonRecord();
		data.put("Count", new JsonArray(new JsonNumber(54321)));
		this.obj_54321 = new DuDeObject(data, "", "1");

		data = new JsonRecord();
		data.put("Count", new JsonArray(new JsonNumber(11111)));
		this.obj_11111 = new DuDeObject(data, "", "2");

		data = new JsonRecord();
		data.put("Count", new JsonArray(new JsonNumber(1234)));
		this.obj_1234 = new DuDeObject(data, "", "3");

		data = new JsonRecord();
		data.put("Count", new JsonArray(new JsonString("asd")));
		this.obj_asd = new DuDeObject(data, "", "4");

		data = new JsonRecord();
		data.put("Count", new JsonArray(JsonNull.NULL));
		this.obj_null = new DuDeObject(data, "", "5");

		this.obj_ = new DuDeObject(new JsonRecord(), "", "6");
	}

	/**
	 * Tests {@link NumberBasedSubkey#compare(DuDeObject, DuDeObject)} using the
	 * {@link NumberBasedSubkey#NumberBasedSubkey(String)} constructor.
	 */
	@Test
	public void testNumberBasedSubkeyString() {
		NumberBasedSubkey subkey = new NumberBasedSubkey("Count");

		assertEquals(new JsonArray(new JsonNumber(12345L)), subkey.getSubkeyValue(this.obj_12345));
		assertEquals(new JsonArray(new JsonNumber(54321L)), subkey.getSubkeyValue(this.obj_54321));
		assertEquals(new JsonArray(new JsonNumber(11111L)), subkey.getSubkeyValue(this.obj_11111));
		assertEquals(new JsonArray(new JsonNumber(1234L)), subkey.getSubkeyValue(this.obj_1234));

		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_asd));
		assertEquals(new JsonArray(new JsonNumber(0L)), subkey.getSubkeyValue(this.obj_null));
		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_));

		assertEquals(0, subkey.compare(this.obj_12345, this.obj_12345));
		assertEquals(0, subkey.compare(this.obj_54321, this.obj_54321));
		assertEquals(0, subkey.compare(this.obj_11111, this.obj_11111));
		assertEquals(0, subkey.compare(this.obj_1234, this.obj_1234));
		assertEquals(0, subkey.compare(this.obj_asd, this.obj_asd));
		assertEquals(0, subkey.compare(this.obj_null, this.obj_null));
		assertEquals(0, subkey.compare(this.obj_, this.obj_));

		assertTrue(subkey.compare(this.obj_12345, this.obj_54321) < 0);
		assertTrue(subkey.compare(this.obj_54321, this.obj_12345) > 0);

		assertTrue(subkey.compare(this.obj_11111, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_11111) > 0);

		assertTrue(subkey.compare(this.obj_1234, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_1234) > 0);

		assertTrue(subkey.compare(this.obj_12345, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_12345) > 0);

		assertTrue(subkey.compare(this.obj_null, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_null) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_null) < 0);
		assertTrue(subkey.compare(this.obj_null, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_null, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_null) > 0);
	}

	/**
	 * Tests {@link NumberBasedSubkey#compare(DuDeObject, DuDeObject)} using the
	 * {@link NumberBasedSubkey#NumberBasedSubkey(String, int)} constructor.
	 */
	@Test
	public void testNumberBasedSubkeyStringInt() {
		// all numbers should be considered
		NumberBasedSubkey subkey = new NumberBasedSubkey("Count", 20);

		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_12345));
		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_54321));
		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_11111));
		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_1234));

		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_asd));
		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_null));
		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_));

		assertEquals(0, subkey.compare(this.obj_12345, this.obj_12345));
		assertEquals(0, subkey.compare(this.obj_54321, this.obj_54321));
		assertEquals(0, subkey.compare(this.obj_11111, this.obj_11111));
		assertEquals(0, subkey.compare(this.obj_1234, this.obj_1234));
		assertEquals(0, subkey.compare(this.obj_asd, this.obj_asd));
		assertEquals(0, subkey.compare(this.obj_null, this.obj_null));

		assertEquals(0, subkey.compare(this.obj_12345, this.obj_54321));
		assertEquals(0, subkey.compare(this.obj_54321, this.obj_12345));

		subkey = new NumberBasedSubkey("Count", 3);

		assertEquals(new JsonArray(new JsonNumber(45L)), subkey.getSubkeyValue(this.obj_12345));
		assertEquals(new JsonArray(new JsonNumber(21L)), subkey.getSubkeyValue(this.obj_54321));
		assertEquals(new JsonArray(new JsonNumber(11L)), subkey.getSubkeyValue(this.obj_11111));
		assertEquals(new JsonArray(new JsonNumber(4L)), subkey.getSubkeyValue(this.obj_1234));

		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_asd));
		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_null));
		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_));

		assertEquals(0, subkey.compare(this.obj_12345, this.obj_12345));
		assertEquals(0, subkey.compare(this.obj_54321, this.obj_54321));
		assertEquals(0, subkey.compare(this.obj_11111, this.obj_11111));
		assertEquals(0, subkey.compare(this.obj_1234, this.obj_1234));
		assertEquals(0, subkey.compare(this.obj_asd, this.obj_asd));
		assertEquals(0, subkey.compare(this.obj_null, this.obj_null));

		assertTrue(subkey.compare(this.obj_54321, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_54321) > 0);

		assertTrue(subkey.compare(this.obj_11111, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_11111) > 0);

		assertTrue(subkey.compare(this.obj_1234, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_1234) > 0);

		assertTrue(subkey.compare(this.obj_12345, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_12345) > 0);

		assertTrue(subkey.compare(this.obj_null, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_null) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_null) < 0);
		assertTrue(subkey.compare(this.obj_null, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_null, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_null) > 0);

		subkey = new NumberBasedSubkey("Count", -1);

		assertEquals(new JsonArray(new JsonNumber(5L)), subkey.getSubkeyValue(this.obj_12345));
		assertEquals(new JsonArray(new JsonNumber(1L)), subkey.getSubkeyValue(this.obj_54321));
		assertEquals(new JsonArray(new JsonNumber(1L)), subkey.getSubkeyValue(this.obj_11111));
		assertEquals(new JsonArray(new JsonNumber(4L)), subkey.getSubkeyValue(this.obj_1234));

		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_asd));
		assertEquals(new JsonArray(new JsonNumber(0L)), subkey.getSubkeyValue(this.obj_null));
		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_));

		assertEquals(0, subkey.compare(this.obj_12345, this.obj_12345));
		assertEquals(0, subkey.compare(this.obj_54321, this.obj_54321));
		assertEquals(0, subkey.compare(this.obj_11111, this.obj_11111));
		assertEquals(0, subkey.compare(this.obj_1234, this.obj_1234));
		assertEquals(0, subkey.compare(this.obj_asd, this.obj_asd));
		assertEquals(0, subkey.compare(this.obj_null, this.obj_null));

		assertTrue(subkey.compare(this.obj_54321, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_54321) > 0);

		assertTrue(subkey.compare(this.obj_11111, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_11111) > 0);

		assertEquals(0, subkey.compare(this.obj_11111, this.obj_54321));
		assertEquals(0, subkey.compare(this.obj_54321, this.obj_11111));

		assertTrue(subkey.compare(this.obj_1234, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_1234) > 0);

		assertTrue(subkey.compare(this.obj_12345, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_12345) > 0);

		assertTrue(subkey.compare(this.obj_null, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_null) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_null) < 0);
		assertTrue(subkey.compare(this.obj_null, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_null, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_null) > 0);
	}

	/**
	 * Tests {@link NumberBasedSubkey#compare(DuDeObject, DuDeObject)} using the
	 * {@link NumberBasedSubkey#NumberBasedSubkey(String, int, int)} constructor.
	 */
	@Test
	public void testNumberBasedSubkeyStringIntInt() {
		// all numbers should be considered
		NumberBasedSubkey subkey = new NumberBasedSubkey("Count", 0, 20);

		assertEquals(new JsonArray(new JsonNumber(12345L)), subkey.getSubkeyValue(this.obj_12345));
		assertEquals(new JsonArray(new JsonNumber(54321L)), subkey.getSubkeyValue(this.obj_54321));
		assertEquals(new JsonArray(new JsonNumber(11111L)), subkey.getSubkeyValue(this.obj_11111));
		assertEquals(new JsonArray(new JsonNumber(1234L)), subkey.getSubkeyValue(this.obj_1234));

		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_asd));
		assertEquals(new JsonArray(new JsonNumber(0L)), subkey.getSubkeyValue(this.obj_null));
		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_));

		assertEquals(0, subkey.compare(this.obj_12345, this.obj_12345));
		assertEquals(0, subkey.compare(this.obj_54321, this.obj_54321));
		assertEquals(0, subkey.compare(this.obj_11111, this.obj_11111));
		assertEquals(0, subkey.compare(this.obj_1234, this.obj_1234));
		assertEquals(0, subkey.compare(this.obj_asd, this.obj_asd));
		assertEquals(0, subkey.compare(this.obj_null, this.obj_null));

		assertTrue(subkey.compare(this.obj_12345, this.obj_54321) < 0);
		assertTrue(subkey.compare(this.obj_54321, this.obj_12345) > 0);

		assertTrue(subkey.compare(this.obj_11111, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_11111) > 0);

		assertTrue(subkey.compare(this.obj_1234, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_1234) > 0);

		assertTrue(subkey.compare(this.obj_12345, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_12345) > 0);

		assertTrue(subkey.compare(this.obj_null, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_null) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_null) < 0);
		assertTrue(subkey.compare(this.obj_null, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_null, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_null) > 0);

		subkey = new NumberBasedSubkey("Count", 2, 2);

		assertEquals(new JsonArray(new JsonNumber(34L)), subkey.getSubkeyValue(this.obj_12345));
		assertEquals(new JsonArray(new JsonNumber(32L)), subkey.getSubkeyValue(this.obj_54321));
		assertEquals(new JsonArray(new JsonNumber(11L)), subkey.getSubkeyValue(this.obj_11111));
		assertEquals(new JsonArray(new JsonNumber(34L)), subkey.getSubkeyValue(this.obj_1234));

		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_asd));
		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_null));
		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_));

		assertEquals(0, subkey.compare(this.obj_12345, this.obj_12345));
		assertEquals(0, subkey.compare(this.obj_54321, this.obj_54321));
		assertEquals(0, subkey.compare(this.obj_11111, this.obj_11111));
		assertEquals(0, subkey.compare(this.obj_1234, this.obj_1234));
		assertEquals(0, subkey.compare(this.obj_asd, this.obj_asd));
		assertEquals(0, subkey.compare(this.obj_null, this.obj_null));

		assertTrue(subkey.compare(this.obj_54321, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_54321) > 0);

		assertTrue(subkey.compare(this.obj_11111, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_11111) > 0);

		assertEquals(0, subkey.compare(this.obj_1234, this.obj_12345));
		assertEquals(0, subkey.compare(this.obj_12345, this.obj_1234));

		assertTrue(subkey.compare(this.obj_12345, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_12345) > 0);

		assertTrue(subkey.compare(this.obj_null, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_null) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_null) < 0);
		assertTrue(subkey.compare(this.obj_null, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_null, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_null) > 0);

		subkey = new NumberBasedSubkey("Count", -1, 2);

		assertEquals(new JsonArray(new JsonNumber(5L)), subkey.getSubkeyValue(this.obj_12345));
		assertEquals(new JsonArray(new JsonNumber(1L)), subkey.getSubkeyValue(this.obj_54321));
		assertEquals(new JsonArray(new JsonNumber(1L)), subkey.getSubkeyValue(this.obj_11111));
		assertEquals(new JsonArray(new JsonNumber(4L)), subkey.getSubkeyValue(this.obj_1234));

		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_asd));
		assertEquals(new JsonArray(new JsonNumber(0L)), subkey.getSubkeyValue(this.obj_null));
		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_));

		assertEquals(0, subkey.compare(this.obj_12345, this.obj_12345));
		assertEquals(0, subkey.compare(this.obj_54321, this.obj_54321));
		assertEquals(0, subkey.compare(this.obj_11111, this.obj_11111));
		assertEquals(0, subkey.compare(this.obj_1234, this.obj_1234));
		assertEquals(0, subkey.compare(this.obj_asd, this.obj_asd));
		assertEquals(0, subkey.compare(this.obj_null, this.obj_null));

		assertTrue(subkey.compare(this.obj_54321, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_54321) > 0);

		assertTrue(subkey.compare(this.obj_11111, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_11111) > 0);

		assertEquals(0, subkey.compare(this.obj_11111, this.obj_54321));
		assertEquals(0, subkey.compare(this.obj_54321, this.obj_11111));

		assertTrue(subkey.compare(this.obj_1234, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_1234) > 0);

		assertTrue(subkey.compare(this.obj_12345, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_12345) > 0);

		assertTrue(subkey.compare(this.obj_null, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_null) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_null) < 0);
		assertTrue(subkey.compare(this.obj_null, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_null, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_null) > 0);

		try {
			subkey = new NumberBasedSubkey("Count", -1, -2);
			fail("IllegalArgumentException should have been thrown...");
		} catch (IllegalArgumentException e) {
			// nothing to do
		}
	}

	/**
	 * Tests {@link NumberBasedSubkey#compare(DuDeObject, DuDeObject)} using the
	 * {@link NumberBasedSubkey#NumberBasedSubkey(String, Integer[])} constructor.
	 */
	@Test
	public void testNumberBasedSubkeyStringIntegerArray() {
		NumberBasedSubkey subkey = new NumberBasedSubkey("Count", new Integer[] { 2, 3 });

		assertEquals(new JsonArray(new JsonNumber(34L)), subkey.getSubkeyValue(this.obj_12345));
		assertEquals(new JsonArray(new JsonNumber(32L)), subkey.getSubkeyValue(this.obj_54321));
		assertEquals(new JsonArray(new JsonNumber(11L)), subkey.getSubkeyValue(this.obj_11111));
		assertEquals(new JsonArray(new JsonNumber(34L)), subkey.getSubkeyValue(this.obj_1234));

		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_asd));
		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_null));
		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_));

		assertEquals(0, subkey.compare(this.obj_12345, this.obj_12345));
		assertEquals(0, subkey.compare(this.obj_54321, this.obj_54321));
		assertEquals(0, subkey.compare(this.obj_11111, this.obj_11111));
		assertEquals(0, subkey.compare(this.obj_1234, this.obj_1234));
		assertEquals(0, subkey.compare(this.obj_asd, this.obj_asd));
		assertEquals(0, subkey.compare(this.obj_null, this.obj_null));

		assertTrue(subkey.compare(this.obj_54321, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_54321) > 0);

		assertTrue(subkey.compare(this.obj_11111, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_11111) > 0);

		assertEquals(0, subkey.compare(this.obj_1234, this.obj_12345));
		assertEquals(0, subkey.compare(this.obj_12345, this.obj_1234));

		assertTrue(subkey.compare(this.obj_12345, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_12345) > 0);

		assertTrue(subkey.compare(this.obj_null, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_null) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_null) < 0);
		assertTrue(subkey.compare(this.obj_null, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_null, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_null) > 0);

		subkey = new NumberBasedSubkey("Count", new Integer[] { 4, 3 });

		assertEquals(new JsonArray(new JsonNumber(54L)), subkey.getSubkeyValue(this.obj_12345));
		assertEquals(new JsonArray(new JsonNumber(12L)), subkey.getSubkeyValue(this.obj_54321));
		assertEquals(new JsonArray(new JsonNumber(11L)), subkey.getSubkeyValue(this.obj_11111));
		assertEquals(new JsonArray(new JsonNumber(4L)), subkey.getSubkeyValue(this.obj_1234));

		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_asd));
		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_null));
		assertEquals(new JsonArray(), subkey.getSubkeyValue(this.obj_));

		assertEquals(0, subkey.compare(this.obj_12345, this.obj_12345));
		assertEquals(0, subkey.compare(this.obj_54321, this.obj_54321));
		assertEquals(0, subkey.compare(this.obj_11111, this.obj_11111));
		assertEquals(0, subkey.compare(this.obj_1234, this.obj_1234));
		assertEquals(0, subkey.compare(this.obj_asd, this.obj_asd));
		assertEquals(0, subkey.compare(this.obj_null, this.obj_null));

		assertTrue(subkey.compare(this.obj_54321, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_54321) > 0);

		assertTrue(subkey.compare(this.obj_11111, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_11111) > 0);

		assertTrue(subkey.compare(this.obj_1234, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_1234) > 0);

		assertTrue(subkey.compare(this.obj_12345, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_12345) > 0);

		assertTrue(subkey.compare(this.obj_null, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_null) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_12345) < 0);
		assertTrue(subkey.compare(this.obj_12345, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_null) < 0);
		assertTrue(subkey.compare(this.obj_null, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_) > 0);

		assertTrue(subkey.compare(this.obj_null, this.obj_asd) < 0);
		assertTrue(subkey.compare(this.obj_asd, this.obj_null) > 0);
	}

}
