/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.util.data.storage;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.util.GlobalConfig;
import de.hpi.fgis.dude.util.data.Jsonable;
import de.hpi.fgis.dude.util.data.json.DuDeJsonGenerator;
import de.hpi.fgis.dude.util.data.json.JsonArray;
import de.hpi.fgis.dude.util.data.json.JsonBoolean;
import de.hpi.fgis.dude.util.data.json.JsonNull;
import de.hpi.fgis.dude.util.data.json.JsonNumber;
import de.hpi.fgis.dude.util.data.json.JsonRecord;
import de.hpi.fgis.dude.util.data.json.JsonString;
import de.hpi.fgis.dude.util.data.json.JsonValue;

/**
 * Tests {@link FileBasedStorage}.
 * 
 * @author Matthias Pohl
 */
public class FileBasedStorageTest {

	private File jsonFile;

	/**
	 * The directory where the test file is located.
	 */
	protected final String filePath = GlobalConfig.getInstance().getWorkingDirectory();

	/**
	 * Name of the file.
	 */
	protected final String filename = "fileBasedStorageTest";

	/**
	 * The content of the test file.
	 */
	protected final Collection<JsonValue> fileContent = new ArrayList<JsonValue>();

	private void initializeValues() {
		this.fileContent.add(new JsonString("test"));
		this.fileContent.add(new JsonNumber(123));
		this.fileContent.add(JsonBoolean.TRUE);
		this.fileContent.add(JsonNull.NULL);
		this.fileContent.add(new JsonArray(new JsonString("array")));

		JsonRecord record = new JsonRecord();
		record.put("attr", "record");
		this.fileContent.add(record);
	}

	/**
	 * The preset of each test method.
	 * 
	 * @throws Exception
	 *             If an error occurs while initializing the test methods.
	 */
	@Before
	public void setUp() throws Exception {
		this.initializeValues();

		this.jsonFile = new File(this.filePath + this.filename + FileBasedStorage.JSON_FILE_EXTENSION);

		DuDeJsonGenerator jsonGenerator = new DuDeJsonGenerator(new FileWriter(this.jsonFile));
		jsonGenerator.writeArrayStart();
		for (Jsonable jsonable : this.fileContent) {
			jsonable.toJson(jsonGenerator);
		}
		jsonGenerator.writeArrayEnd();
		jsonGenerator.close();
	}

	/**
	 * The tear-down method for each test method.
	 * 
	 * @throws Exception
	 *             If an error occurs during the method call.
	 */
	@After
	public void tearDown() throws Exception {
		this.jsonFile.delete();
		GlobalConfig.getInstance().deleteWorkingDirOnExit();
	}

	/**
	 * Tests {@link FileBasedStorage#getReader()}.
	 */
	@Test
	public void testGetReader() {
		try {
			FileBasedStorage<JsonValue> storage = new FileBasedStorage<JsonValue>(this.filename);
			
			JsonableReader<JsonValue> reader = storage.getReader();
			
			assertNotNull(reader);
			
			reader.close();
		} catch (IOException e) {
			fail("IOException occurred...");
		}
	}
	
	/**
	 * Tests {@link FileBasedStorage#getWriter()}.
	 */
	@Test
	public void testGetWriter() {
		
		try {
			FileBasedStorage<JsonValue> storage = new FileBasedStorage<JsonValue>(this.filename);
			
			assertEquals(this.fileContent.size(), storage.size());
			
			JsonableWriter<JsonValue> writer = storage.getWriter();
			
			assertNotNull(writer);
			
			assertEquals(0, storage.size());
			
			writer.close();
		} catch (IOException e) {
			fail("IOException occurred...");
		}
	}

	/**
	 * Tests {@link FileBasedStorage#size()}.
	 */
	@Test
	public void testSize() {
		try {
			FileBasedStorage<JsonValue> storage = new FileBasedStorage<JsonValue>(this.filename);
			assertEquals(this.fileContent.size(), storage.size());
		} catch (IOException e) {
			fail("IOException occurred...");
		}
	}

	/**
	 * Tests {@link FileBasedStorage#renameTo(String)}.
	 */
	@Test
	public void testRenameTo() {
		FileBasedStorage<JsonValue> storage = null;
		try {
			storage = new FileBasedStorage<JsonValue>(this.filename);
		} catch (IOException e) {
			fail("IOException occurred...");
		}

		final String newFilename = "renamedFile";

		final File newFile = new File(this.filePath + newFilename + FileBasedStorage.JSON_FILE_EXTENSION);

		assertTrue(this.jsonFile.exists());
		assertFalse(newFile.exists());

		storage.renameTo(newFilename);

		assertFalse(this.jsonFile.exists());
		assertTrue(newFile.exists());

		newFile.delete();
	}

	/**
	 * Tests {@link FileBasedStorage#delete()}.
	 */
	@Test
	public void testDelete() {
		FileBasedStorage<JsonValue> storage = null;
		try {
			storage = new FileBasedStorage<JsonValue>(this.filename);
		} catch (IOException e) {
			fail("IOException occurred...");
		}

		assertTrue(this.jsonFile.exists());

		storage.delete();

		assertFalse(this.jsonFile.exists());
	}

}
