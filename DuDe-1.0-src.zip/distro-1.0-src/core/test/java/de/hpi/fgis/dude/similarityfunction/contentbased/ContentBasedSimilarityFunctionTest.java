/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.similarityfunction.contentbased;

import static org.junit.Assert.assertEquals;
import de.hpi.fgis.dude.similarityfunction.SimilarityFunction;
import de.hpi.fgis.dude.similarityfunction.SimilarityFunction.SimilarityValidationState;
import de.hpi.fgis.dude.util.data.DuDeObject;
import de.hpi.fgis.dude.util.data.DuDeObjectPair;
import de.hpi.fgis.dude.util.data.json.JsonArray;
import de.hpi.fgis.dude.util.data.json.JsonRecord;
import de.hpi.fgis.dude.util.data.json.JsonString;
import de.hpi.fgis.dude.util.data.json.JsonValue;

/**
 * <code>ContentBasedSimilarityFunctionTest</code> is a super class for testing the behavior of all content-based {@link SimilarityFunction}s.
 * 
 * @author Matthias Pohl
 */
public abstract class ContentBasedSimilarityFunctionTest {

	/**
	 * The attribute that is used.
	 */
	protected static final String ATTRIBUTE_NAME = "attr";

	private static final double TEST_ACCURACY = 0.000001;

	/**
	 * The {@link ContentBasedSimilarityFunction} that shall be tested.
	 */
	protected ContentBasedSimilarityFunction<?> similarityFunction;

	/**
	 * Tests the behavior of the {@link ContentBasedSimilarityFunction} using the passed Strings.
	 * 
	 * @param str1
	 *            The first String.
	 * @param str2
	 *            The second String.
	 * @param expectedValue
	 *            The expected similarity value.
	 */
	protected void testSimilarity(String str1, String str2, double expectedValue) {
		this.testSimilarity(new JsonString(str1), new JsonString(str2), expectedValue);
	}

	/**
	 * Tests the behavior of the {@link ContentBasedSimilarityFunction} using the passed {@link JsonValue}s.
	 * 
	 * @param value1
	 *            The first <code>JsonValue</code>.
	 * @param value2
	 *            The second <code>JsonValue</code>.
	 * @param expectedValue
	 *            The expected similarity value.
	 */
	protected void testSimilarity(JsonValue value1, JsonValue value2, double expectedValue) {
		this.testSimilarity(value1, value2, expectedValue, SimilarityValidationState.BothValid);
	}

	/**
	 * Tests the behavior of the {@link ContentBasedSimilarityFunction} using the passed {@link JsonValue}s.
	 * 
	 * @param value1
	 *            The first <code>JsonValue</code>.
	 * @param value2
	 *            The second <code>JsonValue</code>.
	 * @param expectedValue
	 *            The expected similarity value.
	 * @param expectedState
	 *            The expected {@link SimilarityValidationState}.
	 */
	protected void testSimilarity(JsonValue value1, JsonValue value2, double expectedValue, SimilarityValidationState expectedState) {
		JsonRecord data;

		data = new JsonRecord();
		data.put(ContentBasedSimilarityFunctionTest.ATTRIBUTE_NAME, value1);
		DuDeObject obj1 = new DuDeObject(data, "test", new JsonArray(value1));

		data = new JsonRecord();
		data.put(ContentBasedSimilarityFunctionTest.ATTRIBUTE_NAME, value2);
		DuDeObject obj2 = new DuDeObject(data, "test", new JsonArray(value2));

		assertEquals("Compared values: " + value1.toString() + " <=> " + value2.toString(), expectedValue, this.getSimilarity(obj1, obj2),
				ContentBasedSimilarityFunctionTest.TEST_ACCURACY);
		assertEquals(expectedState, this.similarityFunction.getLastValidationState());
	}

	private double getSimilarity(DuDeObject obj1, DuDeObject obj2) {
		return this.similarityFunction.getSimilarity(new DuDeObjectPair(obj1, obj2));
	}
}
