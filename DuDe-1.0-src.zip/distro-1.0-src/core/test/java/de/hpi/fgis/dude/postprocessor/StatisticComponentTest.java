/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.postprocessor;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import de.hpi.fgis.dude.algorithm.Algorithm;
import de.hpi.fgis.dude.algorithm.duplicatedetection.NaiveDuplicateDetection;
import de.hpi.fgis.dude.datasource.CSVSource;
import de.hpi.fgis.dude.datasource.DuDeObjectSource;
import de.hpi.fgis.dude.util.GoldStandard;
import de.hpi.fgis.dude.util.data.DuDeObject;
import de.hpi.fgis.dude.util.data.DuDeObjectPair;
import de.hpi.fgis.dude.util.data.json.JsonArray;
import de.hpi.fgis.dude.util.data.json.JsonRecord;
import de.hpi.fgis.dude.util.data.json.JsonString;

/**
 * Tests the {@link StatisticComponent} class.
 * 
 * @author Uwe Draisbach
 */
public class StatisticComponentTest {
	
	private StatisticComponent statistic;
	
	private DuDeObjectPair firstPositivePair;
	private DuDeObjectPair secondPositivePair;
	private DuDeObjectPair thirdPositivePair;
	private DuDeObjectPair fourthPositivePair;
	
	private DuDeObjectPair firstNegativePair;
	private DuDeObjectPair secondNegativePair;
	private DuDeObjectPair thirdNegativePair;
	private DuDeObjectPair fourthNegativePair;
	
	private File goldStandardFile = new File("./junit_sample.csv");

	/**
	 * The preset of each test method.
	 * 
	 * @throws Exception
	 *             If an error occurs while initializing the test methods.
	 */
	@Before
	public void setUp() throws Exception {
		
		JsonRecord data1;
		JsonRecord data2;
		
		// create firstPositivePair
		data1 = new JsonRecord(); data1.put("Name", new JsonArray(new JsonString("A")));
		data2 = new JsonRecord(); data2.put("Name", new JsonArray(new JsonString("B")));
		this.firstPositivePair = new DuDeObjectPair(new DuDeObject(data1, "", "1"), new DuDeObject(data2, "", "2"));
		
		// create secondPositivePair
		data1 = new JsonRecord(); data1.put("Name", new JsonArray(new JsonString("C")));
		data2 = new JsonRecord(); data2.put("Name", new JsonArray(new JsonString("D")));
		this.secondPositivePair = new DuDeObjectPair(new DuDeObject(data1, "", "3"), new DuDeObject(data2, "", "4"));
		
		// create thirdPositivePair
		data1 = new JsonRecord(); data1.put("Name", new JsonArray(new JsonString("E")));
		data2 = new JsonRecord(); data2.put("Name", new JsonArray(new JsonString("F")));
		this.thirdPositivePair = new DuDeObjectPair(new DuDeObject(data1, "", "5"), new DuDeObject(data2, "", "6"));
		
		// create fourthPositivePair
		data1 = new JsonRecord(); data1.put("Name", new JsonArray(new JsonString("G")));
		data2 = new JsonRecord(); data2.put("Name", new JsonArray(new JsonString("G")));
		this.fourthPositivePair = new DuDeObjectPair(new DuDeObject(data1, "", "7"), new DuDeObject(data2, "", "8"));
		
		// create firstNegativePair
		data1 = new JsonRecord(); data1.put("Name", new JsonArray(new JsonString("I")));
		data2 = new JsonRecord(); data2.put("Name", new JsonArray(new JsonString("J")));
		this.firstNegativePair = new DuDeObjectPair(new DuDeObject(data1, "", "9"), new DuDeObject(data2, "", "10"));
		
		// create secondNegativePair
		data1 = new JsonRecord(); data1.put("Name", new JsonArray(new JsonString("K")));
		data2 = new JsonRecord(); data2.put("Name", new JsonArray(new JsonString("L")));
		this.secondNegativePair = new DuDeObjectPair(new DuDeObject(data1, "", "11"), new DuDeObject(data2, "", "12"));
		
		// create thirdNegativePair
		data1 = new JsonRecord(); data1.put("Name", new JsonArray(new JsonString("M")));
		data2 = new JsonRecord(); data2.put("Name", new JsonArray(new JsonString("N")));
		this.thirdNegativePair = new DuDeObjectPair(new DuDeObject(data1, "", "13"), new DuDeObject(data2, "", "14"));
		
		// create fourthNegativePair
		data1 = new JsonRecord(); data1.put("Name", new JsonArray(new JsonString("E")));
		data2 = new JsonRecord(); data2.put("Name", new JsonArray(new JsonString("F")));
		this.fourthNegativePair = new DuDeObjectPair(new DuDeObject(data1, "", "15"), new DuDeObject(data2, "", "16"));

		
		// create gold standard
		PrintStream writer = new PrintStream(new File("./junit_sample.csv"));
		writer.println("id_1;id_2");
		writer.println("1;2");
		writer.println("3;4");
		writer.println("5;6");
		writer.println("7;8");
		writer.close();
		
		CSVSource goldStandardSource = new CSVSource("gs", this.goldStandardFile);
		goldStandardSource.enableHeader();
		goldStandardSource.setSeparatorCharacter(';');
		GoldStandard goldStandard = new GoldStandard(goldStandardSource);
		goldStandard.setFirstElementsObjectIdAttributes("id_1");
		goldStandard.setSecondElementsObjectIdAttributes("id_2");
		
		
		// instantiate statistic component
		Collection<DuDeObject> data = new ArrayList<DuDeObject>();
		data.add(this.firstPositivePair.getFirstElement());
		data.add(this.firstPositivePair.getSecondElement());
		data.add(this.secondPositivePair.getFirstElement());
		data.add(this.secondPositivePair.getSecondElement());
		data.add(this.thirdPositivePair.getFirstElement());
		data.add(this.thirdPositivePair.getSecondElement());
		data.add(this.fourthPositivePair.getFirstElement());
		data.add(this.fourthPositivePair.getSecondElement());
		data.add(this.firstNegativePair.getFirstElement());
		data.add(this.firstNegativePair.getSecondElement());
		data.add(this.secondNegativePair.getFirstElement());
		data.add(this.secondNegativePair.getSecondElement());
		data.add(this.thirdNegativePair.getFirstElement());
		data.add(this.thirdNegativePair.getSecondElement());
		data.add(this.fourthNegativePair.getFirstElement());
		data.add(this.fourthNegativePair.getSecondElement());
		
		Algorithm algorithm = new NaiveDuplicateDetection();
		algorithm.enableInMemoryProcessing();
		
		algorithm.addDataSource(new DuDeObjectSource("", data));
		
		this.statistic = new StatisticComponent(goldStandard, algorithm);
		
		// initiate data extraction
		algorithm.iterator();
	}
	
	/**
	 * The tear-down method for each test method.
	 * 
	 * @throws Exception
	 *             If an error occurs during the method call.
	 */
	@After
	public void tearDown() throws Exception {
		this.goldStandardFile.delete();
	}
	
	/**
	 * JUnit-Test for the following key figures:
	 * - Num. of data records
	 * - Num. of real duplicates 
	 * - Num. of candidate pairs
	 * - Num. of pairs
	 * - Num. of comparisons
	 * - Reduction ratio
	 * - Reduction ratio by comparison
	 * - TruePositives
	 * - FalsePositives
	 * - TrueNegatives
	 * - FalseNegatives
	 * - TruePositivesByComparison
	 * - FalsePositivesByComaprison
	 * - TrueNegativesByComparison
	 * - FalseNegativesByComparison
	 * - Precision
	 * - Recall
	 * - F-Measure
	 * - PrecisionByComparison
	 * - RecallByComparison
	 * - F-MeasureByComparison
	 */
	@Test
	public void testKeyFigures() {
		
		assertTrue("Num. of data records", this.statistic.getObjectCount()==16);
		assertTrue("Num. of real duplicates", this.statistic.getNumberOfRealDuplicates()==4);
		
		// Step 1: no pairs added
		assertTrue("Step 1 - Num. of candidate pairs", this.statistic.getNumberOfCandidateComparisons()==120);
		assertTrue("Step 1 - Num. of pairs", this.statistic.getPairCount()==0);
		assertTrue("Step 1 - Num. of comparisons", this.statistic.getComparisonCount()==0);
        assertTrue("Step 1 - Reduction ratio", this.statistic.getReductionRatio()==1);
        assertTrue("Step 1 - Reduction ratio by comparison", this.statistic.getReductionRatioByComparison()==1);		
		
		assertTrue("Step 1 - TruePositives",  this.statistic.getTruePositives()==0);
		assertTrue("Step 1 - FalsePositives", this.statistic.getFalsePositives()==0);
		assertTrue("Step 1 - TrueNegatives",  this.statistic.getTrueNegatives()==116);
		assertTrue("Step 1 - FalseNegatives", this.statistic.getFalseNegatives()==4);
		
		assertTrue("Step 1 - TruePositivesByComparison",  this.statistic.getTruePositivesByComparison()==0);
		assertTrue("Step 1 - FalsePositivesByComaprison", this.statistic.getFalsePositivesByComparison()==0);
		assertTrue("Step 1 - TrueNegativesByComparison",  this.statistic.getTrueNegativesByComparison()==0);
		assertTrue("Step 1 - FalseNegativesByComparison", this.statistic.getFalseNegativesByComparison()==0);
		
		assertTrue("Step 1 - Precision",  this.statistic.getPrecision()==1);
		assertTrue("Step 1 - Recall",  this.statistic.getRecall()==0);
		assertTrue("Step 1 - F-Measure",  this.statistic.getFMeasure()==0);
		
		assertTrue("Step 1 - PrecisionByComparison",  this.statistic.getPrecisionByComparison()==1);
		assertTrue("Step 1 - RecallByComparison",  this.statistic.getRecallByComparison()==0);
		assertTrue("Step 1 - F-MeasureByComparison",  this.statistic.getFMeasureByComparison()==0);
		
		
		// Step 2: add True-Positive as comparison
		this.statistic.addDuplicate(this.firstPositivePair, true);
		
		assertTrue("Step 2 - Num. of candidate pairs", this.statistic.getNumberOfCandidateComparisons()==120);
		assertTrue("Step 2 - Num. of pairs", this.statistic.getPairCount()==1);
		assertTrue("Step 2 - Num. of comparisons", this.statistic.getComparisonCount()==1);
        assertTrue("Step 2 - Reduction ratio", Math.round( this.statistic.getReductionRatio() * 10000 ) / 10000.0==0.9917);
        assertTrue("Step 2 - Reduction ratio by comparison", Math.round( this.statistic.getReductionRatioByComparison() * 10000 ) / 10000.0==0.9917);
		
		assertTrue("Step 2 - TruePositives",  this.statistic.getTruePositives()==1);
		assertTrue("Step 2 - FalsePositives", this.statistic.getFalsePositives()==0);
		assertTrue("Step 2 - TrueNegatives",  this.statistic.getTrueNegatives()==116);
		assertTrue("Step 2 - FalseNegatives", this.statistic.getFalseNegatives()==3);
		
		assertTrue("Step 2 - TruePositivesByComparison",  this.statistic.getTruePositivesByComparison()==1);
		assertTrue("Step 2 - FalsePositivesByComaprison", this.statistic.getFalsePositivesByComparison()==0);
		assertTrue("Step 2 - TrueNegativesByComparison",  this.statistic.getTrueNegativesByComparison()==0);
		assertTrue("Step 2 - FalseNegativesByComparison", this.statistic.getFalseNegativesByComparison()==0);
		
		assertTrue("Step 2 - Precision",  this.statistic.getPrecision()==1);
		assertTrue("Step 2 - Recall",  this.statistic.getRecall()==0.25);
		assertTrue("Step 2 - F-Measure",  this.statistic.getFMeasure()==0.4);
		
		assertTrue("Step 2 - PrecisionByComparison",  this.statistic.getPrecisionByComparison()==1);
		assertTrue("Step 2 - RecallByComparison",  this.statistic.getRecallByComparison()==0.25);
		assertTrue("Step 2 - F-MeasureByComparison",  this.statistic.getFMeasureByComparison()==0.4);
		
		
		// Step 3: add False-Positive as comparison
		this.statistic.addDuplicate(this.firstNegativePair, true);
		
		assertTrue("Step 3 - Num. of candidate pairs", this.statistic.getNumberOfCandidateComparisons()==120);
		assertTrue("Step 3 - Num. of pairs", this.statistic.getPairCount()==2);
		assertTrue("Step 3 - Num. of comparisons", this.statistic.getComparisonCount()==2);
        assertTrue("Step 3 - Reduction ratio", Math.round( this.statistic.getReductionRatio() * 10000 ) / 10000.0==0.9833);
        assertTrue("Step 3 - Reduction ratio by comparison", Math.round( this.statistic.getReductionRatioByComparison() * 10000 ) / 10000.0==0.9833);
		
		assertTrue("Step 3 - TruePositives",  this.statistic.getTruePositives()==1);
		assertTrue("Step 3 - FalsePositives", this.statistic.getFalsePositives()==1);
		assertTrue("Step 3 - TrueNegatives",  this.statistic.getTrueNegatives()==115);
		assertTrue("Step 3 - FalseNegatives", this.statistic.getFalseNegatives()==3);
		
		assertTrue("Step 3 - TruePositivesByComparison",  this.statistic.getTruePositivesByComparison()==1);
		assertTrue("Step 3 - FalsePositivesByComaprison", this.statistic.getFalsePositivesByComparison()==1);
		assertTrue("Step 3 - TrueNegativesByComparison",  this.statistic.getTrueNegativesByComparison()==0);
		assertTrue("Step 3 - FalseNegativesByComparison", this.statistic.getFalseNegativesByComparison()==0);
		
		assertTrue("Step 3 - Precision",  this.statistic.getPrecision()==0.5);
		assertTrue("Step 3 - Recall",  this.statistic.getRecall()==0.25);
		assertTrue("Step 3 - F-Measure", Math.round( this.statistic.getFMeasure() * 10000 ) / 10000.0==0.3333);
		
		assertTrue("Step 3 - PrecisionByComparison",  this.statistic.getPrecisionByComparison()==0.5);
		assertTrue("Step 3 - RecallByComparison",  this.statistic.getRecallByComparison()==0.25);
		assertTrue("Step 3 - F-MeasureByComparison",  Math.round( this.statistic.getFMeasureByComparison() * 10000 ) / 10000.0==0.3333);
		
		
		// Step 4: add True-Negative as comparison
		this.statistic.addNonDuplicate(this.secondNegativePair, true);
		
		assertTrue("Step 4 - Num. of candidate pairs", this.statistic.getNumberOfCandidateComparisons()==120);
		assertTrue("Step 4 - Num. of pairs", this.statistic.getPairCount()==3);
		assertTrue("Step 4 - Num. of comparisons", this.statistic.getComparisonCount()==3);
        assertTrue("Step 4 - Reduction ratio", Math.round( this.statistic.getReductionRatio() * 10000 ) / 10000.0==0.9750);
        assertTrue("Step 4 - Reduction ratio by comparison", Math.round( this.statistic.getReductionRatioByComparison() * 10000 ) / 10000.0==0.9750);
		
		assertTrue("Step 4 - TruePositives",  this.statistic.getTruePositives()==1);
		assertTrue("Step 4 - FalsePositives", this.statistic.getFalsePositives()==1);
		assertTrue("Step 4 - TrueNegatives",  this.statistic.getTrueNegatives()==115);
		assertTrue("Step 4 - FalseNegatives", this.statistic.getFalseNegatives()==3);
		
		assertTrue("Step 4 - TruePositivesByComparison",  this.statistic.getTruePositivesByComparison()==1);
		assertTrue("Step 4 - FalsePositivesByComaprison", this.statistic.getFalsePositivesByComparison()==1);
		assertTrue("Step 4 - TrueNegativesByComparison",  this.statistic.getTrueNegativesByComparison()==1);
		assertTrue("Step 4 - FalseNegativesByComparison", this.statistic.getFalseNegativesByComparison()==0);
		
		assertTrue("Step 4 - Precision",  this.statistic.getPrecision()==0.5);
		assertTrue("Step 4 - Recall",  this.statistic.getRecall()==0.25);
		assertTrue("Step 4 - F-Measure", Math.round( this.statistic.getFMeasure() * 10000 ) / 10000.0==0.3333);
		
		assertTrue("Step 4 - PrecisionByComparison",  this.statistic.getPrecisionByComparison()==0.5);
		assertTrue("Step 4 - RecallByComparison",  this.statistic.getRecallByComparison()==0.25);
		assertTrue("Step 4 - F-MeasureByComparison",  Math.round( this.statistic.getFMeasureByComparison() * 10000 ) / 10000.0==0.3333);
		
		
		// Step 5: add False-Negative as comparison
		this.statistic.addNonDuplicate(this.secondPositivePair, true);
		
		assertTrue("Step 5 - Num. of candidate pairs", this.statistic.getNumberOfCandidateComparisons()==120);
		assertTrue("Step 5 - Num. of pairs", this.statistic.getPairCount()==4);
		assertTrue("Step 5 - Num. of comparisons", this.statistic.getComparisonCount()==4);
        assertTrue("Step 5 - Reduction ratio", Math.round( this.statistic.getReductionRatio() * 10000 ) / 10000.0==0.9667);
        assertTrue("Step 5 - Reduction ratio by comparison", Math.round( this.statistic.getReductionRatioByComparison() * 10000 ) / 10000.0==0.9667);
		
		assertTrue("Step 5 - TruePositives",  this.statistic.getTruePositives()==1);
		assertTrue("Step 5 - FalsePositives", this.statistic.getFalsePositives()==1);
		assertTrue("Step 5 - TrueNegatives",  this.statistic.getTrueNegatives()==115);
		assertTrue("Step 5 - FalseNegatives", this.statistic.getFalseNegatives()==3);
		
		assertTrue("Step 5 - TruePositivesByComparison",  this.statistic.getTruePositivesByComparison()==1);
		assertTrue("Step 5 - FalsePositivesByComaprison", this.statistic.getFalsePositivesByComparison()==1);
		assertTrue("Step 5 - TrueNegativesByComparison",  this.statistic.getTrueNegativesByComparison()==1);
		assertTrue("Step 5 - FalseNegativesByComparison", this.statistic.getFalseNegativesByComparison()==1);
		
		assertTrue("Step 5 - Precision",  this.statistic.getPrecision()==0.5);
		assertTrue("Step 5 - Recall",  this.statistic.getRecall()==0.25);
		assertTrue("Step 5 - F-Measure", Math.round( this.statistic.getFMeasure() * 10000 ) / 10000.0==0.3333);
		
		assertTrue("Step 5 - PrecisionByComparison",  this.statistic.getPrecisionByComparison()==0.5);
		assertTrue("Step 5 - RecallByComparison",  this.statistic.getRecallByComparison()==0.25);
		assertTrue("Step 5 - F-MeasureByComparison",  Math.round( this.statistic.getFMeasureByComparison() * 10000 ) / 10000.0==0.3333);
		
		
		// Step 6: add True-Positive without comparison
		this.statistic.addDuplicate(this.thirdPositivePair, false);
		
		assertTrue("Step 6 - Num. of candidate pairs", this.statistic.getNumberOfCandidateComparisons()==120);
		assertTrue("Step 6 - Num. of pairs", this.statistic.getPairCount()==5);
		assertTrue("Step 6 - Num. of comparisons", this.statistic.getComparisonCount()==4);
        assertTrue("Step 6 - Reduction ratio", Math.round( this.statistic.getReductionRatio() * 10000 ) / 10000.0==0.9583);
        assertTrue("Step 6 - Reduction ratio by comparison", Math.round( this.statistic.getReductionRatioByComparison() * 10000 ) / 10000.0==0.9667);
		
		assertTrue("Step 6 - TruePositives",  this.statistic.getTruePositives()==2);
		assertTrue("Step 6 - FalsePositives", this.statistic.getFalsePositives()==1);
		assertTrue("Step 6 - TrueNegatives",  this.statistic.getTrueNegatives()==115);
		assertTrue("Step 6 - FalseNegatives", this.statistic.getFalseNegatives()==2);
		
		assertTrue("Step 6 - TruePositivesByComparison",  this.statistic.getTruePositivesByComparison()==1);
		assertTrue("Step 6 - FalsePositivesByComaprison", this.statistic.getFalsePositivesByComparison()==1);
		assertTrue("Step 6 - TrueNegativesByComparison",  this.statistic.getTrueNegativesByComparison()==1);
		assertTrue("Step 6 - FalseNegativesByComparison", this.statistic.getFalseNegativesByComparison()==1);
		
		assertTrue("Step 6 - Precision",  Math.round( this.statistic.getPrecision() * 10000 ) / 10000.0==0.6667);
		assertTrue("Step 6 - Recall",  this.statistic.getRecall()==0.5);
		assertTrue("Step 6 - F-Measure", Math.round( this.statistic.getFMeasure() * 1000000 ) / 1000000.0==0.571429);
		
		assertTrue("Step 6 - PrecisionByComparison",  this.statistic.getPrecisionByComparison()==0.5);
		assertTrue("Step 6 - RecallByComparison",  this.statistic.getRecallByComparison()==0.25);
		assertTrue("Step 6 - F-MeasureByComparison",  Math.round( this.statistic.getFMeasureByComparison() * 10000 ) / 10000.0==0.3333);
	
		
		// Step 7: add False-Positive without comparison
		this.statistic.addDuplicate(this.thirdNegativePair, false);
		
		assertTrue("Step 7 - Num. of candidate pairs", this.statistic.getNumberOfCandidateComparisons()==120);
		assertTrue("Step 7 - Num. of pairs", this.statistic.getPairCount()==6);
		assertTrue("Step 7 - Num. of comparisons", this.statistic.getComparisonCount()==4);
        assertTrue("Step 7 - Reduction ratio", Math.round( this.statistic.getReductionRatio() * 10000 ) / 10000.0==0.9500);
        assertTrue("Step 7 - Reduction ratio by comparison", Math.round( this.statistic.getReductionRatioByComparison() * 10000 ) / 10000.0==0.9667);
		
		assertTrue("Step 7 - TruePositives",  this.statistic.getTruePositives()==2);
		assertTrue("Step 7 - FalsePositives", this.statistic.getFalsePositives()==2);
		assertTrue("Step 7 - TrueNegatives",  this.statistic.getTrueNegatives()==114);
		assertTrue("Step 7 - FalseNegatives", this.statistic.getFalseNegatives()==2);
		
		assertTrue("Step 7 - TruePositivesByComparison",  this.statistic.getTruePositivesByComparison()==1);
		assertTrue("Step 7 - FalsePositivesByComaprison", this.statistic.getFalsePositivesByComparison()==1);
		assertTrue("Step 7 - TrueNegativesByComparison",  this.statistic.getTrueNegativesByComparison()==1);
		assertTrue("Step 7 - FalseNegativesByComparison", this.statistic.getFalseNegativesByComparison()==1);
		
		assertTrue("Step 7 - Precision",  this.statistic.getPrecision()==0.5);
		assertTrue("Step 7 - Recall",  this.statistic.getRecall()==0.5);
		assertTrue("Step 7 - F-Measure",  this.statistic.getFMeasure()==0.5);
		
		assertTrue("Step 7 - PrecisionByComparison",  this.statistic.getPrecisionByComparison()==0.5);
		assertTrue("Step 7 - RecallByComparison",  this.statistic.getRecallByComparison()==0.25);
		assertTrue("Step 7 - F-MeasureByComparison",  Math.round( this.statistic.getFMeasureByComparison() * 10000 ) / 10000.0==0.3333);
		
		
		// Step 8: add True-Negative without comparison
		this.statistic.addNonDuplicate(this.fourthNegativePair, false);
		
		assertTrue("Step 8 - Num. of candidate pairs", this.statistic.getNumberOfCandidateComparisons()==120);
		assertTrue("Step 8 - Num. of pairs", this.statistic.getPairCount()==7);
		assertTrue("Step 8 - Num. of comparisons", this.statistic.getComparisonCount()==4);
        assertTrue("Step 8 - Reduction ratio", Math.round( this.statistic.getReductionRatio() * 10000 ) / 10000.0==0.9417);
        assertTrue("Step 8 - Reduction ratio by comparison", Math.round( this.statistic.getReductionRatioByComparison() * 10000 ) / 10000.0==0.9667);
		
		assertTrue("Step 8 - TruePositives",  this.statistic.getTruePositives()==2);
		assertTrue("Step 8 - FalsePositives", this.statistic.getFalsePositives()==2);
		assertTrue("Step 8 - TrueNegatives",  this.statistic.getTrueNegatives()==114);
		assertTrue("Step 8 - FalseNegatives", this.statistic.getFalseNegatives()==2);
		
		assertTrue("Step 8 - TruePositivesByComparison",  this.statistic.getTruePositivesByComparison()==1);
		assertTrue("Step 8 - FalsePositivesByComaprison", this.statistic.getFalsePositivesByComparison()==1);
		assertTrue("Step 8 - TrueNegativesByComparison",  this.statistic.getTrueNegativesByComparison()==1);
		assertTrue("Step 8 - FalseNegativesByComparison", this.statistic.getFalseNegativesByComparison()==1);
		
		assertTrue("Step 8 - Precision",  this.statistic.getPrecision()==0.5);
		assertTrue("Step 8 - Recall",  this.statistic.getRecall()==0.5);
		assertTrue("Step 8 - F-Measure",  this.statistic.getFMeasure()==0.5);
		
		assertTrue("Step 8 - PrecisionByComparison",  this.statistic.getPrecisionByComparison()==0.5);
		assertTrue("Step 8 - RecallByComparison",  this.statistic.getRecallByComparison()==0.25);
		assertTrue("Step 8 - F-MeasureByComparison",  Math.round( this.statistic.getFMeasureByComparison() * 10000 ) / 10000.0==0.3333);
		
		
		// Step 9: add False-Negative without comparison
		this.statistic.addNonDuplicate(this.fourthPositivePair, false);
		
		assertTrue("Step 9 - Num. of candidate pairs", this.statistic.getNumberOfCandidateComparisons()==120);
		assertTrue("Step 9 - Num. of pairs", this.statistic.getPairCount()==8);
		assertTrue("Step 9 - Num. of comparisons", this.statistic.getComparisonCount()==4);
        assertTrue("Step 9 - Reduction ratio", Math.round( this.statistic.getReductionRatio() * 10000 ) / 10000.0==0.9333);
        assertTrue("Step 9 - Reduction ratio by comparison", Math.round( this.statistic.getReductionRatioByComparison() * 10000 ) / 10000.0==0.9667);
		
		assertTrue("Step 9 - TruePositives",  this.statistic.getTruePositives()==2);
		assertTrue("Step 9 - FalsePositives", this.statistic.getFalsePositives()==2);
		assertTrue("Step 9 - TrueNegatives",  this.statistic.getTrueNegatives()==114);
		assertTrue("Step 9 - FalseNegatives", this.statistic.getFalseNegatives()==2);
		
		assertTrue("Step 9 - TruePositivesByComparison",  this.statistic.getTruePositivesByComparison()==1);
		assertTrue("Step 9 - FalsePositivesByComaprison", this.statistic.getFalsePositivesByComparison()==1);
		assertTrue("Step 9 - TrueNegativesByComparison",  this.statistic.getTrueNegativesByComparison()==1);
		assertTrue("Step 9 - FalseNegativesByComparison", this.statistic.getFalseNegativesByComparison()==1);
		
		assertTrue("Step 9 - Precision",  this.statistic.getPrecision()==0.5);
		assertTrue("Step 9 - Recall",  this.statistic.getRecall()==0.5);
		assertTrue("Step 9 - F-Measure",  this.statistic.getFMeasure()==0.5);
		
		assertTrue("Step 9 - PrecisionByComparison",  this.statistic.getPrecisionByComparison()==0.5);
		assertTrue("Step 9 - RecallByComparison",  this.statistic.getRecallByComparison()==0.25);
		assertTrue("Step 9 - F-MeasureByComparison",  Math.round( this.statistic.getFMeasureByComparison() * 10000 ) / 10000.0==0.3333);
	}

}
