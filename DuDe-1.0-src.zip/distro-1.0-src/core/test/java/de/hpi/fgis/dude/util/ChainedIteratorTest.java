/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.util;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import org.junit.Test;

/**
 * Tests the {@link ChainedIterator} class.
 * 
 * @author Arvid Heise
 */
public class ChainedIteratorTest {

	@SuppressWarnings("unchecked")
	private void testIterator(Iterable<?>... iterables) {
		Iterator<Object>[] iterators = new Iterator[iterables.length];
		List<Object> expected = new ArrayList<Object>();
		for (int index = 0; index < iterators.length; index++) {
			iterators[index] = (Iterator<Object>) iterables[index].iterator();
			expected.addAll(CollectionUtil.asList(iterables[index].iterator()));
		}
		testIterator(expected.iterator(), iterators);
	}

	private <T> void testIterator(Iterator<T> expected, Iterator<T>... iterators) {
		assertEquals(CollectionUtil.asList(expected), CollectionUtil.asList(new ChainedIterator<T>(iterators)));
	}

	/**
	 * 
	 */
	@Test
	public void testNoIterators() {
		testIterator();
	}

	/**
	 * 
	 */
	@Test
	public void testSingleEmptyIterator() {
		testIterator(new ArrayList<Integer>());
	}

	/**
	 * 
	 */
	@Test
	public void testMultipleEmptyIterators() {
		testIterator(new ArrayList<Integer>(), new ArrayList<Integer>(), new HashSet<Integer>());
	}

	/**
	 * 
	 */
	@Test
	public void testSingleIterator() {
		testIterator(Arrays.asList(1, 2, 3));
	}

	/**
	 * 
	 */
	@Test
	public void testMultipleIterators() {
		testIterator(Arrays.asList(1, 2, 3), Arrays.asList(4, 5, 6), new HashSet<Integer>(Arrays.asList(7, 8, 9)));
	}
}
