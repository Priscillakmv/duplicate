/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut für Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.similarityfunction.contentbased.util;

/**
 * <code>SoundEx</code> implements a phonetic algorithm for indexing names by sound.
 * 
 * @author Matthias Pohl
 */
public class SoundEx {

	private static final char[] MAP = {
	/*-  
	 A    B    C    D    E    F    G    H    I    J    K    L    M*/
	'0', '1', '2', '3', '0', '1', '2', '0', '0', '2', '2', '4', '5',
	/*-  
	 N    O    P    W    R    S    T    U    V    W    X    Y    Z*/
	'5', '0', '1', '2', '6', '2', '3', '0', '1', '0', '2', '0', '2' };

	/**
	 * Generates the <code>SoundEx</code> value of the passed String.
	 * 
	 * @param s
	 *            The String whose <code>SoundEx</code> value shall be generated.
	 * @return The <code>SoundEx</code> value of the passed String.
	 */
	public String getSoundEx(String s) {
		/*
		 * This code fragment was copied from http://www.java-forums.org/java-lang
		 * /7438-soundex-algorithm-implementation-java.html
		 */

		// Algorithm works on uppercase (mainframe era).
		String t = s.toUpperCase();

		StringBuilder res = new StringBuilder();
		char c, prev = '?';

		// Main loop: find up to 4 chars that map.
		for (int i = 0; i < t.length() && res.length() < 4 && (c = t.charAt(i)) != ','; i++) {

			// Check to see if the given character is alphabetic.
			// Text is already converted to uppercase. Algorithm
			// only handles ASCII letters, do NOT use Character.isLetter()!
			// Also, skip double letters.
			if (c >= 'A' && c <= 'Z' && c != prev) {
				prev = c;

				// First char is installed unchanged, for sorting.
				if (i == 0)
					res.append(c);
				else {
					char m = MAP[c - 'A'];
					if (m != '0')
						res.append(m);
				}
			}
		}
		if (res.length() == 0)
			return null;
		for (int i = res.length(); i < 4; i++)
			res.append('0');
		return res.toString();
	}

}
