/*
 * DuDe - The Duplicate Detection Toolkit
 * 
 * Copyright (C) 2010  Hasso-Plattner-Institut f�r Softwaresystemtechnik GmbH,
 *                     Potsdam, Germany 
 *
 * This file is part of DuDe.
 * 
 * DuDe is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DuDe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DuDe.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package de.hpi.fgis.dude.exec.duplicatedetection;

import java.io.FileInputStream;

import de.hpi.fgis.dude.algorithm.Algorithm;
import de.hpi.fgis.dude.algorithm.duplicatedetection.SortedNeighborhoodMethod;
import de.hpi.fgis.dude.database.DatabaseSource;
import de.hpi.fgis.dude.database.adapter.MySQLDatabase;
import de.hpi.fgis.dude.database.util.DBInfo;
import de.hpi.fgis.dude.datasource.DataSource;
import de.hpi.fgis.dude.similarityfunction.SimilarityFunction;
import de.hpi.fgis.dude.similarityfunction.aggregators.Average;
import de.hpi.fgis.dude.similarityfunction.contentbased.impl.simmetrics.LevenshteinDistanceFunction;
import de.hpi.fgis.dude.util.GlobalConfig;
import de.hpi.fgis.dude.util.data.DuDeObjectPair;
import de.hpi.fgis.dude.util.sorting.sortingkey.SortingKey;
import de.hpi.fgis.dude.util.sorting.sortingkey.TextBasedSubkey;

/**
 * Executes a run using a large data file with the {@link SortedNeighborhoodMethod}. In order to run this executable, the data actual person data has
 * to be included in a MySQL database. The corresponding connection information should be stored in a *.properties './res/dbinfo.properties'.
 * 
 * @author Matthias Pohl
 */
public class HugePersonDataTestExecClass {

	/**
	 * Runs the {@link SortedNeighborhoodMethod} on a huge data set.
	 * 
	 * @param args
	 *            Won't be considered.
	 * @throws Exception
	 *             If any exception occurs.
	 */
	public static void main(String[] args) throws Exception {
		// enables dynamic data-loading for file-based sorting
		GlobalConfig.getInstance().setInMemoryObjectThreshold(1000);

		// sets the data source
		DataSource dataSource = new DatabaseSource("persons", new MySQLDatabase(new DBInfo(new FileInputStream("./res/dbinfo.properties"))),
				"person_data_10000");

		// defines sub-keys that are used to generate the sorting key
		TextBasedSubkey artistSubkey = new TextBasedSubkey("lastName");
		artistSubkey.setIgnoredCharactersRegEx(TextBasedSubkey.NO_VOWELS_REGEX);

		// the key generator uses sub-key selectors to generate a key for each object
		SortingKey sortingKey = new SortingKey();
		sortingKey.addSubkey(artistSubkey);

		Algorithm algorithm = new SortedNeighborhoodMethod(sortingKey, 30);

		// enable in-memory storing
		algorithm.enableInMemoryProcessing();

		// adds the "data" to the algorithm
		algorithm.addDataSource(dataSource);

		// instantiates similarity measure
		SimilarityFunction comparator = new Average(new LevenshteinDistanceFunction("lastName"), new LevenshteinDistanceFunction("firstName"));

		long start = System.currentTimeMillis();

		// counts the generated object pairs
		int cnt = 0;
		int dupCnt = 0;

		for (DuDeObjectPair pair : algorithm) {
			if (comparator.getSimilarity(pair) > 0.9) {
				++dupCnt;
			}
			++cnt;
		}

		// print statistics
		System.out.println();
		System.out.println();
		System.out.println(dupCnt + " duplicates out of " + cnt + " pairs detected in " + (System.currentTimeMillis() - start) + " ms");
	}

}
